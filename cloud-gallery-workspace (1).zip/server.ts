import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import { initFirebase } from "./server/firebaseAdmin";
import { initDrive, getDriveService, uploadToDrive } from "./server/driveClient";
import { IMAGES_DIR } from "./server/storageHelpers";
import storageRouter from "./server/storageController";
import driveRouter from "./server/driveRouter";
import shareRouter from "./server/shareRouter";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Intercept zeroThreat validation requests at the absolute top of the server stack
  app.use((req, res, next) => {
    const rawPath = req.path.toLowerCase().trim();
    // Normalize path by stripping trailing slash
    const cleanPath = rawPath.endsWith('/') && rawPath.length > 1 ? rawPath.slice(0, -1) : rawPath;

    if (
      cleanPath === "/zero-threat" ||
      cleanPath === "/zero-threat.html" ||
      cleanPath === "/zerothreat" ||
      cleanPath === "/zerothreat.html"
    ) {
      console.log(`[ZeroThreat] Request intercepted: Path="${req.path}" Method="${req.method}" IP="${req.ip}"`);

      // Add fully permissive CORS headers so any external tool can access it
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS, POST");
      res.setHeader("Access-Control-Allow-Headers", "*");
      res.setHeader("Access-Control-Max-Age", "86400");

      // Prevent caching by CDN or proxy
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, private");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");

      // Handle preflight options requests
      if (req.method === "OPTIONS") {
        return res.sendStatus(200);
      }

      res.setHeader("Content-Type", "text/html; charset=UTF-8");
      return res.send(`<html lang="en"><head><meta charset="UTF-8"><title>Txt Record Title</title></head><body>zeroThreat=MTAwOTE=TVRBd09URT0=TVRBd09URT</body></html>`);
    }
    next();
  });

  // Initialize Firebase Admin & Google Drive Services
  await initFirebase();
  initDrive();

  // Middleware for JSON requests with 100MB body size limit
  app.use(express.json({ limit: '100mb' }));

  // zeroThreat Verification Routes
  const zeroThreatHandler = (req: express.Request, res: express.Response) => {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, private");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    res.setHeader("Content-Type", "text/html; charset=UTF-8");
    res.send(`<html lang="en"><head><meta charset="UTF-8"><title>Txt Record Title</title></head><body>zeroThreat=MTAwOTE=TVRBd09URT0=TVRBd09URT</body></html>`);
  };

  app.get("/zero-threat", zeroThreatHandler);
  app.get("/zero-threat.html", zeroThreatHandler);
  app.get("/zeroThreat", zeroThreatHandler);
  app.get("/zeroThreat.html", zeroThreatHandler);
  app.get("/zerothreat", zeroThreatHandler);
  app.get("/zerothreat.html", zeroThreatHandler);

  // Helper to retrieve client IP safely
  app.get('/api/ip', (req, res) => {
    let clientIp = '0.0.0.0';
    const forwarded = req.headers['x-forwarded-for'];
    if (forwarded) {
      const ipStr = Array.isArray(forwarded) ? forwarded[0] : forwarded;
      clientIp = ipStr.split(',')[0].trim();
    } else {
      clientIp = req.socket.remoteAddress || req.ip || '0.0.0.0';
    }
    res.json({ ip: clientIp });
  });

  // Download source code
  app.get("/api/download-source", async (req, res) => {
    try {
      const { createRequire } = await import("module");
      const require = createRequire(import.meta.url);
      const { ZipArchive } = require("archiver");

      res.attachment("cloud-gallery-workspace.zip");
      const archive = new ZipArchive({
        zlib: { level: 9 }
      });

      archive.on("error", (err: any) => {
        console.error("[Archiver] Archive error:", err);
        if (!res.headersSent) {
          res.status(500).send("Erro ao gerar o pacote zip.");
        }
      });

      archive.pipe(res);

      archive.glob("**/*", {
        cwd: process.cwd(),
        ignore: [
          "node_modules/**",
          "dist/**",
          "source.zip",
          "cloud-gallery-workspace.zip",
          ".git/**",
          "uploads/**",
          "dev-dist/**",
          ".env"
        ]
      });

      archive.finalize();
    } catch (err: any) {
      console.error("[DownloadSource] Error preparing zip:", err);
      if (!res.headersSent) {
        res.status(500).json({ error: err.message || "Erro desconhecido ao gerar o pacote zip." });
      }
    }
  });

  // Store for verification codes (in-memory with rate-limiting support)
  const verificationStore = new Map<string, { code: string; expiresAt: number; attempts: number; blockedUntil: number | null }>();

  // Send email verification code
  app.post("/api/auth/send-code", async (req, res) => {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: "E-mail é obrigatório" });
    }

    const emailKey = email.toLowerCase().trim();
    const existing = verificationStore.get(emailKey);

    // Check if the email is currently blocked
    if (existing && existing.blockedUntil && Date.now() < existing.blockedUntil) {
      const remainingMinutes = Math.ceil((existing.blockedUntil - Date.now()) / 60000);
      return res.json({
        success: false,
        blockedUntil: existing.blockedUntil,
        attempts: existing.attempts,
        error: `Este e-mail está temporariamente bloqueado por excesso de tentativas incorretas. Tente novamente em ${remainingMinutes} minuto(s).`
      });
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Retain previous attempts & block state if we are overwriting, unless block has expired
    const currentAttempts = (existing && existing.blockedUntil && Date.now() >= existing.blockedUntil) ? 0 : (existing ? existing.attempts : 0);
    const currentBlockedUntil = (existing && existing.blockedUntil && Date.now() >= existing.blockedUntil) ? null : (existing ? existing.blockedUntil : null);

    verificationStore.set(emailKey, {
      code,
      expiresAt: Date.now() + 10 * 60 * 1000, // 10 minutes expiry
      attempts: currentAttempts,
      blockedUntil: currentBlockedUntil
    });

    const RESEND_KEY = process.env.RESEND_API_KEY || "re_4rddSFCJ_FensYToFK9SKqPFM4znsw3AA";

    const htmlContent = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #09090b; color: #f4f4f5; padding: 40px; border-radius: 24px; max-width: 440px; margin: 0 auto; border: 1px solid rgba(255,255,255,0.08); box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);">
        <div style="text-align: center; margin-bottom: 32px;">
          <div style="width: 56px; height: 56px; background-color: rgba(255,255,255,0.04); border-radius: 16px; border: 1px solid rgba(255,255,255,0.1); box-shadow: inset 0 1px 0 rgba(255,255,255,0.1); margin: 0 auto; display: table;">
            <div style="display: table-cell; vertical-align: middle; text-align: center;">
              <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" style="display: inline-block; vertical-align: middle;">
                <path d="M20 13c0 5-3.5 7.5-7.66 9.7a1 1 0 0 1-.68 0C7.5 20.5 4 18 4 13V6a1 1 0 0 1 .76-.97l8-2a1 1 0 0 1 .48 0l8 2A1 1 0 0 1 20 6z"/>
                <path d="m9 12 2 2 4-4"/>
              </svg>
            </div>
          </div>
          <h2 style="font-size: 24px; font-weight: 800; margin-top: 16px; margin-bottom: 4px; color: #ffffff; letter-spacing: -0.025em;">Cloud Gallery</h2>
          <p style="color: #71717a; font-size: 14px; margin: 0;">Código de Verificação de Segurança</p>
        </div>
        
        <div style="background-color: rgba(255,255,255,0.01); border: 1px solid rgba(255,255,255,0.06); padding: 28px; border-radius: 20px; text-align: center; margin-bottom: 24px; box-shadow: inset 0 1px 1px rgba(255,255,255,0.02);">
          <p style="color: #a1a1aa; font-size: 14px; margin-top: 0; margin-bottom: 16px; font-weight: 500;">Seu código de confirmação é:</p>
          <div style="font-size: 38px; font-weight: 800; letter-spacing: 0.15em; color: #ffffff; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; margin: 12px 0;">${code}</div>
          <p style="color: #52525b; font-size: 12px; margin-top: 16px; margin-bottom: 0;">Válido por 10 minutos.</p>
        </div>
        
        <p style="color: #52525b; font-size: 12px; text-align: center; line-height: 1.6; margin: 0; padding: 0 10px;">
          Se você não solicitou este código, por favor ignore este e-mail. Nenhuma ação é necessária.
        </p>
      </div>
    `;

    try {
      const response = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${RESEND_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          from: "onboarding@resend.dev",
          to: [email],
          subject: `Código de Verificação: ${code}`,
          html: htmlContent
        })
      });

      const data = await response.json() as any;

      if (!response.ok) {
        console.error("[Server] Resend error:", data);
        let userFriendlyError = data.message || "Falha ao enviar e-mail. Verifique se o e-mail está autorizado no Resend Sandbox.";
        
        // Detect Resend sandbox restriction error
        if (data.message && data.message.includes("testing emails to your own email address")) {
          userFriendlyError = `Como a conta do Resend está no modo de teste (Sandbox), você só pode enviar e-mails de teste para o seu próprio e-mail cadastrado (jogonesteterp@gmail.com). Por favor, use este e-mail para testar o cadastro, ou ative um domínio próprio no Resend.`;
        } else if (data.name === "validation_error") {
          userFriendlyError = `Erro de validação no Resend: ${data.message || "Verifique se o e-mail inserido é válido e permitido."}`;
        }

        return res.json({ 
          success: false,
          error: userFriendlyError
        });
      }

      res.json({ success: true, message: "Código enviado com sucesso!" });
    } catch (err: any) {
      console.error("[Server] Failed to send email via Resend:", err);
      res.json({ success: false, error: "Erro interno do servidor ao enviar código por e-mail." });
    }
  });

  // Verify code
  app.post("/api/auth/verify-code", (req, res) => {
    const { email, code } = req.body;
    if (!email || !code) {
      return res.json({ success: false, error: "E-mail e código são obrigatórios" });
    }

    const emailKey = email.toLowerCase().trim();
    const record = verificationStore.get(emailKey);

    if (!record) {
      return res.json({ success: false, error: "Nenhum código foi solicitado para este e-mail" });
    }

    // Check if the user is currently blocked
    if (record.blockedUntil && Date.now() < record.blockedUntil) {
      const remainingMinutes = Math.ceil((record.blockedUntil - Date.now()) / 60000);
      return res.json({
        success: false,
        blockedUntil: record.blockedUntil,
        attempts: record.attempts,
        error: `Este e-mail está bloqueado por excesso de tentativas incorretas. Tente novamente em ${remainingMinutes} minuto(s).`
      });
    }

    // Check expiry
    if (Date.now() > record.expiresAt) {
      return res.json({ success: false, error: "O código de verificação expirou. Solicite um novo." });
    }

    // Check code correctness
    if (record.code !== code.trim()) {
      record.attempts += 1;
      let blockedUntil: number | null = null;
      let errorMsg = "Código de verificação incorreto.";

      if (record.attempts >= 5) {
        blockedUntil = Date.now() + 15 * 60 * 1000; // Block for 15 minutes
        record.blockedUntil = blockedUntil;
        errorMsg = "Código de verificação incorreto. Seu e-mail foi temporariamente bloqueado por 15 minutos.";
      } else if (record.attempts >= 3) {
        const remaining = 5 - record.attempts;
        errorMsg = `Código incorreto. Você tem mais ${remaining} tentativa(s) antes do seu e-mail ser bloqueado por 15 minutos.`;
      }

      verificationStore.set(emailKey, record);

      return res.json({
        success: false,
        error: errorMsg,
        attempts: record.attempts,
        blockedUntil: blockedUntil
      });
    }

    // Code is valid! Clean it up so it can't be reused, and verify success
    verificationStore.delete(emailKey);
    res.json({ success: true });
  });

  // User account migration route (migrates local file ownership from email to Google)
  app.post("/api/auth/migrate-user", async (req, res) => {
    try {
      const { oldUserId, newUserId } = req.body;
      if (!oldUserId || !newUserId) {
        return res.status(400).json({ success: false, error: "oldUserId and newUserId are required" });
      }

      const files = await fs.promises.readdir(IMAGES_DIR);
      let count = 0;
      const migratedImageIds: string[] = [];

      for (const file of files) {
        if (file.endsWith(".json")) {
          const filePath = path.join(IMAGES_DIR, file);
          try {
            const content = await fs.promises.readFile(filePath, "utf-8");
            const data = JSON.parse(content);
            if (data.userId === oldUserId) {
              data.userId = newUserId;
              await fs.promises.writeFile(filePath, JSON.stringify(data), "utf-8");
              count++;
              if (data.id) {
                migratedImageIds.push(data.id);
              }

              // Also update Google Drive backup if drive is configured
              const driveService = getDriveService();
              if (driveService) {
                const fileName = `secure_vault_image_${data.id}.json`;
                try {
                  await uploadToDrive(fileName, data);
                } catch (driveErr) {
                  console.warn(`[Migration] Failed updating Drive backup for ${data.id}:`, driveErr);
                }
              }
            }
          } catch (err) {
            console.error(`[Migration] Error migrating file ${file}:`, err);
          }
        }
      }

      console.log(`[Migration] Migrated ${count} images from ${oldUserId} to ${newUserId}`);
      res.json({ success: true, migratedCount: count, migratedImageIds });
    } catch (err: any) {
      console.error("[Migration] Error in migrate-user endpoint:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Mount API Routers
  app.use('/api/storage', storageRouter);
  app.use('/api/drive', driveRouter);
  app.use('/api/share', shareRouter);

  // Vite middleware or Static serving logic
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath, { index: false }));
    
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Server] Secure Vault server running on http://localhost:${PORT}`);
  });
}

startServer();
