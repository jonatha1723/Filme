import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand, ListObjectsV2Command } from "@aws-sdk/client-s3";

let r2ClientInstance: S3Client | null = null;

/**
 * Lazy initialization of the S3 client configured for Cloudflare R2.
 * Region is set to "auto" which is required by Cloudflare R2.
 */
export function getR2Client(): S3Client | null {
  if (r2ClientInstance) return r2ClientInstance;

  const endpoint = process.env.CLOUDFLARE_R2_ENDPOINT;
  const accessKeyId = process.env.CLOUDFLARE_R2_ACCESS_KEY_ID;
  const secretAccessKey = process.env.CLOUDFLARE_R2_SECRET_ACCESS_KEY;

  if (!endpoint || !accessKeyId || !secretAccessKey) {
    // If credentials are not set, return null gracefully rather than crashing
    return null;
  }

  try {
    r2ClientInstance = new S3Client({
      endpoint,
      credentials: {
        accessKeyId,
        secretAccessKey,
      },
      region: "auto",
    });
    console.log("[R2Client] S3Client initialized successfully for Cloudflare R2 endpoint:", endpoint);
    return r2ClientInstance;
  } catch (err) {
    console.error("[R2Client] Error initializing S3Client for R2:", err);
    return null;
  }
}

/**
 * Uploads a JSON payload or a string to a Cloudflare R2 Bucket.
 */
export async function uploadToR2(key: string, data: any, contentType: string = "application/json"): Promise<boolean> {
  const client = getR2Client();
  if (!client) return false;

  const bucket = process.env.CLOUDFLARE_R2_BUCKET_NAME || "secure-vault";
  const bodyString = typeof data === "string" ? data : JSON.stringify(data);

  try {
    const command = new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: bodyString,
      ContentType: contentType,
    });
    await client.send(command);
    console.log(`[R2Client] Uploaded successfully: ${key} to bucket ${bucket}`);
    return true;
  } catch (err) {
    console.error(`[R2Client] Error uploading ${key} to R2:`, err);
    return false;
  }
}

/**
 * Downloads a string payload from R2 and returns it. If it is JSON, it can be parsed.
 */
export async function downloadFromR2(key: string): Promise<string | null> {
  const client = getR2Client();
  if (!client) return null;

  const bucket = process.env.CLOUDFLARE_R2_BUCKET_NAME || "secure-vault";

  try {
    const command = new GetObjectCommand({
      Bucket: bucket,
      Key: key,
    });
    const response = await client.send(command);
    if (!response.Body) {
      return null;
    }
    const content = await response.Body.transformToString();
    return content;
  } catch (err: any) {
    if (err.name === "NoSuchKey") {
      console.log(`[R2Client] File not found in R2: ${key}`);
    } else {
      console.error(`[R2Client] Error downloading ${key} from R2:`, err);
    }
    return null;
  }
}

/**
 * Deletes an object from Cloudflare R2.
 */
export async function deleteFromR2(key: string): Promise<boolean> {
  const client = getR2Client();
  if (!client) return false;

  const bucket = process.env.CLOUDFLARE_R2_BUCKET_NAME || "secure-vault";

  try {
    const command = new DeleteObjectCommand({
      Bucket: bucket,
      Key: key,
    });
    await client.send(command);
    console.log(`[R2Client] Deleted successfully from R2: ${key}`);
    return true;
  } catch (err) {
    console.error(`[R2Client] Error deleting ${key} from R2:`, err);
    return false;
  }
}

/**
 * Lists keys in the bucket, optionally filtered by a prefix.
 */
export async function listKeysFromR2(prefix?: string): Promise<string[]> {
  const client = getR2Client();
  if (!client) return [];

  const bucket = process.env.CLOUDFLARE_R2_BUCKET_NAME || "secure-vault";

  try {
    const command = new ListObjectsV2Command({
      Bucket: bucket,
      Prefix: prefix,
    });
    const response = await client.send(command);
    if (response.Contents) {
      return response.Contents.map(item => item.Key || "").filter(Boolean);
    }
    return [];
  } catch (err) {
    console.error(`[R2Client] Error listing keys from R2:`, err);
    return [];
  }
}
