import express from "express";
import { findExistingShare, createShare, deleteShare, viewShare } from "./shareService";

const router = express.Router();

// 1. Find existing share for an image
router.get('/image/:imageId', findExistingShare);

// 2. Create or Update share
router.post('/create', createShare);

// 3. Delete/Cancel share link
router.delete('/:shareId', deleteShare);

// 4. Public secure view for share links
router.get('/view/:shareId', viewShare);

export default router;
