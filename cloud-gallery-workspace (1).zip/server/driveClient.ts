import { google } from "googleapis";

let driveService: any = null;

export function initDrive() {
  const clientId = process.env.GOOGLE_DRIVE_CLIENT_ID || "2191174521-vvnqmlt5cna4mc3mdc86pe16ofutdnqn.apps.googleusercontent.com";
  const clientSecret = process.env.GOOGLE_DRIVE_CLIENT_SECRET || "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";
  const refreshToken = process.env.GOOGLE_DRIVE_REFRESH_TOKEN || "1//040q_ML-dNxbZCgYIARAAGAQSNwF-L9IrHJigoszIZYUsbWMNwy5SxFXZUlvWemLBvfr_RJLqvW4Vn3lZ5ISg50eoB8aUau50eXM";

  if (clientId && clientSecret && refreshToken) {
    try {
      const oauth2Client = new google.auth.OAuth2(clientId, clientSecret, "https://developers.google.com/oauthplayground");
      oauth2Client.setCredentials({ refresh_token: refreshToken });
      driveService = google.drive({ version: 'v3', auth: oauth2Client });
      console.log('[Server] Google Drive initialized successfully');
    } catch (e) {
      console.error('[Server] Failed to init Google Drive:', e);
    }
  }
}

export function getDriveService() {
  return driveService;
}

export async function uploadToDrive(fileName: string, content: any): Promise<string | null> {
  if (!driveService) return null;
  try {
    const listRes = await driveService.files.list({
      q: `name = '${fileName}' and trashed = false`,
      fields: 'files(id)',
      spaces: 'drive',
      pageSize: 1
    });

    const fileMetadata = {
      name: fileName,
      mimeType: 'application/json'
    };

    const media = {
      mimeType: 'application/json',
      body: typeof content === 'string' ? content : JSON.stringify(content)
    };

    if (listRes.data.files && listRes.data.files.length > 0) {
      const fileId = listRes.data.files[0].id;
      const updateRes = await driveService.files.update({
        fileId: fileId,
        media: media,
        fields: 'id'
      });
      console.log(`[Drive] File updated: ${fileName} (${fileId})`);
      return fileId;
    } else {
      const driveRes = await driveService.files.create({
        requestBody: fileMetadata,
        media: media,
        fields: 'id'
      });
      console.log(`[Drive] New file created to Drive: ${fileName} (${driveRes.data.id})`);
      return driveRes.data.id;
    }
  } catch (err) {
    console.warn(`[Drive] Failed upload to Drive for ${fileName}:`, err);
    return null;
  }
}

export async function downloadFromDriveByName(fileName: string): Promise<any | null> {
  if (!driveService) return null;
  try {
    const listRes = await driveService.files.list({
      q: `name = '${fileName}' and trashed = false`,
      fields: 'files(id)',
      spaces: 'drive',
      pageSize: 1
    });

    if (!listRes.data.files || listRes.data.files.length === 0) {
      return null;
    }

    const fileId = listRes.data.files[0].id;
    const downloadRes = await driveService.files.get({
      fileId: fileId,
      alt: 'media'
    });

    return downloadRes.data;
  } catch (err) {
    console.warn(`[Drive] Failed download from Drive for ${fileName}:`, err);
    return null;
  }
}

export async function deleteFromDriveByName(fileName: string): Promise<void> {
  if (!driveService) return;
  try {
    const listRes = await driveService.files.list({
      q: `name = '${fileName}' and trashed = false`,
      fields: 'files(id)',
      spaces: 'drive',
      pageSize: 10
    });

    if (listRes.data.files && listRes.data.files.length > 0) {
      for (const file of listRes.data.files) {
        await driveService.files.delete({ fileId: file.id });
        console.log(`[Drive] Deleted file from Drive: ${fileName} (${file.id})`);
      }
    }
  } catch (err) {
    console.warn(`[Drive] Failed delete from Drive for ${fileName}:`, err);
  }
}
