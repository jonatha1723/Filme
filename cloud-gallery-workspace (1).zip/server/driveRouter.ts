import express from "express";
import { getDriveService } from "./driveClient";

const router = express.Router();

// Direct API Route for Google Drive Upload backup
router.post('/upload', async (req, res) => {
  const driveService = getDriveService();
  if (!driveService) {
    return res.status(500).json({ success: false, error: 'Google Drive not configured' });
  }
  try {
    const { id, ciphertext, iv, createdAt } = req.body;
    if (!id || !ciphertext || !iv) {
      return res.status(400).json({ success: false, error: 'Missing data' });
    }

    const fileMetadata = {
      name: `secure_vault_image_${id}.json`,
      mimeType: 'application/json'
    };

    const media = {
      mimeType: 'application/json',
      body: JSON.stringify({ id, ciphertext, iv, createdAt })
    };

    const driveRes = await driveService.files.create({
      requestBody: fileMetadata,
      media: media,
      fields: 'id'
    });

    res.json({ success: true, fileId: driveRes.data.id });
  } catch (error: any) {
    console.error('[DriveRouter] Error uploading to Drive:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

export default router;
