import path from "path";
import fs from "node:fs/promises";
import { getDriveService } from "./driveClient";
import { getR2Client, downloadFromR2, listKeysFromR2 } from "./r2Client";

export const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
export const IMAGES_DIR = path.resolve(UPLOADS_DIR, 'images');

export async function ensureDir() {
  try {
    await fs.mkdir(IMAGES_DIR, { recursive: true });
  } catch (err) {
    console.error('[StorageController] Failed to create images directory:', err);
  }
}

export async function recoverFromDrive(userId: string, localIds: Set<string>) {
  const driveService = getDriveService();
  if (!driveService) return;
  try {
    const listRes = await driveService.files.list({
      q: "name contains 'secure_vault_image_' and trashed = false",
      fields: 'files(id, name)',
      spaces: 'drive',
      pageSize: 100
    });

    if (listRes.data.files && listRes.data.files.length > 0) {
      const promises = listRes.data.files.map(async (file) => {
        const fileName = file.name || '';
        const googleFileId = file.id;
        if (fileName.startsWith('secure_vault_image_') && fileName.endsWith('.json')) {
          const imageId = fileName.substring('secure_vault_image_'.length, fileName.length - 5);
          if (!localIds.has(imageId)) {
            console.log(`[Drive Auto-Recovery] Restoring missing file from Drive: ${fileName}`);
            try {
              const downloadRes = await driveService.files.get({
                fileId: googleFileId,
                alt: 'media'
              });
              
              const fileContent = typeof downloadRes.data === 'string' ? downloadRes.data : JSON.stringify(downloadRes.data);
              const parsed = JSON.parse(fileContent);
              
              if (parsed.userId === userId) {
                const destPath = path.join(IMAGES_DIR, `${imageId}.json`);
                await fs.writeFile(destPath, fileContent, 'utf-8');
                localIds.add(imageId);
                console.log(`[Drive Auto-Recovery] Restored local file: ${imageId}`);
              }
            } catch (dlErr) {
              console.error(`[Drive Auto-Recovery] Failed to restore file ${imageId}:`, dlErr);
            }
          }
        }
      });
      await Promise.all(promises);
    }
  } catch (driveSyncErr) {
    console.warn('[Drive Auto-Recovery] Skipped Google Drive query sync:', driveSyncErr);
  }
}

export async function recoverFromR2(userId: string, localIds: Set<string>) {
  const r2Client = getR2Client();
  if (!r2Client) return;

  try {
    const keys = await listKeysFromR2("images/");
    const promises = keys.map(async (key) => {
      if (key.startsWith("images/") && key.endsWith(".json")) {
        const imageId = key.substring("images/".length, key.length - 5);
        if (!localIds.has(imageId)) {
          console.log(`[R2 Auto-Recovery] Restoring missing file from R2: ${key}`);
          try {
            const fileContent = await downloadFromR2(key);
            if (fileContent) {
              const parsed = JSON.parse(fileContent);
              if (parsed.userId === userId) {
                const destPath = path.join(IMAGES_DIR, `${imageId}.json`);
                await fs.writeFile(destPath, fileContent, "utf-8");
                localIds.add(imageId);
                console.log(`[R2 Auto-Recovery] Restored local file from R2: ${imageId}`);
              }
            }
          } catch (dlErr) {
            console.error(`[R2 Auto-Recovery] Failed to restore file ${imageId} from R2:`, dlErr);
          }
        }
      }
    });
    await Promise.all(promises);
  } catch (r2SyncErr) {
    console.warn("[R2 Auto-Recovery] Skipped R2 list sync:", r2SyncErr);
  }
}
