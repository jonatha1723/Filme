import { Request, Response } from "express";
import path from "path";
import fs from "node:fs/promises";
import { getDB } from "./firebaseAdmin";
import { getDriveService, uploadToDrive, downloadFromDriveByName, deleteFromDriveByName } from "./driveClient";
import { IMAGES_DIR } from "./storageHelpers";
import { getR2Client, uploadToR2, downloadFromR2, deleteFromR2, listKeysFromR2 } from "./r2Client";

const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
const SHARES_DIR = path.resolve(UPLOADS_DIR, 'shares');

// Verifies if the image still exists in the local file system, Google Drive, or Cloudflare R2
async function checkImageExists(imageId: string): Promise<boolean> {
  if (!imageId) return false;
  const localPath = path.join(IMAGES_DIR, `${imageId}.json`);
  try {
    await fs.access(localPath);
    return true;
  } catch (e) {}

  // If local not found, check Google Drive
  const driveService = getDriveService();
  if (driveService) {
    try {
      const listRes = await driveService.files.list({
        q: `name = 'secure_vault_image_${imageId}.json' and trashed = false`,
        fields: 'files(id)',
        spaces: 'drive',
        pageSize: 1
      });
      if (listRes.data.files && listRes.data.files.length > 0) {
        return true;
      }
    } catch (e) {}
  }

  // If still not found, check Cloudflare R2
  try {
    const r2Data = await downloadFromR2(`images/${imageId}.json`);
    if (r2Data) {
      return true;
    }
  } catch (e) {}

  return false;
}

// Purges all shares associated with a deleted image
export async function deleteSharesForImage(imageId: string) {
  try {
    const driveService = getDriveService();
    const db = getDB();

    // 1. Delete from Firestore
    if (db) {
      try {
        const snapshot = await db.collection('shares').where('imageId', '==', imageId).get();
        if (!snapshot.empty) {
          const promises = snapshot.docs.map(doc => doc.ref.delete());
          await Promise.all(promises);
          console.log(`[ShareService] Deleted ${snapshot.size} shares from Firestore for image ${imageId}`);
        }
      } catch (err) {
        console.error('[ShareService] Error deleting shares from Firestore for image:', imageId, err);
      }
    }

    // 2. Delete from local folder and Google Drive
    let localFiles: string[] = [];
    try {
      localFiles = await fs.readdir(SHARES_DIR);
    } catch (e) {
      localFiles = [];
    }

    for (const file of localFiles) {
      if (file.endsWith('.json')) {
        try {
          const filePath = path.join(SHARES_DIR, file);
          const content = await fs.readFile(filePath, 'utf-8');
          const data = JSON.parse(content);
          if (data.imageId === imageId) {
            const shareId = data.id;
            // Delete local file
            await fs.unlink(filePath);
            console.log(`[ShareService] Deleted local share ${shareId} for image ${imageId}`);
            // Delete from Drive
            if (driveService) {
              await deleteFromDriveByName(`secure_vault_share_${shareId}.json`);
            }
            // Delete from Cloudflare R2
            try {
              await deleteFromR2(`shares/${shareId}.json`);
            } catch (e) {}
          }
        } catch (e) {
          console.error('[ShareService] Parse or delete error during share purge:', file, e);
        }
      }
    }
  } catch (err) {
    console.error('[ShareService] Error in deleteSharesForImage:', err);
  }
}

// Ensure local directory
async function ensureDir() {
  try {
    await fs.mkdir(SHARES_DIR, { recursive: true });
  } catch (err) {
    console.error('[ShareService] Failed to create shares directory:', err);
  }
}
ensureDir();

// 1. Find existing share for an image
export async function findExistingShare(req: Request, res: Response) {
  try {
    const { imageId } = req.params;
    
    // Search local folder
    let localFiles: string[] = [];
    try {
      localFiles = await fs.readdir(SHARES_DIR);
    } catch (e) {
      await fs.mkdir(SHARES_DIR, { recursive: true });
      localFiles = [];
    }

    for (const file of localFiles) {
      if (file.endsWith('.json')) {
        try {
          const filePath = path.join(SHARES_DIR, file);
          const content = await fs.readFile(filePath, 'utf-8');
          const data = JSON.parse(content);
          if (data.imageId === imageId) {
            return res.json({ success: true, share: data });
          }
        } catch (e) {
          console.error('[ShareService] Parse error local file:', file, e);
        }
      }
    }

    // Search Google Drive
    const driveService = getDriveService();
    if (driveService) {
      try {
        const listRes = await driveService.files.list({
          q: `name contains 'secure_vault_share_' and trashed = false`,
          fields: 'files(id, name)',
          spaces: 'drive',
          pageSize: 100
        });

        if (listRes.data.files && listRes.data.files.length > 0) {
          for (const file of listRes.data.files) {
            const fileName = file.name || '';
            const googleFileId = file.id;
            try {
              const downloadRes = await driveService.files.get({
                fileId: googleFileId,
                alt: 'media'
              });
              const fileContent = typeof downloadRes.data === 'string' ? downloadRes.data : JSON.stringify(downloadRes.data);
              const parsed = JSON.parse(fileContent);
              if (parsed.imageId === imageId) {
                const filePath = path.join(SHARES_DIR, `${parsed.id}.json`);
                await fs.writeFile(filePath, fileContent, 'utf-8');
                return res.json({ success: true, share: parsed });
              }
            } catch (e) {
              console.error('[ShareService] Error parsing Drive share:', e);
            }
          }
        }
      } catch (driveErr) {
        console.warn('[ShareService] Drive search skipped:', driveErr);
      }
    }

    // Search Cloudflare R2
    try {
      const keys = await listKeysFromR2("shares/");
      for (const key of keys) {
        if (key.startsWith("shares/") && key.endsWith(".json")) {
          const r2Content = await downloadFromR2(key);
          if (r2Content) {
            const parsed = JSON.parse(r2Content);
            if (parsed.imageId === imageId) {
              const filePath = path.join(SHARES_DIR, `${parsed.id}.json`);
              await fs.writeFile(filePath, r2Content, 'utf-8');
              return res.json({ success: true, share: parsed });
            }
          }
        }
      }
    } catch (r2Err) {
      console.warn('[ShareService] R2 share search skipped:', r2Err);
    }

    // Search Firestore
    const db = getDB();
    if (db) {
      try {
        const sharesRef = db.collection('shares');
        const snapshot = await sharesRef.where('imageId', '==', imageId).limit(1).get();
        if (!snapshot.empty) {
          const shareDoc = snapshot.docs[0];
          return res.json({ success: true, share: { id: shareDoc.id, ...shareDoc.data() } });
        }
      } catch (fsErr) {
        console.warn('[ShareService] Firestore fallback failed:', fsErr);
      }
    }

    return res.json({ success: true, share: null });
  } catch (err: any) {
    console.error('[ShareService] Error finding share:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
}

// 2. Create or Update share
export async function createShare(req: Request, res: Response) {
  try {
    const { id, imageId, userId, ciphertext, iv, options } = req.body;
    if (!id || !imageId || !ciphertext || !iv) {
      return res.status(400).json({ success: false, error: 'Missing data' });
    }

    const shareData = {
      id,
      imageId,
      userId: userId || null,
      ciphertext,
      iv,
      isChunked: req.body.isChunked || false,
      chunkCount: req.body.chunkCount || 1,
      contentType: req.body.contentType || 'image/png',
      totalSize: req.body.totalSize || 0,
      options: {
        requirePassword: !!options.requirePassword,
        encryptedShareKey: options.encryptedShareKey || null,
        ivShareKey: options.ivShareKey || null,
        allowDownload: options.allowDownload !== false,
        oneTimeView: !!options.oneTimeView,
        expiresAt: options.expiresAt || null
      },
      createdAt: Date.now(),
      firstViewedAt: null,
      firstViewerIp: null
    };

    const filePath = path.join(SHARES_DIR, `${id}.json`);
    await fs.writeFile(filePath, JSON.stringify(shareData), 'utf-8');

    const driveService = getDriveService();
    if (driveService) {
      try {
        await uploadToDrive(`secure_vault_share_${id}.json`, shareData);
      } catch (e) {
        console.error('[ShareService] Drive upload fail:', e);
      }
    }

    const db = getDB();
    if (db) {
      try {
        const docData = { ...shareData, ciphertext: ciphertext.length < 750 * 1024 ? ciphertext : '' };
        await db.collection('shares').doc(id).set(docData);
      } catch (e) {
        console.warn('[ShareService] Firestore save fail:', e);
      }
    }

    // Upload to Cloudflare R2 S3 storage
    try {
      await uploadToR2(`shares/${id}.json`, shareData);
    } catch (e) {
      console.error('[ShareService] R2 upload fail:', e);
    }

    res.json({ success: true, share: shareData });
  } catch (err: any) {
    console.error('[ShareService] Error creating share:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

// 3. Delete share
export async function deleteShare(req: Request, res: Response) {
  try {
    const { shareId } = req.params;
    const filePath = path.join(SHARES_DIR, `${shareId}.json`);
    
    try {
      await fs.unlink(filePath);
    } catch (e) {}

    const driveService = getDriveService();
    if (driveService) {
      try {
        await deleteFromDriveByName(`secure_vault_share_${shareId}.json`);
      } catch (e) {}
    }

    const db = getDB();
    if (db) {
      try {
        await db.collection('shares').doc(shareId).delete();
      } catch (e) {}
    }

    // Delete from Cloudflare R2
    try {
      await deleteFromR2(`shares/${shareId}.json`);
    } catch (e) {}

    res.json({ success: true });
  } catch (err: any) {
    console.error('[ShareService] Error deleting share:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

// 4. View share
export async function viewShare(req: Request, res: Response) {
  try {
    const { shareId } = req.params;
    const filePath = path.join(SHARES_DIR, `${shareId}.json`);
    
    const driveService = getDriveService();
    const db = getDB();

    // 1. If Firestore is active, it is the absolute source of truth for share existence.
    // This prevents stale files or async Google Drive index lag from restoring deleted shares.
    if (db) {
      try {
        const docSnap = await db.collection('shares').doc(shareId).get();
        if (!docSnap.exists) {
          console.log(`[ShareService] Share ${shareId} has been explicitly deleted according to Firestore.`);
          // Clean up stale or async files immediately
          try { await fs.unlink(filePath); } catch (e) {}
          if (driveService) { try { await deleteFromDriveByName(`secure_vault_share_${shareId}.json`); } catch (e) {} }
          try { await deleteFromR2(`shares/${shareId}.json`); } catch (e) {}
          return res.status(404).json({ success: false, error: 'Link de compartilhamento inválido ou expirado.' });
        }
      } catch (e) {
        console.warn('[ShareService] Firestore state check skipped:', e);
      }
    }

    let shareData: any = null;

    try {
      const content = await fs.readFile(filePath, 'utf-8');
      shareData = JSON.parse(content);
    } catch (err) {
      if (driveService) {
        try {
          const driveData = await downloadFromDriveByName(`secure_vault_share_${shareId}.json`);
          if (driveData) {
            shareData = typeof driveData === 'string' ? JSON.parse(driveData) : driveData;
            await fs.writeFile(filePath, JSON.stringify(shareData), 'utf-8');
          }
        } catch (e) {}
      }

      // Try reading from Cloudflare R2
      if (!shareData) {
        try {
          const r2Data = await downloadFromR2(`shares/${shareId}.json`);
          if (r2Data) {
            shareData = JSON.parse(r2Data);
            await fs.writeFile(filePath, r2Data, 'utf-8');
          }
        } catch (e) {}
      }

      if (!shareData && db) {
        try {
          const docSnap = await db.collection('shares').doc(shareId).get();
          if (docSnap.exists) {
            shareData = docSnap.data();
          }
        } catch (e) {}
      }
    }

    if (!shareData) {
      return res.status(404).json({ success: false, error: 'Link de compartilhamento inválido ou expirado.' });
    }

    // 2. Anti-bypass protection: Verify that the parent image STILL exists in the vault.
    // If the image was deleted, any sharing links associated with it MUST be invalidated and purged immediately.
    const imageExists = await checkImageExists(shareData.imageId);
    if (!imageExists) {
      console.log(`[ShareService] Parent image ${shareData.imageId} not found. Purging orphan share ${shareId}.`);
      try { await fs.unlink(filePath); } catch (e) {}
      if (driveService) { try { await deleteFromDriveByName(`secure_vault_share_${shareId}.json`); } catch (e) {} }
      if (db) { try { await db.collection('shares').doc(shareId).delete(); } catch (e) {} }
      try { await deleteFromR2(`shares/${shareId}.json`); } catch (e) {}
      return res.status(404).json({ success: false, error: 'Link de compartilhamento inválido ou expirado.' });
    }

    const now = Date.now();
    if (shareData.options?.expiresAt && now > shareData.options.expiresAt) {
      try { await fs.unlink(filePath); } catch (e) {}
      if (driveService) { try { await deleteFromDriveByName(`secure_vault_share_${shareId}.json`); } catch (e) {} }
      if (db) { try { await db.collection('shares').doc(shareId).delete(); } catch (e) {} }
      try { await deleteFromR2(`shares/${shareId}.json`); } catch (e) {}
      return res.status(410).json({ success: false, error: 'Este link de compartilhamento expirou (limite de 1 hora).' });
    }

    const forwarded = req.headers['x-forwarded-for'];
    const clientIp = (forwarded ? (Array.isArray(forwarded) ? forwarded[0] : forwarded) : '').split(',')[0].trim() || req.socket.remoteAddress || req.ip || '0.0.0.0';

    if (shareData.options?.oneTimeView) {
      if (!shareData.firstViewedAt) {
        shareData.firstViewedAt = now;
        shareData.firstViewerIp = clientIp;
        await fs.writeFile(filePath, JSON.stringify(shareData), 'utf-8');
        if (driveService) { try { await uploadToDrive(`secure_vault_share_${shareId}.json`, shareData); } catch (e) {} }
        try { await uploadToR2(`shares/${shareId}.json`, shareData); } catch (e) {}
        if (db) {
          try {
            await db.collection('shares').doc(shareId).update({ firstViewedAt: now, firstViewerIp: clientIp });
          } catch (e) {}
        }
      } else {
        if ((now - shareData.firstViewedAt) / 1000 > 60) {
          try { await fs.unlink(filePath); } catch (e) {}
          if (driveService) { try { await deleteFromDriveByName(`secure_vault_share_${shareId}.json`); } catch (e) {} }
          if (db) { try { await db.collection('shares').doc(shareId).delete(); } catch (e) {} }
          try { await deleteFromR2(`shares/${shareId}.json`); } catch (e) {}
          return res.status(403).json({ success: false, error: 'Esta visualização única expirou. O limite de 1 minuto foi atingido e o arquivo foi excluído permanentemente.' });
        }
        if (shareData.firstViewerIp && shareData.firstViewerIp !== clientIp) {
          return res.status(403).json({ success: false, error: 'Acesso bloqueado: Este link de visualização única está travado no dispositivo inicial.' });
        }
      }
    }

    return res.json({
      success: true,
      share: {
        id: shareData.id || shareId,
        imageId: shareData.imageId,
        userId: shareData.userId,
        ciphertext: shareData.ciphertext,
        iv: shareData.iv,
        isChunked: shareData.isChunked || false,
        chunkCount: shareData.chunkCount || 1,
        contentType: shareData.contentType || 'image/png',
        totalSize: shareData.totalSize || 0,
        options: {
          requirePassword: shareData.options.requirePassword,
          encryptedShareKey: shareData.options.encryptedShareKey,
          ivShareKey: shareData.options.ivShareKey,
          allowDownload: shareData.options.allowDownload,
          oneTimeView: shareData.options.oneTimeView,
          expiresAt: shareData.options.expiresAt
        },
        firstViewedAt: shareData.firstViewedAt,
        clientIp
      }
    });
  } catch (err: any) {
    console.error('[ShareService] Error holding view share:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}
