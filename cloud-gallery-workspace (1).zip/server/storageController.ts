import express from "express";
import path from "path";
import fs from "node:fs/promises";
import { getDriveService, uploadToDrive, downloadFromDriveByName, deleteFromDriveByName } from "./driveClient";
import { IMAGES_DIR, ensureDir, recoverFromDrive, recoverFromR2 } from "./storageHelpers";
import { deleteSharesForImage } from "./shareService";
import { uploadToR2, downloadFromR2, deleteFromR2 } from "./r2Client";

const router = express.Router();

ensureDir();

// 1. Get all image metadata for a user (with self-healing from Google Drive and Firestore)
router.get('/images', async (req, res) => {
  try {
    const { userId } = req.query;
    if (!userId || typeof userId !== 'string') {
      return res.status(400).json({ success: false, error: 'userId parameter is required' });
    }

    let localFiles: string[] = [];
    try {
      localFiles = await fs.readdir(IMAGES_DIR);
    } catch (e) {
      await fs.mkdir(IMAGES_DIR, { recursive: true });
      localFiles = [];
    }
    
    const localIds = new Set(localFiles.filter(f => f.endsWith('.json')).map(f => f.slice(0, -5)));

    // Sync and recover missing files from Google Drive and R2 before reading the directory
    try {
      await recoverFromDrive(userId, localIds);
    } catch (err) {
      console.warn('[StorageController] Drive recovery error:', err);
    }

    try {
      await recoverFromR2(userId, localIds);
    } catch (err) {
      console.warn('[StorageController] R2 recovery error:', err);
    }

    // Re-read local directory to obtain full list
    const files = await fs.readdir(IMAGES_DIR);
    const images: any[] = [];

    for (const file of files) {
      if (file.endsWith('.json')) {
        try {
          const filePath = path.join(IMAGES_DIR, file);
          const content = await fs.readFile(filePath, 'utf-8');
          
          // Otimização: pular parse de arquivos que nitidamente não pertencem ao usuário atual
          if (!content.includes(`"userId":"${userId}"`) && !content.includes(`"userId": "${userId}"`)) {
            continue;
          }

          const data = JSON.parse(content);
          if (data.userId === userId && !data.isProtected) {
            images.push({
              id: data.id,
              createdAt: data.createdAt || Date.now(),
              userId: data.userId,
              contentType: data.contentType || 'image/png',
              totalSize: data.totalSize || 0,
              isChunked: data.isChunked || false,
              chunkCount: data.chunkCount || 1,
              thumbnailCiphertext: data.thumbnailCiphertext || '',
              thumbnailIv: data.thumbnailIv || '',
              fileKeyCiphertext: data.fileKeyCiphertext,
              fileKeyIv: data.fileKeyIv,
              fileSalt: data.fileSalt,
              iv: data.iv
            });
          }
        } catch (parseErr) {
          console.error('[StorageController] Skip parsing invalid image JSON file:', file);
        }
      }
    }

    images.sort((a, b) => b.createdAt - a.createdAt);
    res.json({ success: true, images });
  } catch (err: any) {
    console.error('[StorageController] Error listing local images:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/protected-images', async (req, res) => {
  try {
    const userId = req.query.userId as string;
    if (!userId) {
      return res.status(400).json({ success: false, error: 'userId parameter is required' });
    }

    let localFiles: string[] = [];
    try {
      localFiles = await fs.readdir(IMAGES_DIR);
    } catch (_) {
      await fs.mkdir(IMAGES_DIR, { recursive: true });
      localFiles = [];
    }

    const localIds = new Set(localFiles.filter(f => f.endsWith('.json')).map(f => f.slice(0, -5)));

    // Sync and recover missing files from Google Drive and R2 before reading the directory
    try {
      await recoverFromDrive(userId, localIds);
    } catch (err) {
      console.warn('[StorageController] Drive recovery error for protected-images:', err);
    }

    try {
      await recoverFromR2(userId, localIds);
    } catch (err) {
      console.warn('[StorageController] R2 recovery error for protected-images:', err);
    }

    const files = await fs.readdir(IMAGES_DIR);
    const images: any[] = [];

    for (const file of files) {
      if (file.endsWith('.json')) {
        try {
          const filePath = path.join(IMAGES_DIR, file);
          const content = await fs.readFile(filePath, 'utf-8');
          
          if (!content.includes(`"userId":"${userId}"`) && !content.includes(`"userId": "${userId}"`)) {
            continue;
          }

          const data = JSON.parse(content);
          if (data.userId === userId && data.isProtected) {
            images.push({
              id: data.id,
              createdAt: data.createdAt || Date.now(),
              userId: data.userId,
              contentType: data.contentType || 'image/png',
              totalSize: data.totalSize || 0,
              isChunked: data.isChunked || false,
              chunkCount: data.chunkCount || 1,
              thumbnailCiphertext: data.thumbnailCiphertext || '',
              thumbnailIv: data.thumbnailIv || '',
              fileKeyCiphertext: data.fileKeyCiphertext,
              fileKeyIv: data.fileKeyIv,
              fileSalt: data.fileSalt,
              iv: data.iv
            });
          }
        } catch (parseErr) {
          console.error('[StorageController] Skip parsing invalid image JSON file:', file);
        }
      }
    }

    images.sort((a, b) => b.createdAt - a.createdAt);
    res.json({ success: true, images });
  } catch (err: any) {
    console.error('[StorageController] Error listing local protected images:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 2. Upload/Save full un-chunked image or video file
router.post('/upload', async (req, res) => {
  try {
    const { id, userId, ciphertext, iv, contentType, totalSize, thumbnailCiphertext, thumbnailIv, isChunked, chunkCount, isProtected, fileKeyCiphertext, fileKeyIv, fileSalt, createdAt } = req.body;
    if (!id || !userId || !ciphertext || !iv) {
      return res.status(400).json({ success: false, error: 'Missing required media parameters' });
    }
    if (!/^[a-zA-Z0-9_-]+$/.test(id)) {
      return res.status(400).json({ success: false, error: 'Invalid ID format' });
    }

    const fileData = {
      id,
      userId,
      ciphertext,
      iv,
      contentType,
      totalSize,
      isChunked: isChunked || false,
      chunkCount: chunkCount || 1,
      thumbnailCiphertext,
      thumbnailIv,
      fileKeyCiphertext,
      fileKeyIv,
      fileSalt,
      isProtected: isProtected || false,
      createdAt: createdAt || Date.now()
    };

    // A. Write to fast local storage cache
    const filePath = path.join(IMAGES_DIR, `${id}.json`);
    await fs.writeFile(filePath, JSON.stringify(fileData), 'utf-8');

    // B. Write to Google Drive for permanent backup
    const driveService = getDriveService();
    if (driveService) {
      const fileName = `secure_vault_image_${id}.json`;
      try {
        await uploadToDrive(fileName, fileData);
        console.log(`[StorageController] Image ${id} backed up securely to Google Drive.`);
      } catch (driveErr) {
        console.error(`[StorageController] Google Drive backup failed for ${id}:`, driveErr);
      }
    }

    // C. Write to Cloudflare R2 for redundant cloud storage
    try {
      await uploadToR2(`images/${id}.json`, fileData);
    } catch (r2Err) {
      console.error(`[StorageController] Cloudflare R2 upload failed for ${id}:`, r2Err);
    }

    res.json({ success: true, image: fileData });
  } catch (err: any) {
    console.error('[StorageController] Error saving local upload:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. Get single full un-chunked image/video data
router.get('/image/:id', async (req, res) => {
  try {
    const { id } = req.params;
    if (!id || !/^[a-zA-Z0-9_-]+$/.test(id)) {
      return res.status(400).json({ success: false, error: 'Invalid ID format' });
    }
    const filePath = path.join(IMAGES_DIR, `${id}.json`);
    
    try {
      const content = await fs.readFile(filePath, 'utf-8');
      const data = JSON.parse(content);
      return res.json({ success: true, image: data });
    } catch (err) {
      console.log(`[StorageController] Local file ${id} is missing. Restoring from Cloud...`);
      const driveService = getDriveService();

      if (driveService) {
        try {
          const driveData = await downloadFromDriveByName(`secure_vault_image_${id}.json`);
          if (driveData) {
            const fileContent = typeof driveData === 'string' ? driveData : JSON.stringify(driveData);
            await fs.writeFile(filePath, fileContent, 'utf-8');
            const parsed = JSON.parse(fileContent);
            return res.json({ success: true, image: parsed });
          }
        } catch (driveRestoreErr) {
          console.error(`[StorageController] Failed restoring image ${id} from Drive:`, driveRestoreErr);
        }
      }

      // Try self-healing recovery from Cloudflare R2 S3 storage
      try {
        const r2Data = await downloadFromR2(`images/${id}.json`);
        if (r2Data) {
          await fs.writeFile(filePath, r2Data, 'utf-8');
          const parsed = JSON.parse(r2Data);
          return res.json({ success: true, image: parsed });
        }
      } catch (r2RestoreErr) {
        console.error(`[StorageController] Failed restoring image ${id} from Cloudflare R2:`, r2RestoreErr);
      }

      res.status(404).json({ success: false, error: 'Mídia não encontrada localmente, no Google Drive, nem no Cloudflare R2' });
    }
  } catch (err: any) {
    console.error('[StorageController] Error fetching image:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Delete single image/video file
router.delete('/image/:id', async (req, res) => {
  try {
    const { id } = req.params;
    if (!id || !/^[a-zA-Z0-9_-]+$/.test(id)) {
      return res.status(400).json({ success: false, error: 'Invalid ID format' });
    }
    const filePath = path.join(IMAGES_DIR, `${id}.json`);
    
    try {
      await fs.unlink(filePath);
    } catch (e) {}

    const driveService = getDriveService();
    if (driveService) {
      try {
        await deleteFromDriveByName(`secure_vault_image_${id}.json`);
      } catch (driveDelErr) {
        console.error(`[StorageController] Failed to purge ${id} from Google Drive:`, driveDelErr);
      }
    }

    // Delete from Cloudflare R2
    try {
      await deleteFromR2(`images/${id}.json`);
    } catch (r2DelErr) {
      console.error(`[StorageController] Failed to purge ${id} from Cloudflare R2:`, r2DelErr);
    }

    // Purge any sharing links associated with this image to prevent any further access
    try {
      await deleteSharesForImage(id);
    } catch (sharePurgeErr) {
      console.error(`[StorageController] Failed to purge associated shares for image ${id}:`, sharePurgeErr);
    }

    res.json({ success: true });
  } catch (err: any) {
    console.error('[StorageController] Error deleting image:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
