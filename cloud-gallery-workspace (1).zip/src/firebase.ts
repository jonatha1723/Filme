import { initializeApp } from 'firebase/app';
import { initializeAuth, browserLocalPersistence, browserPopupRedirectResolver } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// 1. New user-provided Firebase configuration (Primary)
const newFirebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyB66ZqvvC3-TZoqvOUqPusY2IGMitx5ZS8",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "gen-lang-client-0718492200.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "gen-lang-client-0718492200",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "gen-lang-client-0718492200.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "552951184679",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:552951184679:web:2dadc140f51f2fafaffd02"
};

// Initialize Primary Apps (New Database)
const appPrimary = initializeApp(newFirebaseConfig, 'primary');

// Use initializeAuth for more explicit control in iframe environments
export const authPrimary = initializeAuth(appPrimary, {
  persistence: browserLocalPersistence,
  popupRedirectResolver: browserPopupRedirectResolver,
});

export const dbPrimary = getFirestore(appPrimary, '(default)');

