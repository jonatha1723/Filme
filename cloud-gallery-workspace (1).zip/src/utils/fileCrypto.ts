import { encryptData, decryptData, deriveKey, generateSalt } from './crypto';

// Generates a random 15-character key using letters, numbers, and specific symbols.
export function generateFileKey(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789#$%!';
  let key = '';
  const array = new Uint32Array(15);
  window.crypto.getRandomValues(array);
  for (let i = 0; i < 15; i++) {
    key += chars[array[i] % chars.length];
  }
  return key;
}

// Generates a random salt (or uses provided), derives a CryptoKey from the file key, and encrypts the data.
export async function encryptWithFileKey(data: string, fileKey: string, providedSalt?: string): Promise<{ ciphertext: string, iv: string, fileSalt: string }> {
  const fileSalt = providedSalt || await generateSalt();
  const cryptoKey = await deriveKey(fileKey, fileSalt);
  const encrypted = await encryptData(data, cryptoKey);
  return {
    ciphertext: encrypted.ciphertext,
    iv: encrypted.iv,
    fileSalt
  };
}

// Encrypts the file key itself using the user's master CryptoKey.
export async function encryptFileKey(fileKey: string, masterKey: CryptoKey): Promise<{ ciphertext: string, iv: string }> {
  return encryptData(fileKey, masterKey);
}

// Decrypts the encrypted file key using the user's master CryptoKey.
export async function decryptFileKey(encryptedFileKey: string, iv: string, masterKey: CryptoKey): Promise<string> {
  return decryptData(encryptedFileKey, iv, masterKey);
}

// Derives the CryptoKey from the file key and salt, then decrypts the data.
export async function decryptWithFileKey(ciphertext: string, iv: string, fileKey: string, fileSalt: string): Promise<string> {
  const cryptoKey = await deriveKey(fileKey, fileSalt);
  return decryptData(ciphertext, iv, cryptoKey);
}
