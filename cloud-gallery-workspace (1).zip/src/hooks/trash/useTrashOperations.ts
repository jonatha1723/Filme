import React from "react";
import { useAuth } from "../../contexts/AuthContext";
import { getTrashItems, removeFromTrash, clearTrash, saveImageToCache } from "../../utils/db";
import { TrashImage } from "../gallery/trashDecryptHelper";

interface UseTrashOperationsProps {
  images: TrashImage[];
  setImages: React.Dispatch<React.SetStateAction<TrashImage[]>>;
  selectedIds: string[];
  setSelectedIds: React.Dispatch<React.SetStateAction<string[]>>;
  setSelectedImage: (img: TrashImage | null) => void;
  setIsRestoring: (val: boolean) => void;
  setIsDeleting: (val: boolean) => void;
  setIsConfirmDeleteOpen: (val: boolean) => void;
  setIsConfirmDeleteMultipleOpen: (val: boolean) => void;
  setIsConfirmEmptyOpen: (val: boolean) => void;
  showToast: (msg: string, type?: "success" | "error") => void;
}

export function useTrashOperations({
  images,
  setImages,
  selectedIds,
  setSelectedIds,
  setSelectedImage,
  setIsRestoring,
  setIsDeleting,
  setIsConfirmDeleteOpen,
  setIsConfirmDeleteMultipleOpen,
  setIsConfirmEmptyOpen,
  showToast,
}: UseTrashOperationsProps) {
  const { user, securityImageId } = useAuth();

  const restoreInternal = async (id: string) => {
    if (!user) return;
    const items = await getTrashItems();
    const trashItem = items.find((i) => i.id === id);

    if (!trashItem) throw new Error("Item not found in trash");

    try {
      await fetch("/api/storage/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: trashItem.id,
          userId: user.uid,
          ciphertext: trashItem.ciphertext,
          iv: trashItem.iv,
          contentType: trashItem.contentType,
          totalSize: trashItem.totalSize,
          thumbnailCiphertext: trashItem.thumbnailCiphertext,
          thumbnailIv: trashItem.thumbnailIv,
          isChunked: trashItem.isChunked || false,
          chunkCount: trashItem.chunkCount || 1,
          fileKeyCiphertext: trashItem.fileKeyCiphertext,
          fileKeyIv: trashItem.fileKeyIv,
          fileSalt: trashItem.fileSalt,
          isProtected: trashItem.isProtected || false,
        }),
      });
    } catch (err) {
      console.warn("Erro ao restaurar no servidor local:", err);
    }

    await removeFromTrash(id);

    if (trashItem.isProtected) {
      if (trashItem.auxKey) {
        try {
          const { saveAuxKeyToCache } = await import("../../utils/db");
          await saveAuxKeyToCache(trashItem.id, trashItem.auxKey);
        } catch (_) {}

        if (navigator.onLine) {
          try {
            const { setDoc, doc } = await import("firebase/firestore");
            const { dbPrimary } = await import("../../firebase");
            await setDoc(doc(dbPrimary, "media_keys", trashItem.id), {
              auxKey: trashItem.auxKey,
              userId: user.uid,
              createdAt: Date.now(),
            });
          } catch (fsErr) {
            console.warn("Erro ao restaurar chave auxiliar no Firestore:", fsErr);
          }
        }
      }
      window.dispatchEvent(new CustomEvent("refresh-protected-gallery"));
    } else {
      await saveImageToCache({
        id: trashItem.id,
        ciphertext: trashItem.ciphertext,
        iv: trashItem.iv,
        createdAt: trashItem.createdAt,
        isChunked: trashItem.isChunked || false,
        chunkCount: trashItem.chunkCount || 1,
        contentType: trashItem.contentType || "image/png",
        totalSize: trashItem.totalSize || 0,
        thumbnailCiphertext: trashItem.thumbnailCiphertext || "",
        thumbnailIv: trashItem.thumbnailIv || "",
        fileKeyCiphertext: trashItem.fileKeyCiphertext,
        fileKeyIv: trashItem.fileKeyIv,
        fileSalt: trashItem.fileSalt,
      });
    }
  };

  const handleRestore = async (image: TrashImage) => {
    if (!user) return;
    setIsRestoring(true);
    try {
      await restoreInternal(image.id);
      setImages((prev) => prev.filter((img) => img.id !== image.id));
      setSelectedImage(null);
      setSelectedIds((prev) => prev.filter((id) => id !== image.id));
      showToast("Imagem restaurada com sucesso!");
    } catch (error) {
      console.error("Error restoring image:", error);
      showToast("Erro ao restaurar imagem.", "error");
    } finally {
      setIsRestoring(false);
    }
  };

  const handleRestoreMultiple = async () => {
    if (!user || selectedIds.length === 0) return;
    setIsRestoring(true);
    try {
      for (const id of selectedIds) {
        try {
          await restoreInternal(id);
        } catch (e) {
          console.error(`Failed to restore ${id}`, e);
        }
      }
      const restoredSet = new Set(selectedIds);
      setImages((prev) => prev.filter((img) => !restoredSet.has(img.id)));
      setSelectedIds([]);
      showToast(`${restoredSet.size} itens restaurados.`);
    } catch (error) {
      showToast("Erro ao restaurar itens.", "error");
    } finally {
      setIsRestoring(false);
    }
  };

  const deleteInternal = async (id: string) => {
    await removeFromTrash(id);
    if (user && navigator.onLine) {
      try {
        await fetch(`/api/storage/image/${id}`, { method: "DELETE" });
      } catch (err) {}
      try {
        const { deleteDoc, doc } = await import("firebase/firestore");
        const { dbPrimary } = await import("../../firebase");
        await deleteDoc(doc(dbPrimary, "media_keys", id));
      } catch (fsErr) {}
    }
  };

  const handleDeletePermanently = async (image: TrashImage) => {
    setIsDeleting(true);
    try {
      await deleteInternal(image.id);
      setImages((prev) => prev.filter((img) => img.id !== image.id));
      setSelectedImage(null);
      setSelectedIds((prev) => prev.filter((id) => id !== image.id));
      setIsConfirmDeleteOpen(false);
      showToast("Imagem excluída permanentemente.");
    } catch (error) {
      console.error("Error deleting image:", error);
      showToast("Erro ao excluir imagem.", "error");
    } finally {
      setIsDeleting(false);
    }
  };

  const handleDeleteMultiple = async () => {
    if (selectedIds.length === 0) return;
    setIsDeleting(true);
    try {
      for (const id of selectedIds) {
        await deleteInternal(id);
      }
      const deletedSet = new Set(selectedIds);
      setImages((prev) => prev.filter((img) => !deletedSet.has(img.id)));
      setSelectedIds([]);
      setIsConfirmDeleteMultipleOpen(false);
      showToast(`${deletedSet.size} itens excluídos permanentemente.`);
    } catch (error) {
      showToast("Erro ao excluir itens.", "error");
    } finally {
      setIsDeleting(false);
    }
  };

  const handleEmptyTrash = async () => {
    setIsDeleting(true);
    try {
      if (user && navigator.onLine) {
        const { deleteDoc, doc } = await import("firebase/firestore");
        const { dbPrimary } = await import("../../firebase");
        for (const item of images) {
          try {
            await fetch(`/api/storage/image/${item.id}`, { method: "DELETE" });
          } catch (e) {}
          try {
            await deleteDoc(doc(dbPrimary, "media_keys", item.id));
          } catch (e) {}
        }
      }
      await clearTrash();
      setImages([]);
      setIsConfirmEmptyOpen(false);
      showToast("Lixeira esvaziada com sucesso!");
    } catch (error) {
      console.error("Error emptying trash:", error);
      showToast("Erro ao esvaziar lixeira.", "error");
    } finally {
      setIsDeleting(false);
    }
  };

  return {
    handleRestore,
    handleRestoreMultiple,
    handleDeletePermanently,
    handleDeleteMultiple,
    handleEmptyTrash,
  };
}
