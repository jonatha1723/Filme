import { useEffect } from "react";
import { User, onAuthStateChanged } from "firebase/auth";
import { getDoc, doc } from "firebase/firestore";
import { authPrimary, dbPrimary } from "../firebase";
import { checkForMigration } from "../utils/authMigration";

interface AuthInitializeProps {
  setUser: (user: User | null) => void;
  setNeedsSetup: (needsSetup: boolean) => void;
  setOrDecryptExtraPassword: (extraVal: any, key: CryptoKey | null) => Promise<void>;
  setSecurityImageId: (id: string | null) => void;
  setIsAuthReady: (ready: boolean) => void;
  cryptoKey: CryptoKey | null;
  setCryptoKey: (key: CryptoKey | null) => void;
  setExtraPassword: (pwd: string | null) => void;
  isAuthReady: boolean;
}

export function useAuthInitialize({
  setUser,
  setNeedsSetup,
  setOrDecryptExtraPassword,
  setSecurityImageId,
  setIsAuthReady,
  cryptoKey,
  setCryptoKey,
  setExtraPassword,
  isAuthReady,
}: AuthInitializeProps) {
  useEffect(() => {
    const savedOfflineUser = localStorage.getItem("offline_user");
    let initialUser: any = null;

    if (savedOfflineUser) {
      try {
        initialUser = JSON.parse(savedOfflineUser);
        setUser(initialUser);

        const cachedVaultData = localStorage.getItem(
          `vault_data_${initialUser.uid}`,
        );
        if (cachedVaultData) {
          const data = JSON.parse(cachedVaultData);
          setNeedsSetup(false);
          setOrDecryptExtraPassword(data.extraPassword, null);
          setSecurityImageId(data.securityImageId || null);
          setIsAuthReady(true);
        }
      } catch (e) {
        console.error("Failed to parse offline user", e);
      }
    }

    let initialAuthFired = false;

    const unsubscribePrimary = onAuthStateChanged(
      authPrimary,
      async (currentUser) => {
        initialAuthFired = true;
        if (currentUser) {
          await checkForMigration(currentUser);

          const offlineUserInfo = {
            uid: currentUser.uid,
            email: currentUser.email,
            displayName: currentUser.displayName,
            photoURL: currentUser.photoURL,
          };
          localStorage.setItem("offline_user", JSON.stringify(offlineUserInfo));
          setUser(currentUser);

          const cachedData = localStorage.getItem(
            `vault_data_${currentUser.uid}`,
          );

          if (cachedData) {
            const data = JSON.parse(cachedData);
            setNeedsSetup(false);
            await setOrDecryptExtraPassword(data.extraPassword, null);
            setSecurityImageId(data.securityImageId || null);
            setIsAuthReady(true);
          } else {
            setIsAuthReady(false);
            try {
              const userDoc = await getDoc(doc(dbPrimary, "users", currentUser.uid));

              if (userDoc && userDoc.exists()) {
                setNeedsSetup(false);
                const data = userDoc.data();
                await setOrDecryptExtraPassword(data.extraPassword, cryptoKey);
                setSecurityImageId(data.securityImageId || null);
                localStorage.setItem(
                  `vault_data_${currentUser.uid}`,
                  JSON.stringify({
                    salt: data.salt,
                    verification: data.verification,
                    extraPassword: data.extraPassword,
                    securityImageId: data.securityImageId,
                    extraPasswordUpdatedAt: data.extraPasswordUpdatedAt || 0,
                    securityImageIdUpdatedAt: data.securityImageIdUpdatedAt || 0,
                    failedAttempts: data.failedAttempts || 0,
                    lockedUntil: data.lockedUntil || null,
                  }),
                );
              } else {
                setNeedsSetup(true);
              }
            } catch (error: any) {
              console.warn(
                "Offline or error fetching user doc:",
                error,
              );
              if (error.code === 'permission-denied' || error.code === 'not-found') {
                setNeedsSetup(true);
              } else {
                setNeedsSetup(false);
              }
            }
            setIsAuthReady(true);
          }
        } else {
          setUser(null);
          localStorage.removeItem("offline_user");
          setCryptoKey(null);
          setNeedsSetup(false);
          setExtraPassword(null);
          setSecurityImageId(null);
          setIsAuthReady(true);
        }
      },
    );

    const timeout = setTimeout(
      () => {
        if (!initialAuthFired && !isAuthReady) {
          setIsAuthReady(true);
        }
      },
      savedOfflineUser ? 5000 : 1500,
    );

    return () => {
      unsubscribePrimary();
      clearTimeout(timeout);
    };
  }, []);
}
