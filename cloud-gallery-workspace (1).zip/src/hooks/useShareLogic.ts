import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { generateRandomKey, exportKeyToBase64, encryptData, deriveKey, generateSalt } from '../utils/crypto';

export function useShareLogic(
  isOpen: boolean,
  imageId: string,
  decryptedImageUrl: string,
  onClose: () => void
) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);
  const [existingShare, setExistingShare] = useState<any>(null);
  const [requirePassword, setRequirePassword] = useState(false);
  const [password, setPassword] = useState('');
  const [allowDownload, setAllowDownload] = useState(true);
  const [oneTimeView, setOneTimeView] = useState(false);
  const [linkDuration, setLinkDuration] = useState<'1h' | 'permanent'>('1h');
  const [generatedLink, setGeneratedLink] = useState('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isOpen && imageId && user) {
      checkExistingShare();
    }
  }, [isOpen, imageId, user]);

  const checkExistingShare = async () => {
    setChecking(true);
    setError('');
    try {
      const res = await fetch(`/api/share/image/${imageId}`);
      if (res.ok) {
        const resData = await res.json();
        if (resData.success && resData.share) {
          const shareData = resData.share;
          setExistingShare(shareData);
          setRequirePassword(shareData.options.requirePassword);
          setAllowDownload(shareData.options.allowDownload);
          setOneTimeView(shareData.options.oneTimeView);
          setLinkDuration(shareData.options.expiresAt ? '1h' : 'permanent');
          
          const origin = window.location.origin;
          const link = `${origin}/?share=${shareData.id}`;
          setGeneratedLink(link);
        } else {
          setExistingShare(null);
          setGeneratedLink('');
        }
      } else {
        setExistingShare(null);
        setGeneratedLink('');
      }
    } catch (err: any) {
      console.error('Erro ao verificar compartilhamento seguro:', err);
    } finally {
      setChecking(false);
    }
  };

  const handleDeleteShare = async () => {
    if (!existingShare) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/share/${existingShare.id}`, {
        method: 'DELETE'
      });
      if (!res.ok) {
        throw new Error('Falha ao excluir link de compartilhamento no servidor.');
      }
      setExistingShare(null);
      setGeneratedLink('');
      setPassword('');
      setRequirePassword(false);
      setAllowDownload(true);
      setOneTimeView(false);
      setLinkDuration('1h');
    } catch (err: any) {
      setError(err.message || 'Erro ao excluir link de compartilhamento.');
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateShare = async () => {
    setError('');
    if (requirePassword && password.length < 6) {
      setError('A senha de proteção deve ter pelo menos 6 dígitos ou caracteres.');
      return;
    }

    setLoading(true);
    try {
      const shareKey = await generateRandomKey();
      const shareKeyBase64 = await exportKeyToBase64(shareKey);

      let fileBlob: Blob;
      try {
        const response = await fetch(decryptedImageUrl);
        fileBlob = await response.blob();
      } catch (fErr) {
        console.error('Error fetching decrypted image URL, attempting fallback:', fErr);
        if (decryptedImageUrl.includes('base64,')) {
          const parts = decryptedImageUrl.split(';base64,');
          const contentType = parts[0].split(':')[1] || 'image/png';
          const base64Str = parts[1];
          const binary = atob(base64Str);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
          }
          fileBlob = new Blob([bytes], { type: contentType });
        } else {
          const binary = atob(decryptedImageUrl);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
          }
          fileBlob = new Blob([bytes], { type: 'image/png' });
        }
      }

      const totalSize = fileBlob.size;
      let ciphertextToSave = '';
      let ivToSave = '';
      const contentTypeToSave = fileBlob.type || 'image/png';

      const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(fileBlob);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = e => reject(e);
      });

      const encryptResult = await encryptData(base64Data, shareKey);
      ciphertextToSave = encryptResult.ciphertext;
      ivToSave = encryptResult.iv;

      const shareId = Math.random().toString(36).substring(2, 11) + Math.random().toString(36).substring(2, 11);
      const expiresAt = linkDuration === '1h' ? new Date(Date.now() + 3600000) : null;

      let optionsPayload: any = {
        requirePassword,
        allowDownload,
        oneTimeView,
        expiresAt,
        encryptedShareKey: null,
        ivShareKey: null
      };

      let finalUrl = '';

      if (requirePassword) {
        const salt = await generateSalt();
        const derivedKey = await deriveKey(password, salt);
        const encryptedKeyResult = await encryptData(shareKeyBase64, derivedKey);
        
        optionsPayload.encryptedShareKey = encryptedKeyResult.ciphertext + '|' + salt;
        optionsPayload.ivShareKey = encryptedKeyResult.iv;
        finalUrl = `${window.location.origin}/?share=${shareId}`;
      } else {
        finalUrl = `${window.location.origin}/?share=${shareId}&key=${encodeURIComponent(shareKeyBase64)}#${encodeURIComponent(shareKeyBase64)}`;
      }

      const shareDocData = {
        id: shareId,
        imageId,
        userId: user ? user.uid : null,
        ciphertext: ciphertextToSave,
        iv: ivToSave,
        isChunked: false,
        chunkCount: 1,
        contentType: contentTypeToSave,
        totalSize: totalSize,
        options: {
          requirePassword: !!optionsPayload.requirePassword,
          encryptedShareKey: optionsPayload.encryptedShareKey,
          ivShareKey: optionsPayload.ivShareKey,
          allowDownload: oneTimeView ? false : !!optionsPayload.allowDownload,
          oneTimeView: optionsPayload.oneTimeView,
          expiresAt: optionsPayload.expiresAt ? optionsPayload.expiresAt.getTime() : null
        },
        createdAt: Date.now(),
        firstViewedAt: null,
        firstViewerIp: null
      };

      const res = await fetch('/api/share/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(shareDocData)
      });

      if (!res.ok) {
        throw new Error('Falha ao registrar compartilhamento no servidor seguro.');
      }
      
      setGeneratedLink(finalUrl);
      setExistingShare(shareDocData);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Erro inesperado na geração do compartilhamento seguro.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!generatedLink) return;
    navigator.clipboard.writeText(generatedLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return {
    loading,
    checking,
    existingShare,
    requirePassword,
    setRequirePassword,
    password,
    setPassword,
    allowDownload,
    setAllowDownload,
    oneTimeView,
    setOneTimeView,
    linkDuration,
    setLinkDuration,
    generatedLink,
    copied,
    error,
    setError,
    handleDeleteShare,
    handleGenerateShare,
    handleCopy,
  };
}
