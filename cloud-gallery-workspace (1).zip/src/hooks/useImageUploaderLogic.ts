import React, { useState, useCallback, useEffect, useRef } from 'react';
import { doc, getDoc, updateDoc, increment } from 'firebase/firestore';
import { useAuth } from '../contexts/AuthContext';
import { dbPrimary } from '../firebase';
import { encryptData } from '../utils/crypto';
import { generateFileKey, encryptWithFileKey, encryptFileKey } from '../utils/fileCrypto';
import { saveImageToCache } from '../utils/db';
import { 
  compressImage, 
  compressVideo, 
  generateImageThumbnail, 
  generateVideoThumbnail 
} from '../utils/media';
import { ToastType } from '../components/Toast';

export function useImageUploaderLogic(
  onComplete?: () => void,
  onUploadingStateChange?: (isUploading: boolean) => void,
  initialFiles: File[] = []
) {
  const { user, cryptoKey } = useAuth();
  const [uploading, setUploading] = useState(false);
  const [progressText, setProgressText] = useState('');
  const isUploadingRef = useRef(false);
  const [toast, setToast] = useState<{ message: string; type: ToastType } | null>(null);

  const showToast = (message: string, type: ToastType = 'success') => {
    setToast({ message, type });
    window.dispatchEvent(new CustomEvent('show-app-toast', {
      detail: { message, type }
    }));
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (!user || !cryptoKey || acceptedFiles.length === 0 || isUploadingRef.current) return;
    
    isUploadingRef.current = true;
    setUploading(true);
    if (onUploadingStateChange) onUploadingStateChange(true);
    
    try {
      let isCloudSyncFailed = false;
      const userDocRef = doc(dbPrimary, 'users', user.uid);

      const uniqueFiles = Array.from(
        new Map(acceptedFiles.map(f => [f.name + '_' + f.size, f])).values()
      );

      for (const file of uniqueFiles) {
        if (file.size > 20 * 1024 * 1024) {
          throw new Error(`O arquivo "${file.name}" excede o limite individual máximo permitido de 20 MB.`);
        }
      }

      const uploadBaseTime = Date.now();

      for (let index = 0; index < uniqueFiles.length; index++) {
        const file = uniqueFiles[index];
        const isVideo = file.type.startsWith('video/');
        const fileLabel = `${index + 1}/${uniqueFiles.length}`;

        let processedFile = file;

        if (isVideo) {
          setProgressText(`Otimizando vídeo (${fileLabel})...`);
          processedFile = await compressVideo(file, (pct) => {
            setProgressText(`Compactando vídeo (${fileLabel}): ${Math.round(pct * 100)}%`);
          });
        } else {
          setProgressText(`Compactando foto (${fileLabel})...`);
          processedFile = await compressImage(file);
        }

        const newId = Math.random().toString(36).substring(2, 11) + Date.now().toString(36);
        const fileKey = generateFileKey();

        setProgressText(`Gerando miniatura (${fileLabel})...`);
        const thumbnailBase64 = isVideo 
          ? await generateVideoThumbnail(processedFile) 
          : await generateImageThumbnail(processedFile);

        let thumbnailCiphertext = '';
        let thumbnailIv = '';
        let fileSalt = '';

        if (thumbnailBase64) {
          const thumbEnc = await encryptWithFileKey(thumbnailBase64, fileKey);
          thumbnailCiphertext = thumbEnc.ciphertext;
          thumbnailIv = thumbEnc.iv;
          fileSalt = thumbEnc.fileSalt;
        }

        setProgressText(`Preparando criptografia local (${fileLabel})...`);
        const fullBase64 = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.readAsDataURL(processedFile);
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = error => reject(error);
        });

        const encryptedFull = await encryptWithFileKey(fullBase64, fileKey, fileSalt);
        
        // Ensure we have a fileSalt (if thumbnail wasn't generated)
        if (!fileSalt) {
          fileSalt = encryptedFull.fileSalt;
        }

        // Encrypt the file key with the user's master key
        const encryptedKey = await encryptFileKey(fileKey, cryptoKey);

        // Generate precise sequential timestamp to maintain user's uploaded order (Index 0 gets highest value to appear first in newest-first sorting)
        const itemCreatedAt = uploadBaseTime + (uniqueFiles.length - index) * 1000;

        await saveImageToCache({
          id: newId,
          ciphertext: encryptedFull.ciphertext,
          iv: encryptedFull.iv,
          createdAt: itemCreatedAt,
          isChunked: false,
          chunkCount: 1,
          contentType: processedFile.type,
          totalSize: processedFile.size,
          thumbnailCiphertext,
          thumbnailIv,
          fileKeyCiphertext: encryptedKey.ciphertext,
          fileKeyIv: encryptedKey.iv,
          fileSalt
        });

        // Dispatch immediate event to render the image on the screen instantly
        window.dispatchEvent(new CustomEvent('refresh-gallery-list'));

        try {
          setProgressText(`Enviando para o cofre seguro (${fileLabel})...`);
          
          const uploadRes = await fetch('/api/storage/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              id: newId,
              userId: user.uid,
              ciphertext: encryptedFull.ciphertext,
              iv: encryptedFull.iv,
              contentType: processedFile.type,
              totalSize: processedFile.size,
              isChunked: false,
              chunkCount: 1,
              thumbnailCiphertext,
              thumbnailIv,
              fileKeyCiphertext: encryptedKey.ciphertext,
              fileKeyIv: encryptedKey.iv,
              fileSalt,
              createdAt: itemCreatedAt
            })
          });

          if (!uploadRes.ok) {
            const uploadErrData = await uploadRes.json();
            throw new Error(uploadErrData.error || 'Erro na resposta do servidor de upload');
          }
        } catch (localUploadErr: any) {
          console.warn('Erro ao salvar no servidor local:', localUploadErr);
          isCloudSyncFailed = true;
        }

        if (!isCloudSyncFailed) {
          try {
            await updateDoc(userDocRef, {
              storageUsed: increment(processedFile.size)
            });
          } catch (stErr) {
            console.warn('Erro ao incrementar cota de armazenamento:', stErr);
          }
        }
      }

      if (isCloudSyncFailed) {
        showToast('Erro ao enviar para o servidor. Salvo localmente.', 'error');
      }

      if (onComplete) {
        onComplete();
      }
    } catch (error: any) {
      console.error('Error uploading media:', error);
      showToast('Erro ao enviar para o servidor.', 'error');
    } finally {
      isUploadingRef.current = false;
      setUploading(false);
      setProgressText('');
      if (onUploadingStateChange) onUploadingStateChange(false);
    }
  }, [user, cryptoKey, onComplete, onUploadingStateChange]);

  const lastProcessedFiles = useRef<File[]>([]);

  useEffect(() => {
    if (initialFiles.length > 0 && initialFiles !== lastProcessedFiles.current) {
      lastProcessedFiles.current = initialFiles;
      onDrop(initialFiles);
    }
  }, [initialFiles, onDrop]);

  return {
    uploading,
    progressText,
    toast,
    setToast,
    onDrop,
  };
}
