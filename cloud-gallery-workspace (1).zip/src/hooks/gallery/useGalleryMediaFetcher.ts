import { useAuth } from "../../contexts/AuthContext";
import { DecryptedImage } from "../../types";
import { decryptData } from "../../utils/crypto";
import { decryptFileKey, decryptWithFileKey } from "../../utils/fileCrypto";
import { getImageFromCache, saveImageToCache } from "../../utils/db";

interface UseGalleryMediaFetcherProps {
  isExtraUnlocked?: boolean;
  setSelectedImage: (url: string | null) => void;
  setSelectedImageId: (id: string | null) => void;
  setDownloadingFull: (val: boolean) => void;
  setFullDownloadProgress: (progress: string) => void;
  showToast: (msg: string, type?: "success" | "error") => void;
}

export function useGalleryMediaFetcher({
  isExtraUnlocked,
  setSelectedImage,
  setSelectedImageId,
  setDownloadingFull,
  setFullDownloadProgress,
  showToast,
}: UseGalleryMediaFetcherProps) {
  const { user, cryptoKey, extraPassword, securityImageId } = useAuth();

  const fetchFullMedia = async (img: DecryptedImage) => {
    setSelectedImage(img.url || "loading");

    if (img.originalUrl) {
      setSelectedImage(img.originalUrl);
      return;
    }

    try {
      let activeKey = cryptoKey!;
      if (img.id === securityImageId) {
        if (!isExtraUnlocked || !extraPassword) {
          throw new Error("Você precisa desbloquear a pasta de segurança primeiro.");
        }
        const { getAuxKeyFromCache, saveAuxKeyToCache } = await import("../../utils/db");
        let auxKey = await getAuxKeyFromCache(img.id);
        if (!auxKey) {
          const { doc, getDoc } = await import("firebase/firestore");
          const { dbPrimary } = await import("../../firebase");
          const docSnap = await getDoc(doc(dbPrimary, "media_keys", img.id));
          if (docSnap.exists()) {
            auxKey = docSnap.data().auxKey;
            if (auxKey) {
              await saveAuxKeyToCache(img.id, auxKey);
            }
          }
        }
        if (auxKey) {
          const { deriveKey } = await import("../../utils/crypto");
          const salt = btoa(auxKey.slice(0, 16).padEnd(16, "0"));
          activeKey = await deriveKey(extraPassword, salt);
        } else {
          throw new Error("Chave auxiliar não encontrada.");
        }
      }

      setDownloadingFull(true);
      const isVideo = img.isVideo || img.contentType?.startsWith("video/") || false;
      setFullDownloadProgress(isVideo ? "Preparando vídeo..." : "Carregando versão original...");

      const cached = await getImageFromCache(img.id);

      if (cached && cached.ciphertext && cached.ciphertext !== "chunked_vault_data") {
        setFullDownloadProgress("Descriptografando localmente...");
        let decryptedBase64 = "";
        if (cached.fileKeyCiphertext && cached.fileKeyIv && cached.fileSalt) {
          try {
            const fileKeyStr = await decryptFileKey(cached.fileKeyCiphertext, cached.fileKeyIv, activeKey);
            decryptedBase64 = await decryptWithFileKey(cached.ciphertext, cached.iv, fileKeyStr, cached.fileSalt);
          } catch (e) {
            console.error("Local file key decryption failed", e);
            decryptedBase64 = await decryptData(cached.ciphertext, cached.iv, activeKey);
          }
        } else {
          decryptedBase64 = await decryptData(cached.ciphertext, cached.iv, activeKey);
        }

        img.originalUrl = decryptedBase64;
        setSelectedImage(decryptedBase64);
      } else if (user) {
        setFullDownloadProgress("Carregando do cofre seguro...");
        const storeRes = await fetch(`/api/storage/image/${img.id}`);
        if (storeRes.ok) {
          const storeData = await storeRes.json();
          if (storeData.success && storeData.image) {
            const fileData = storeData.image;
            let decryptedBase64 = "";

            if (fileData.ciphertext === "chunked_vault_data") {
              throw new Error("Esta mídia antiga está em um formato particionado que não é mais suportado. O arquivo completo não pode ser carregado.");
            }
            if (fileData.fileKeyCiphertext && fileData.fileKeyIv && fileData.fileSalt) {
              try {
                const fileKeyStr = await decryptFileKey(fileData.fileKeyCiphertext, fileData.fileKeyIv, activeKey);
                decryptedBase64 = await decryptWithFileKey(fileData.ciphertext, fileData.iv, fileKeyStr, fileData.fileSalt);
              } catch (e) {
                console.error("Remote file key decryption failed", e);
                decryptedBase64 = await decryptData(fileData.ciphertext, fileData.iv, activeKey);
              }
            } else {
              decryptedBase64 = await decryptData(fileData.ciphertext, fileData.iv, activeKey);
            }

            img.originalUrl = decryptedBase64;
            setSelectedImage(decryptedBase64);

            try {
              await saveImageToCache({
                id: img.id,
                ciphertext: fileData.ciphertext,
                iv: fileData.iv,
                createdAt: fileData.createdAt,
                isChunked: false,
                chunkCount: 1,
                contentType: fileData.contentType || "image/png",
                totalSize: fileData.totalSize || 0,
                thumbnailCiphertext: fileData.thumbnailCiphertext || "",
                thumbnailIv: fileData.thumbnailIv || "",
                fileKeyCiphertext: fileData.fileKeyCiphertext,
                fileKeyIv: fileData.fileKeyIv,
                fileSalt: fileData.fileSalt,
              });
            } catch (cacheErr) {
              console.warn("Silent warning: Failed to cache downloaded image locally:", cacheErr);
            }
            return;
          }
        }
        throw new Error("Mídia não encontrada localmente nem no cofre do Google Drive.");
      }
    } catch (err: any) {
      console.error("Error loading full asset", err);
      showToast(err.message || "Erro ao carregar ou descriptografar mídia completa.", "error");
      setSelectedImage(null);
      setSelectedImageId(null);
    } finally {
      setDownloadingFull(false);
      setFullDownloadProgress("");
    }
  };

  return { fetchFullMedia };
}
