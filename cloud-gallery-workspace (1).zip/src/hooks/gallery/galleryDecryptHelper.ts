import { DecryptedImage } from '../../types';
import { getTimestamp } from '../../utils/galleryHelpers';
import { decryptData } from '../../utils/crypto';
import { decryptFileKey, decryptWithFileKey } from '../../utils/fileCrypto';

export async function decryptSingleThumbnail(
  img: any,
  securityImageId: string | null | undefined,
  isExtraUnlocked: boolean | undefined,
  extraPassword: string | null | undefined,
  cryptoKey: CryptoKey | null | undefined,
  decryptedCache: Map<string, string>
): Promise<DecryptedImage> {
  const createdAt = getTimestamp(img.createdAt);
  const isVideo = img.contentType?.startsWith('video/') || false;
  const isChunked = img.isChunked || false;
  const chunkCount = img.chunkCount || 1;
  const contentType = img.contentType || (isVideo ? 'video/mp4' : 'image/png');
  const totalSize = img.totalSize || 0;

  // Special handling for the security image (fake vault trigger)
  if (img.id === securityImageId && !isExtraUnlocked) {
    return {
      id: img.id,
      url: '',
      createdAt,
      isVideo,
      isChunked,
      chunkCount,
      contentType,
      totalSize,
      failed: false,
      noThumbnail: false
    } as DecryptedImage;
  }

  if (img.id === securityImageId && isExtraUnlocked) {
    let decryptedThumbnailUrl = '';
    let failed = false;
    let noThumbnail = false;

    try {
      const { getAuxKeyFromCache, saveAuxKeyToCache } = await import('../../utils/db');
      let auxKey = await getAuxKeyFromCache(img.id);
      if (!auxKey) {
        const { doc, getDoc } = await import('firebase/firestore');
        const { dbPrimary } = await import('../../firebase');
        const docSnap = await getDoc(doc(dbPrimary, 'media_keys', img.id));
        if (docSnap.exists()) {
          auxKey = docSnap.data().auxKey;
          if (auxKey) {
            await saveAuxKeyToCache(img.id, auxKey);
          }
        }
      }

      if (auxKey && extraPassword) {
        const { deriveKey } = await import('../../utils/crypto');
        const salt = btoa(auxKey.slice(0, 16).padEnd(16, '0'));
        const combinedKey = await deriveKey(extraPassword, salt);

        let fileKeyStr: string | null = null;
        try {
          if ((img as any).fileKeyCiphertext && (img as any).fileKeyIv && (img as any).fileSalt) {
            fileKeyStr = await decryptFileKey((img as any).fileKeyCiphertext, (img as any).fileKeyIv, combinedKey);
          }
        } catch (e) {
          console.error('Failed to decrypt file key for security image', e);
        }

        if (img.thumbnailCiphertext && img.thumbnailIv) {
          if (fileKeyStr && (img as any).fileSalt) {
            try {
              decryptedThumbnailUrl = await decryptWithFileKey(img.thumbnailCiphertext, img.thumbnailIv, fileKeyStr, (img as any).fileSalt);
            } catch (innerErr) {
              decryptedThumbnailUrl = await decryptData(img.thumbnailCiphertext, img.thumbnailIv, combinedKey);
            }
          } else {
            decryptedThumbnailUrl = await decryptData(img.thumbnailCiphertext, img.thumbnailIv, combinedKey);
          }
        } else if (img.ciphertext && img.iv) {
          if (img.ciphertext === 'chunked_vault_data') {
            noThumbnail = true;
          } else {
            if (fileKeyStr && (img as any).fileSalt) {
              try {
                decryptedThumbnailUrl = await decryptWithFileKey(img.ciphertext, img.iv, fileKeyStr, (img as any).fileSalt);
              } catch (innerErr) {
                decryptedThumbnailUrl = await decryptData(img.ciphertext, img.iv, combinedKey);
              }
            } else {
              decryptedThumbnailUrl = await decryptData(img.ciphertext, img.iv, combinedKey);
            }
          }
        } else {
          failed = true;
        }

        if (decryptedThumbnailUrl) {
          decryptedCache.set(img.id, decryptedThumbnailUrl);
        }
      } else {
        failed = true;
      }
    } catch (err) {
      console.error('Error decrypting security image thumbnail:', img.id, err);
      failed = true;
    }

    return {
      id: img.id,
      url: decryptedThumbnailUrl,
      createdAt,
      isVideo,
      isChunked,
      chunkCount,
      contentType,
      totalSize,
      failed,
      noThumbnail
    } as DecryptedImage;
  }

  if (decryptedCache.has(img.id)) {
    return {
      id: img.id,
      url: decryptedCache.get(img.id)!,
      createdAt,
      isVideo,
      isChunked,
      chunkCount,
      contentType,
      totalSize
    } as DecryptedImage;
  }

  let decryptedThumbnailUrl = '';
  let failed = false;
  let noThumbnail = false;

  let fileKeyStr: string | null = null;
  try {
    if ((img as any).fileKeyCiphertext && (img as any).fileKeyIv && (img as any).fileSalt) {
      fileKeyStr = await decryptFileKey((img as any).fileKeyCiphertext, (img as any).fileKeyIv, cryptoKey!);
    }
  } catch (e) {
    console.error('Failed to decrypt file key', e);
  }

  if (img.thumbnailCiphertext && img.thumbnailIv) {
    try {
      if (fileKeyStr && (img as any).fileSalt) {
        try {
          decryptedThumbnailUrl = await decryptWithFileKey(img.thumbnailCiphertext, img.thumbnailIv, fileKeyStr, (img as any).fileSalt);
        } catch (innerErr) {
          console.warn('Envelope decryption failed for thumbnail, trying legacy cryptoKey decryption as fallback...', innerErr);
          decryptedThumbnailUrl = await decryptData(img.thumbnailCiphertext, img.thumbnailIv, cryptoKey!);
        }
      } else {
        decryptedThumbnailUrl = await decryptData(img.thumbnailCiphertext, img.thumbnailIv, cryptoKey!);
      }
      decryptedCache.set(img.id, decryptedThumbnailUrl);
    } catch (thErr) {
      console.warn('Error decrypting thumbnail for', img.id, thErr);
      if (isChunked) {
        noThumbnail = true;
      } else {
        failed = true;
      }
    }
  } else if (isChunked) {
    noThumbnail = true;
  } else if (img.ciphertext && img.iv) {
    try {
      if (img.ciphertext === 'chunked_vault_data') {
        noThumbnail = true;
      } else {
        if (fileKeyStr && (img as any).fileSalt) {
          try {
            decryptedThumbnailUrl = await decryptWithFileKey(img.ciphertext, img.iv, fileKeyStr, (img as any).fileSalt);
          } catch (innerErr) {
            console.warn('Envelope decryption failed for full content as thumbnail, trying legacy cryptoKey decryption as fallback...', innerErr);
            decryptedThumbnailUrl = await decryptData(img.ciphertext, img.iv, cryptoKey!);
          }
        } else {
          decryptedThumbnailUrl = await decryptData(img.ciphertext, img.iv, cryptoKey!);
        }
        decryptedCache.set(img.id, decryptedThumbnailUrl);
      }
    } catch (fullErr) {
      console.error('Error decrypting full single-part file for thumbnail', img.id, fullErr);
      failed = true;
    }
  } else {
    failed = true;
  }

  return {
    id: img.id,
    url: decryptedThumbnailUrl,
    createdAt,
    isVideo,
    isChunked,
    chunkCount,
    contentType,
    totalSize,
    failed,
    noThumbnail
  } as DecryptedImage;
}
