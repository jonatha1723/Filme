import React from 'react';
import { doc, deleteDoc } from 'firebase/firestore';
import { dbPrimary } from '../../firebase';
import { DecryptedImage } from '../../types';
import { getImageFromCache, removeImageFromCache, saveToTrash } from '../../utils/db';

export function useGalleryDeletion(
  user: any,
  images: DecryptedImage[],
  setImages: React.Dispatch<React.SetStateAction<DecryptedImage[]>>,
  selectedImageId: string | null,
  setSelectedImage: React.Dispatch<React.SetStateAction<string | null>>,
  setSelectedImageId: React.Dispatch<React.SetStateAction<string | null>>,
  imageToDelete: string | null,
  setImageToDelete: React.Dispatch<React.SetStateAction<string | null>>,
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void
) {
  const handleDelete = async () => {
    if (!imageToDelete) return;
    const id = imageToDelete;
    
    setImages(prev => prev.filter(img => img.id !== id));
    if (selectedImageId === id) {
      setSelectedImage(null);
      setSelectedImageId(null);
    }
    setImageToDelete(null);

    try {
      let cachedImage = await getImageFromCache(id);
      if (!cachedImage) {
        try {
          const res = await fetch(`/api/storage/image/${id}`);
          if (res.ok) {
            const data = await res.json();
            if (data.success && data.image) {
              cachedImage = data.image;
            }
          }
        } catch (fetchErr) {
          console.warn('Erro ao obter imagem para salvar na lixeira:', fetchErr);
        }
      }

      if (cachedImage) {
        await saveToTrash({
          ...cachedImage,
          deletedAt: Date.now()
        });
      } else {
        const stateImg = images.find(img => img.id === id);
        if (stateImg) {
          await saveToTrash({
            id: stateImg.id,
            ciphertext: '',
            iv: '',
            createdAt: stateImg.createdAt || Date.now(),
            deletedAt: Date.now(),
            isChunked: stateImg.isChunked || false,
            chunkCount: stateImg.chunkCount || 1,
            contentType: stateImg.contentType || 'image/png',
            totalSize: stateImg.totalSize || 0,
            thumbnailCiphertext: '',
            thumbnailIv: '',
          });
        }
      }
      await removeImageFromCache(id);
      
      if (user && navigator.onLine) {
        try {
          await deleteDoc(doc(dbPrimary, 'images', id));
        } catch (fsErr) {
          console.warn('Erro ao deletar do Firestore ao mover para lixeira:', fsErr);
        }
        try {
          await fetch(`/api/storage/image/${id}`, { method: 'DELETE' });
        } catch (serverErr) {
          console.warn('Erro ao deletar do servidor local:', serverErr);
        }
      }
      
      showToast('Imagem movida para a lixeira!');
    } catch (error) {
      console.error('Erro ao excluir imagem:', error);
      showToast('Erro ao excluir imagem.', 'error');
    }
  };

  return { handleDelete };
}
