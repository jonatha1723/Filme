import { useState, useRef, useEffect } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { saveImageToCache, getAllImagesFromCache } from "../../utils/db";
import { DecryptedImage } from "../../types";
import { getTimestamp } from "../../utils/galleryHelpers";
import { decryptSingleThumbnail } from "./galleryDecryptHelper";

export function useGalleryMediaLoader(
  showToast: (msg: string, type?: "success" | "error") => void,
  isExtraUnlocked?: boolean
) {
  const { user, cryptoKey, isAuthReady, extraPassword, securityImageId } = useAuth();
  const [images, setImages] = useState<DecryptedImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncStatus, setSyncStatus] = useState<"synced" | "local-only" | "loading">("loading");
  const [backgroundSyncing, setBackgroundSyncing] = useState(false);
  const [backgroundSyncProgress, setBackgroundSyncProgress] = useState(0);

  const decryptedCache = useRef<Map<string, string>>(new Map());

  const processAndSetImages = async (imageList: any[], append = false) => {
    if (imageList.length === 0) {
      if (!append) setLoading(false);
      return;
    }

    const listToProcess = [...imageList];
    listToProcess.sort((a, b) => {
      const timeA = getTimestamp(a.createdAt);
      const timeB = getTimestamp(b.createdAt);
      return timeB - timeA;
    });

    for (let i = 0; i < listToProcess.length; ) {
      const currentBatchSize = listToProcess.length;
      const batch = listToProcess.slice(i, i + currentBatchSize);
      i += currentBatchSize;

      const batchResults = await Promise.all(
        batch.map((img) =>
          decryptSingleThumbnail(
            img,
            securityImageId,
            isExtraUnlocked,
            extraPassword,
            cryptoKey,
            decryptedCache.current
          )
        )
      );

      setImages((prev) => {
        const existingIds = new Set(prev.map((p) => p.id));
        const added = batchResults.filter((img) => !existingIds.has(img.id));
        const final = [...prev, ...added];
        final.sort((a, b) => b.createdAt - a.createdAt);
        return final;
      });

      if (!append) {
        setLoading(false);
      }
    }
  };

  const loadImages = async () => {
    if (!user || !cryptoKey) return;
    try {
      setLoading(true);

      const cachedImagesPromise = getAllImagesFromCache();
      const serverFetchPromise = navigator.onLine
        ? fetch(`/api/storage/images?userId=${user.uid}`)
            .then((res) => (res.ok ? res.json() : null))
            .catch(() => null)
        : Promise.resolve(null);

      const cachedImages = await cachedImagesPromise;

      if (cachedImages.length > 0) {
        processAndSetImages(cachedImages).then(() => {
          if (cachedImages.length > 0) setLoading(false);
        });
      } else {
        setLoading(false);
      }

      const mergedImages = [...cachedImages];
      const newImagesFound: any[] = [];
      let serverImages: any[] = [];

      const data = await serverFetchPromise;

      if (data && data.success && Array.isArray(data.images)) {
        serverImages = data.images;
        const cachedIds = new Set(cachedImages.map((img: any) => img.id));
        for (const serverImg of data.images) {
          if (!cachedIds.has(serverImg.id)) {
            const loadedImage = {
              id: serverImg.id,
              ciphertext: serverImg.ciphertext || (serverImg.isChunked ? "chunked_vault_data" : ""),
              iv: serverImg.iv || "",
              createdAt: serverImg.createdAt,
              isChunked: serverImg.isChunked || false,
              chunkCount: serverImg.chunkCount || 1,
              contentType: serverImg.contentType || "image/png",
              totalSize: serverImg.totalSize || 0,
              thumbnailCiphertext: serverImg.thumbnailCiphertext || "",
              thumbnailIv: serverImg.thumbnailIv || "",
              fileKeyCiphertext: serverImg.fileKeyCiphertext,
              fileKeyIv: serverImg.fileKeyIv,
              fileSalt: serverImg.fileSalt,
            };
            await saveImageToCache(loadedImage);
            mergedImages.push(loadedImage);
            newImagesFound.push(loadedImage);
          }
        }
        setSyncStatus("synced");
      } else {
        setSyncStatus("local-only");
      }

      if (newImagesFound.length > 0) {
        await processAndSetImages(newImagesFound, true);
      } else if (cachedImages.length === 0) {
        await processAndSetImages([]);
      }

      if (navigator.onLine && serverImages.length > 0) {
        const itemsToSync = serverImages.filter((sImg: any) => {
          const cached = cachedImages.find((c: any) => c.id === sImg.id);
          return (!cached || !cached.ciphertext || cached.ciphertext === "chunked_vault_data") && !sImg.isChunked;
        });

        if (itemsToSync.length > 0) {
          (async () => {
            setBackgroundSyncing(true);
            let syncedCount = 0;
            for (const item of itemsToSync) {
              try {
                const storeRes = await fetch(`/api/storage/image/${item.id}`);
                if (storeRes.ok) {
                  const storeData = await storeRes.json();
                  if (storeData.success && storeData.image && storeData.image.ciphertext !== "chunked_vault_data") {
                    const fileData = storeData.image;
                    await saveImageToCache({
                      id: item.id,
                      ciphertext: fileData.ciphertext,
                      iv: fileData.iv,
                      createdAt: fileData.createdAt,
                      isChunked: false,
                      chunkCount: 1,
                      contentType: fileData.contentType || "image/png",
                      totalSize: fileData.totalSize || 0,
                      thumbnailCiphertext: fileData.thumbnailCiphertext || "",
                      thumbnailIv: fileData.thumbnailIv || "",
                      fileKeyCiphertext: fileData.fileKeyCiphertext,
                      fileKeyIv: fileData.fileKeyIv,
                      fileSalt: fileData.fileSalt,
                    });
                  }
                }
              } catch (e) {
                console.warn("Silent background sync failed for item", item.id);
              }
              syncedCount++;
              setBackgroundSyncProgress(Math.round((syncedCount / itemsToSync.length) * 100));
            }
            setBackgroundSyncing(false);
            setBackgroundSyncProgress(0);
          })();
        }
      }
    } catch (err) {
      console.error("Error loading images:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!isAuthReady || !user || !cryptoKey) return;
    loadImages();

    const handleRefresh = () => {
      console.log("[useGalleryMedia] Refresh event received, reloading images...");
      loadImages();
    };

    window.addEventListener("refresh-gallery-list", handleRefresh);
    return () => {
      window.removeEventListener("refresh-gallery-list", handleRefresh);
    };
  }, [user, cryptoKey, isAuthReady, isExtraUnlocked, securityImageId, extraPassword]);

  return {
    images,
    setImages,
    loading,
    setLoading,
    syncStatus,
    setSyncStatus,
    backgroundSyncing,
    backgroundSyncProgress,
    loadImages,
  };
}
