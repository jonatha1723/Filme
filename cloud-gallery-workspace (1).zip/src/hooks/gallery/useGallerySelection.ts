import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { getImageFromCache, removeImageFromCache, saveToTrash } from '../../utils/db';
import { deleteDoc, doc } from 'firebase/firestore';
import { dbPrimary } from '../../firebase';
import { DecryptedImage } from '../../types';

export function useGallerySelection(
  images: DecryptedImage[],
  setImages: React.Dispatch<React.SetStateAction<DecryptedImage[]>>,
  showToast: (msg: string, type?: 'success' | 'error') => void
) {
  const { user } = useAuth();
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedForDeletion, setSelectedForDeletion] = useState<string[]>([]);
  const [isDeletingMultiple, setIsDeletingMultiple] = useState(false);
  const [isCleaningDuplicates, setIsCleaningDuplicates] = useState(false);
  const [duplicatesToDelete, setDuplicatesToDelete] = useState<string[]>([]);
  const [lastSelectedIndex, setLastSelectedIndex] = useState<number | null>(null);

  const handleSelectionClick = (img: DecryptedImage, index: number, e: React.MouseEvent) => {
    if (e?.shiftKey && lastSelectedIndex !== null) {
      const start = Math.min(lastSelectedIndex, index);
      const end = Math.max(lastSelectedIndex, index);
      const rangeIds = images.slice(start, end + 1).map(i => i.id);
      setSelectedForDeletion(prev => {
        const newSet = new Set(prev);
        rangeIds.forEach(id => newSet.add(id));
        return Array.from(newSet);
      });
    } else {
      setSelectedForDeletion(prev => 
        prev.includes(img.id) ? prev.filter(id => id !== img.id) : [...prev, img.id]
      );
    }
    setLastSelectedIndex(index);
  };

  const handleDeleteMultiple = async () => {
    setIsDeletingMultiple(false);
    const ids = [...selectedForDeletion];
    
    setImages(prev => prev.filter(img => !ids.includes(img.id)));
    setSelectedForDeletion([]);
    setIsSelectionMode(false);

    try {
      for (const id of ids) {
        let cachedImage = await getImageFromCache(id);
        if (!cachedImage) {
          try {
            const res = await fetch(`/api/storage/image/${id}`);
            if (res.ok) {
              const data = await res.json();
              if (data.success && data.image) {
                cachedImage = data.image;
              }
            }
          } catch (fetchErr) {
            console.warn('Erro ao obter imagem para salvar na lixeira:', fetchErr);
          }
        }

        if (cachedImage) {
          await saveToTrash({
            ...cachedImage,
            deletedAt: Date.now()
          });
        } else {
          const stateImg = images.find(img => img.id === id);
          if (stateImg) {
            await saveToTrash({
              id: stateImg.id,
              ciphertext: '',
              iv: '',
              createdAt: stateImg.createdAt || Date.now(),
              deletedAt: Date.now(),
              isChunked: stateImg.isChunked || false,
              chunkCount: stateImg.chunkCount || 1,
              contentType: stateImg.contentType || 'image/png',
              totalSize: stateImg.totalSize || 0,
              thumbnailCiphertext: '',
              thumbnailIv: '',
            });
          }
        }
        await removeImageFromCache(id);
        
        if (user && navigator.onLine) {
          try {
            await deleteDoc(doc(dbPrimary, 'images', id));
          } catch (fsErr) {
            console.warn('Erro ao deletar do Firestore ao mover para lixeira:', fsErr);
          }
          try {
            await fetch(`/api/storage/image/${id}`, { method: 'DELETE' });
          } catch (serverErr) {
            console.warn('Erro ao deletar do servidor local:', serverErr);
          }
        }
      }
      showToast(`${ids.length} mídias movidas para a lixeira!`);
    } catch (error) {
      console.error('Erro ao excluir imagens:', error);
      showToast('Erro ao excluir imagens.', 'error');
    }
  };

  const handleCleanDuplicates = async () => {
    setIsCleaningDuplicates(false);
    const ids = [...duplicatesToDelete];
    
    setImages(prev => prev.filter(img => !ids.includes(img.id)));
    setDuplicatesToDelete([]);
    setIsSelectionMode(false);

    try {
      for (const id of ids) {
        let cachedImage = await getImageFromCache(id);
        if (!cachedImage) {
          try {
            const res = await fetch(`/api/storage/image/${id}`);
            if (res.ok) {
              const data = await res.json();
              if (data.success && data.image) {
                cachedImage = data.image;
              }
            }
          } catch (fetchErr) {
            console.warn('Erro ao obter imagem para salvar na lixeira:', fetchErr);
          }
        }

        if (cachedImage) {
          await saveToTrash({
            ...cachedImage,
            deletedAt: Date.now()
          });
        } else {
          const stateImg = images.find(img => img.id === id);
          if (stateImg) {
            await saveToTrash({
              id: stateImg.id,
              ciphertext: '',
              iv: '',
              createdAt: stateImg.createdAt || Date.now(),
              deletedAt: Date.now(),
              isChunked: stateImg.isChunked || false,
              chunkCount: stateImg.chunkCount || 1,
              contentType: stateImg.contentType || 'image/png',
              totalSize: stateImg.totalSize || 0,
              thumbnailCiphertext: '',
              thumbnailIv: '',
            });
          }
        }
        await removeImageFromCache(id);
        
        if (user && navigator.onLine) {
          try {
            await deleteDoc(doc(dbPrimary, 'images', id));
          } catch (fsErr) {
            console.warn('Erro ao deletar do Firestore ao limpar duplicatas:', fsErr);
          }
          try {
            await fetch(`/api/storage/image/${id}`, { method: 'DELETE' });
          } catch (serverErr) {
            console.warn('Erro ao deletar do servidor local:', serverErr);
          }
        }
      }
      showToast(`${ids.length} duplicatas movidas para a lixeira!`);
    } catch (error) {
      console.error('Erro ao limpar duplicatas:', error);
      showToast('Erro ao limpar duplicatas.', 'error');
    }
  };

  return {
    isSelectionMode,
    setIsSelectionMode,
    selectedForDeletion,
    setSelectedForDeletion,
    isDeletingMultiple,
    setIsDeletingMultiple,
    isCleaningDuplicates,
    setIsCleaningDuplicates,
    duplicatesToDelete,
    setDuplicatesToDelete,
    lastSelectedIndex,
    setLastSelectedIndex,
    handleSelectionClick,
    handleDeleteMultiple,
    handleCleanDuplicates,
  };
}
