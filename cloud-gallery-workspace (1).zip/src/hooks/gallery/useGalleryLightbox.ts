import React, { useState, useEffect } from "react";
import { DecryptedImage } from "../../types";

interface UseGalleryLightboxProps {
  images: DecryptedImage[];
  selectedImage: string | null;
  selectedImageId: string | null;
  setSelectedImage: (img: string | null) => void;
  setSelectedImageId: (id: string | null) => void;
  setSelectedImageIsVideo: (isVideo: boolean) => void;
  fetchFullMedia: (img: DecryptedImage) => Promise<void>;
  securityImageId: string | null;
  extraPassword: string | null;
  resetFailedAttempts: () => Promise<void>;
  registerFailedAttempt: () => Promise<{ lockedUntil: string | null }>;
  lockVault: () => void;
  isSelectionMode: boolean;
  handleSelectionClick: (img: DecryptedImage, index: number, e: React.MouseEvent) => void;
  showToast: (message: string, type?: "success" | "error" | "info" | "warning") => void;
  isExtraUnlocked: boolean;
  setIsExtraUnlocked: (val: boolean) => void;
}

export function useGalleryLightbox({
  images,
  selectedImage,
  selectedImageId,
  setSelectedImage,
  setSelectedImageId,
  setSelectedImageIsVideo,
  fetchFullMedia,
  securityImageId,
  extraPassword,
  resetFailedAttempts,
  registerFailedAttempt,
  lockVault,
  isSelectionMode,
  handleSelectionClick,
  showToast,
  isExtraUnlocked,
  setIsExtraUnlocked,
}: UseGalleryLightboxProps) {
  const [imageFit, setImageFit] = useState<"contain" | "cover">("contain");
  const [showControls, setShowControls] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [extraPasswordInput, setExtraPasswordInput] = useState("");
  const [isPromptingExtra, setIsPromptingExtra] = useState<string | null>(null);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () =>
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
  }, []);

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    if (selectedImage && showControls) {
      timeout = setTimeout(() => {
        setShowControls(false);
      }, 3000);
    }
    return () => clearTimeout(timeout);
  }, [selectedImage, showControls]);

  const closeLightbox = async () => {
    if (document.fullscreenElement && document.exitFullscreen) {
      try {
        await document.exitFullscreen();
      } catch (err) {
        console.error(err);
      }
    }
    setIsZoomed(false);
    setSelectedImage(null);
    setSelectedImageId(null);
    const url = new URL(window.location.href);
    url.searchParams.delete("image");
    window.history.replaceState({}, "", url);
  };

  const handleImageClick = async (
    img: DecryptedImage,
    index: number,
    e: React.MouseEvent,
  ) => {
    if (isSelectionMode) {
      handleSelectionClick(img, index, e);
      return;
    }
    if (img.failed) return;

    if (img.id === securityImageId && !isExtraUnlocked && extraPassword) {
      setIsPromptingExtra(img.id);
      return;
    }

    const isVideo =
      img.isVideo || img.contentType?.startsWith("video/") || false;
    setSelectedImageIsVideo(isVideo);
    setSelectedImageId(img.id);
    setShowControls(true);

    const url = new URL(window.location.href);
    url.searchParams.set("image", img.id);
    window.history.replaceState({}, "", url);

    await fetchFullMedia(img);
  };

  const handleNextImage = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!selectedImageId) return;
    const currentIndex = images.findIndex((img) => img.id === selectedImageId);
    if (currentIndex < images.length - 1) {
      const nextImg = images[currentIndex + 1];
      setIsZoomed(false);
      handleImageClick(nextImg, currentIndex + 1, e || ({} as any));
    }
  };

  const handlePrevImage = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!selectedImageId) return;
    const currentIndex = images.findIndex((img) => img.id === selectedImageId);
    if (currentIndex > 0) {
      const prevImg = images[currentIndex - 1];
      setIsZoomed(false);
      handleImageClick(prevImg, currentIndex - 1, e || ({} as any));
    }
  };

  const handleExtraPasswordSubmit = async (
    e?: React.FormEvent | React.KeyboardEvent,
  ) => {
    e?.preventDefault();
    if (extraPasswordInput.trim() === extraPassword?.trim()) {
      setIsExtraUnlocked(true);
      await resetFailedAttempts();

      const img = images.find((i) => i.id === isPromptingExtra);
      if (img) {
        setSelectedImage(img.url);
        setSelectedImageId(img.id);
        setShowControls(true);
        const url = new URL(window.location.href);
        url.searchParams.set("image", img.id);
        window.history.replaceState({}, "", url);
      }
      setIsPromptingExtra(null);
      setExtraPasswordInput("");
    } else {
      const { lockedUntil } = await registerFailedAttempt();
      if (lockedUntil) {
        showToast(
          "Muitas tentativas falhas. Cofre bloqueado temporariamente.",
          "error",
        );
        setIsPromptingExtra(null);
        setExtraPasswordInput("");
        lockVault();
      } else {
        showToast("Senha extra incorreta", "error");
      }
    }
  };

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        }
      }
    } catch (err) {
      console.error("Erro ao tentar alternar tela cheia:", err);
    }
  };

  return {
    imageFit,
    setImageFit,
    showControls,
    setShowControls,
    isFullscreen,
    isZoomed,
    setIsZoomed,
    isShareOpen,
    setIsShareOpen,
    extraPasswordInput,
    setExtraPasswordInput,
    isPromptingExtra,
    setIsPromptingExtra,
    isExtraUnlocked,
    setIsExtraUnlocked,
    closeLightbox,
    handleImageClick,
    handleNextImage,
    handlePrevImage,
    handleExtraPasswordSubmit,
    toggleFullscreen,
  };
}
