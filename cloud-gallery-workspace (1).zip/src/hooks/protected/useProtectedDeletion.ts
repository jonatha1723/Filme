import React, { useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { getAuxKeyFromCache } from "../../utils/db";
import { doc, getDoc, deleteDoc } from "firebase/firestore";
import { dbPrimary } from "../../firebase";

interface UseProtectedDeletionProps {
  images: any[];
  setImages: React.Dispatch<React.SetStateAction<any[]>>;
  selectedIndex: number | null;
  setSelectedIndex: (idx: number | null) => void;
  loadProtectedImages: () => Promise<void>;
  setToast: (toast: { message: string; type: "success" | "error" | "info" } | null) => void;
}

export function useProtectedDeletion({
  images,
  setImages,
  selectedIndex,
  setSelectedIndex,
  loadProtectedImages,
  setToast,
}: UseProtectedDeletionProps) {
  const { user } = useAuth();
  const [imageToDelete, setImageToDelete] = useState<string | null>(null);

  const handleDelete = async () => {
    if (!imageToDelete) return;
    const id = imageToDelete;

    // Optimistically filter the image from the state
    setImages((prev) => prev.filter((img) => img.id !== id));

    // Close lightbox if the deleted image was active
    if (selectedIndex !== null && images[selectedIndex]?.id === id) {
      setSelectedIndex(null);
    }
    setImageToDelete(null);

    try {
      let fullImageJson: any = null;
      try {
        const response = await fetch(`/api/storage/image/${id}`);
        if (response.ok) {
          const resData = await response.json();
          if (resData.success && resData.image) {
            fullImageJson = resData.image;
          }
        }
      } catch (err) {
        console.warn("Erro ao buscar imagem completa do servidor para mover para a lixeira:", err);
      }

      let auxKey = await getAuxKeyFromCache(id);
      if (!auxKey && user && navigator.onLine) {
        try {
          const keyDoc = await getDoc(doc(dbPrimary, "media_keys", id));
          if (keyDoc.exists()) {
            auxKey = keyDoc.data().auxKey;
          }
        } catch (_) {}
      }

      const { saveToTrash, removeImageFromCache, removeAuxKeyFromCache } = await import("../../utils/db");

      if (fullImageJson) {
        await saveToTrash({
          id: fullImageJson.id,
          ciphertext: fullImageJson.ciphertext,
          iv: fullImageJson.iv,
          createdAt: fullImageJson.createdAt || Date.now(),
          deletedAt: Date.now(),
          isChunked: fullImageJson.isChunked || false,
          chunkCount: fullImageJson.chunkCount || 1,
          contentType: fullImageJson.contentType || "image/png",
          totalSize: fullImageJson.totalSize || 0,
          thumbnailCiphertext: fullImageJson.thumbnailCiphertext || "",
          thumbnailIv: fullImageJson.thumbnailIv || "",
          fileKeyCiphertext: fullImageJson.fileKeyCiphertext,
          fileKeyIv: fullImageJson.fileKeyIv,
          fileSalt: fullImageJson.fileSalt,
          isProtected: true,
          auxKey: auxKey
        });
      } else {
        const stateImg = images.find(img => img.id === id);
        if (stateImg) {
          await saveToTrash({
            id: stateImg.id,
            ciphertext: stateImg.ciphertext || "",
            iv: stateImg.iv || "",
            createdAt: stateImg.createdAt || Date.now(),
            deletedAt: Date.now(),
            isChunked: stateImg.isChunked || false,
            chunkCount: stateImg.chunkCount || 1,
            contentType: stateImg.contentType || "image/png",
            totalSize: stateImg.totalSize || 0,
            thumbnailCiphertext: stateImg.thumbnailCiphertext || "",
            thumbnailIv: stateImg.thumbnailIv || "",
            fileKeyCiphertext: stateImg.fileKeyCiphertext,
            fileKeyIv: stateImg.fileKeyIv,
            fileSalt: stateImg.fileSalt,
            isProtected: true,
            auxKey: auxKey
          });
        }
      }

      await removeImageFromCache(id);
      await removeAuxKeyFromCache(id);

      if (user && navigator.onLine) {
        try {
          await deleteDoc(doc(dbPrimary, "media_keys", id));
        } catch (fsErr) {
          console.warn("Erro ao deletar chave auxiliar do Firestore:", fsErr);
        }
        try {
          await fetch(`/api/storage/image/${id}`, { method: "DELETE" });
        } catch (serverErr) {
          console.warn("Erro ao deletar do servidor local:", serverErr);
        }
      }

      setToast({ message: "Imagem protegida movida para a lixeira!", type: "success" });
    } catch (error) {
      console.error("Erro ao excluir imagem protegida:", error);
      setToast({ message: "Erro ao excluir imagem protegida.", type: "error" });
      loadProtectedImages();
    }
  };

  return {
    imageToDelete,
    setImageToDelete,
    handleDelete,
  };
}
