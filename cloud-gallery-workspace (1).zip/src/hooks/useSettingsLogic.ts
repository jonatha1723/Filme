import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { clearImageCache, getAllImagesFromCache, removeImageFromCache } from '../utils/db';
import { decryptData } from '../utils/crypto';
import { decryptFileKey, decryptWithFileKey } from '../utils/fileCrypto';
import { useInstallPrompt } from '../utils/useInstallPrompt';
import { ToastType } from '../components/Toast';
import { dbPrimary } from '../firebase';
import { doc, getDoc } from 'firebase/firestore';

interface DecryptedImage {
  id: string;
  url: string;
  failed?: boolean;
  createdAt: number;
}

export function useSettingsLogic(isOpen: boolean, images: DecryptedImage[], onClose: () => void, onOpenTrash?: () => void) {
  const { user, logOut, extraPassword, securityImageId, updateExtraPassword, setSecurityImage, cryptoKey } = useAuth();
  const { isInstallable, promptToInstall, isInIframe } = useInstallPrompt();
  
  const [autoLockTimer, setAutoLockTimer] = useState<string>('15');
  const [privacyMode, setPrivacyMode] = useState<boolean>(false);
  const [toast, setToast] = useState<{ message: string; type: ToastType } | null>(null);
  const [clearing, setClearing] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [storageUsage, setStorageUsage] = useState<{ total: number; count: number }>({ total: 0, count: 0 });
  const [cloudStorageUsed, setCloudStorageUsed] = useState<number>(0);
  const [newExtraPassword, setNewExtraPassword] = useState(extraPassword || '');
  const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);
  const [isSettingsUnlocked, setIsSettingsUnlocked] = useState(false);
  const [unlockPasswordInput, setUnlockPasswordInput] = useState('');
  
  const tabs = [
    { id: 'security', label: 'Segurança', icon: 'Shield', description: 'Privacidade e bloqueio automático' },
    { id: 'fakeVault', label: 'Imagem Protegida', icon: 'Lock', description: 'Oculte fotos com senha de segurança' },
    { id: 'storage', label: 'Armazenamento', icon: 'HardDrive', description: 'Cache e limpeza de dados' },
    { id: 'repair', label: 'Reparar Cofre', icon: 'Wrench', description: 'Corrigir erros de carregamento' },
    { id: 'account', label: 'Conta', icon: 'User', description: 'Sua sessão e instalação' },
    { id: 'about', label: 'Sobre', icon: 'Sparkles', description: 'Versão e informações do app' },
  ] as const;

  const [activeTab, setActiveTab] = useState<typeof tabs[number]['id'] | 'menu'>('menu');

  useEffect(() => {
    setNewExtraPassword(extraPassword || '');
  }, [extraPassword]);

  useEffect(() => {
    const savedTimer = localStorage.getItem('autoLockTimer') || '15';
    setAutoLockTimer(savedTimer);
    const savedPrivacy = localStorage.getItem('privacyMode') === 'true';
    setPrivacyMode(savedPrivacy);
  }, []);

  useEffect(() => {
    const calculateStorage = async () => {
      try {
        const cachedImages = await getAllImagesFromCache();
        let totalBytes = 0;
        cachedImages.forEach(img => {
          if (img.ciphertext) {
            totalBytes += (img.ciphertext.length * 0.75);
          }
        });
        setStorageUsage({ total: totalBytes, count: cachedImages.length });
      } catch (e) {
        console.error('Error calculating storage:', e);
      }
    };

    const loadCloudStorageBytes = async () => {
      if (!user) return;
      try {
        const userDocRef = doc(dbPrimary, 'users', user.uid);
        const userDocSnap = await getDoc(userDocRef);
        if (userDocSnap.exists()) {
          const cloudUsage = userDocSnap.data().storageUsed || 0;
          setCloudStorageUsed(cloudUsage);
        }
      } catch (err) {
        console.error('Error fetching cloud storage used:', err);
      }
    };

    if (isOpen) {
      calculateStorage();
      loadCloudStorageBytes();
    }
  }, [isOpen, images, user]);

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleClose = () => {
    setIsSettingsUnlocked(false);
    setUnlockPasswordInput('');
    setActiveTab('menu');
    onClose();
  };

  const handleSaveTimer = (val: string) => {
    setAutoLockTimer(val);
    localStorage.setItem('autoLockTimer', val);
    showToast('Tempo de bloqueio atualizado');
  };

  const handleTogglePrivacy = () => {
    const newVal = !privacyMode;
    setPrivacyMode(newVal);
    localStorage.setItem('privacyMode', String(newVal));
    showToast(newVal ? 'Modo Privacidade ativado' : 'Modo Privacidade desativado');
  };

  const showToast = (message: string, type: ToastType = 'success') => {
    setToast({ message, type });
  };

  const handleRemoveFailedImages = async () => {
    setClearing(true);
    try {
      const failedImages = images.filter(img => img.failed);
      for (const img of failedImages) {
        await removeImageFromCache(img.id);
      }
      showToast(`${failedImages.length} imagens corrompidas removidas`);
    } catch (error) {
      showToast('Erro ao remover imagens corrompidas', 'error');
    } finally {
      setClearing(false);
    }
  };

  const handleClearCache = async () => {
    setClearing(true);
    try {
      await clearImageCache();
      showToast('Cache limpo com sucesso');
    } catch (error) {
      showToast('Erro ao limpar cache', 'error');
    } finally {
      setClearing(false);
    }
  };

  const handleBackupToDrive = async () => {
    setDownloading(true);
    try {
      showToast('Iniciando envio para o Drive...', 'info');
      const cachedImages = await getAllImagesFromCache();
      if (cachedImages.length === 0) {
        showToast('Nenhuma imagem no cache', 'info');
        setDownloading(false);
        return;
      }
      
      let successCount = 0;
      let lastError = '';
      for (const img of cachedImages) {
        if (img.ciphertext && img.iv) {
          try {
            const res = await fetch('/api/drive/upload', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                id: img.id,
                ciphertext: img.ciphertext,
                iv: img.iv,
                createdAt: img.createdAt
              })
            });
            const data = await res.json();
            if (data.success) {
              successCount++;
            } else {
              lastError = data.error || 'Erro desconhecido';
            }
          } catch (fetchErr: any) {
            lastError = fetchErr.message || 'Erro de conexão';
          }
        }
      }
      
      if (successCount === 0) {
        showToast(`Falha no backup: ${lastError || 'token do Drive expirado ou inválido'}. Adicione GOOGLE_DRIVE_REFRESH_TOKEN em suas variáveis de ambiente para corrigir.`, 'error');
      } else if (successCount < cachedImages.length) {
        showToast(`Backup parcial concluído! ${successCount} de ${cachedImages.length} imagens salvas no Drive.`, 'info');
      } else {
        showToast(`Backup concluído perfeitamente! ${successCount} mídias criptografadas foram salvas com sucesso em seu Google Drive.`, 'success');
      }
    } catch (error) {
      console.error('Erro ao migrar imagens:', error);
      showToast('Erro ao realizar backup das imagens', 'error');
    } finally {
      setDownloading(false);
    }
  };

  const handleDownloadAll = async () => {
    if (!cryptoKey) {
      showToast('Chave de criptografia não disponível', 'error');
      return;
    }
    setDownloading(true);
    try {
      const cachedImages = await getAllImagesFromCache();
      if (cachedImages.length === 0) {
        showToast('Nenhuma imagem no cache', 'info');
        return;
      }
      
      for (const img of cachedImages) {
        if (img.ciphertext && img.iv) {
          let decryptedBase64 = '';
          if (img.fileKeyCiphertext && img.fileKeyIv && img.fileSalt) {
            try {
              const fileKeyStr = await decryptFileKey(img.fileKeyCiphertext, img.fileKeyIv, cryptoKey);
              decryptedBase64 = await decryptWithFileKey(img.ciphertext, img.iv, fileKeyStr, img.fileSalt);
            } catch (e) {
              console.error('Download decryption failed', e);
              decryptedBase64 = await decryptData(img.ciphertext, img.iv, cryptoKey);
            }
          } else {
            decryptedBase64 = await decryptData(img.ciphertext, img.iv, cryptoKey);
          }
          
          const link = document.createElement('a');
          link.href = decryptedBase64;
          link.download = `image-${img.id}.png`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
      }
      showToast('Download iniciado...');
    } catch (error) {
      console.error('Erro ao baixar imagens:', error);
      showToast('Erro ao baixar imagens', 'error');
    } finally {
      setDownloading(false);
    }
  };

  const handleUpdateExtraPassword = async (customPassword?: string) => {
    const passwordToUse = (customPassword !== undefined ? customPassword : newExtraPassword).trim();
    if (!passwordToUse) {
      showToast('A senha não pode estar vazia', 'error');
      return;
    }
    setIsUpdatingPassword(true);
    try {
      await updateExtraPassword(passwordToUse);
      showToast('Senha de segurança atualizada com sucesso');
    } catch (error) {
      showToast('Erro ao atualizar senha de segurança', 'error');
    } finally {
      setIsUpdatingPassword(false);
    }
  };

  return {
    user,
    logOut,
    extraPassword,
    securityImageId,
    setSecurityImage,
    cryptoKey,
    isInstallable,
    promptToInstall,
    isInIframe,
    autoLockTimer,
    privacyMode,
    toast,
    setToast,
    clearing,
    setClearing,
    downloading,
    storageUsage,
    cloudStorageUsed,
    newExtraPassword,
    setNewExtraPassword,
    isUpdatingPassword,
    isSettingsUnlocked,
    setIsSettingsUnlocked,
    unlockPasswordInput,
    setUnlockPasswordInput,
    activeTab,
    setActiveTab,
    tabs,
    formatBytes,
    handleClose,
    handleSaveTimer,
    handleTogglePrivacy,
    showToast,
    handleRemoveFailedImages,
    handleClearCache,
    handleBackupToDrive,
    handleDownloadAll,
    handleUpdateExtraPassword,
  };
}
