import React, { createContext, useContext, useState } from "react";
import { authPrimary } from "../firebase";
import {
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  User,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
} from "firebase/auth";
import { decryptData } from "../utils/crypto";
import { removeKeyFromLocal } from "../utils/db";
import { AuthContextType } from "./AuthContextTypes";
import { useAutoLock } from "./useAutoLock";
import { useVaultOperations } from "./useVaultOperations";
import { useExtraPasswordSync } from "./useExtraPasswordSync";
import { useAuthInitialize } from "../hooks/useAuthInitialize";
import ConfirmModal from "../components/ConfirmModal";

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [cryptoKey, setCryptoKey] = useState<CryptoKey | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [extraPassword, setExtraPassword] = useState<string | null>(null);
  const [securityImageId, setSecurityImageId] = useState<string | null>(null);

  const setOrDecryptExtraPassword = async (extraVal: any, key: CryptoKey | null) => {
    console.log("[AuthContext] setOrDecryptExtraPassword called with extraVal type:", typeof extraVal, "hasKey:", !!key);
    if (extraVal && typeof extraVal === "object" && extraVal.ciphertext && extraVal.iv) {
      if (key) {
        try {
          const decrypted = await decryptData(extraVal.ciphertext, extraVal.iv, key);
          console.log("[AuthContext] Decrypted extra password successfully:", decrypted);
          setExtraPassword(decrypted);
        } catch (err) {
          console.error("[AuthContext] Error decrypting extra password:", err);
          setExtraPassword(null);
        }
      } else {
        console.log("[AuthContext] Extra password is encrypted but key is not available, setting to null");
        setExtraPassword(null);
      }
    } else if (typeof extraVal === "string" && extraVal) {
      console.log("[AuthContext] Extra password is a plain string, setting to:", extraVal);
      setExtraPassword(extraVal);
    } else {
      console.log("[AuthContext] Extra password is null or empty, setting to null");
      setExtraPassword(null);
    }
  };

  // Set up all vault lifecycle functions
  const {
    setupVault,
    unlockVault,
    lockVault,
    updateExtraPassword,
    setSecurityImage,
    changeVaultPin,
    registerFailedAttempt,
    resetFailedAttempts,
  } = useVaultOperations({
    user,
    cryptoKey,
    setCryptoKey,
    setNeedsSetup,
    extraPassword,
    setExtraPassword,
    setSecurityImageId,
    securityImageId,
  });

  // Set up auto lock
  useAutoLock(cryptoKey, lockVault);

  useAuthInitialize({
    setUser,
    setNeedsSetup,
    setOrDecryptExtraPassword,
    setSecurityImageId,
    setIsAuthReady,
    cryptoKey,
    setCryptoKey,
    setExtraPassword,
    isAuthReady,
  });

  const signIn = async () => {
    let retries = 0;
    const attemptSignIn = async (): Promise<void> => {
      try {
        await signInWithPopup(authPrimary, new GoogleAuthProvider());
      } catch (error: any) {
        if (error.code === "auth/network-request-failed" && retries < 2) {
          retries++;
          await new Promise(r => setTimeout(r, 1500));
          return attemptSignIn();
        }
        if (error.code === "auth/network-request-failed") {
          throw new Error("Falha na conexão com o servidor de autenticação. Verifique sua internet ou se há algum bloqueador de anúncios impedindo o acesso.");
        }
        console.error("Erro ao autenticar no projeto primário:", error);
        throw error;
      }
    };
    return attemptSignIn();
  };

  const signInEmail = async (e: string, p: string) => { await signInWithEmailAndPassword(authPrimary, e, p); };
  const signUpEmail = async (e: string, p: string) => { await createUserWithEmailAndPassword(authPrimary, e, p); };
  const resetPassword = async (e: string) => { await sendPasswordResetEmail(authPrimary, e); };

  const [isLogoutConfirmOpen, setIsLogoutConfirmOpen] = useState(false);

  const performActualLogOut = async () => {
    setIsLogoutConfirmOpen(false);
    if (user) await removeKeyFromLocal(user.uid);
    await signOut(authPrimary);
    setCryptoKey(null);
  };

  const logOut = async () => {
    setIsLogoutConfirmOpen(true);
  };

  useExtraPasswordSync(user, cryptoKey, setOrDecryptExtraPassword, setSecurityImageId);

  const [showProtected, setShowProtected] = useState(false);

  return (
    <AuthContext.Provider
      value={{
        user,
        cryptoKey,
        isAuthReady,
        needsSetup,
        signIn,
        signInEmail,
        signUpEmail,
        resetPassword,
        logOut,
        setupVault,
        unlockVault,
        lockVault,
        extraPassword,
        securityImageId,
        updateExtraPassword,
        setSecurityImage,
        changeVaultPin,
        showProtected,
        setShowProtected,
        registerFailedAttempt,
        resetFailedAttempts,
      }}
    >
      {children}
      <ConfirmModal
        isOpen={isLogoutConfirmOpen}
        onClose={() => setIsLogoutConfirmOpen(false)}
        onConfirm={performActualLogOut}
        title="Sair da Conta"
        message="Tem certeza que deseja sair de sua conta?"
        confirmText="Sair"
        cancelText="Cancelar"
      />
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
};
