import { User } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";
import { dbPrimary } from "../../firebase";
import { deriveKey, generateSalt, encryptData, decryptData } from "../../utils/crypto";
import {
  encryptFileKey,
  decryptFileKey,
} from "../../utils/fileCrypto";
import {
  saveKeyToLocal,
  getAllImagesFromCache,
  saveImageToCache,
  getTrashItems,
  saveToTrash,
} from "../../utils/db";

export async function changeVaultPinLogic(
  currentPin: string,
  newPin: string,
  user: User,
  cryptoKey: CryptoKey,
  extraPassword: string | null,
  setCryptoKey: (key: CryptoKey | null) => void
) {
  if (!user) throw new Error("Usuário não autenticado");
  if (!cryptoKey) throw new Error("Cofre não está desbloqueado");

  const cachedData = localStorage.getItem(`vault_data_${user.uid}`);
  if (!cachedData) throw new Error("Dados do cofre não encontrados localmente");
  const data = JSON.parse(cachedData);

  const currentSalt = data.salt;
  const currentDerivedKey = await deriveKey(currentPin, currentSalt, true);

  try {
    const check = await decryptData(
      data.verification.ciphertext,
      data.verification.iv,
      currentDerivedKey
    );
    if (check !== "vault-check") {
      throw new Error("Senha atual do cofre incorreta");
    }
  } catch (e) {
    throw new Error("Senha atual do cofre incorreta");
  }

  const newSalt = await generateSalt();
  const newDerivedKey = await deriveKey(newPin, newSalt, true);
  const newVerification = await encryptData("vault-check", newDerivedKey);

  let newEncryptedExtra = null;
  if (extraPassword) {
    newEncryptedExtra = await encryptData(extraPassword, newDerivedKey);
  } else if (data.extraPassword) {
    try {
      const decryptedExtra = await decryptData(
        data.extraPassword.ciphertext,
        data.extraPassword.iv,
        currentDerivedKey
      );
      newEncryptedExtra = await encryptData(decryptedExtra, newDerivedKey);
    } catch (err) {
      console.warn("Falha ao re-criptografar a senha extra das imagens:", err);
    }
  }

  const now = Date.now();
  const updatePayload: any = {
    salt: newSalt,
    verification: newVerification,
  };
  if (newEncryptedExtra) {
    updatePayload.extraPassword = newEncryptedExtra;
    updatePayload.extraPasswordUpdatedAt = now;
  }

  try {
    await setDoc(doc(dbPrimary, "users", user.uid), updatePayload, { merge: true });
  } catch (fsErr) {
    console.warn("Falha ao salvar nova senha no banco remoto, salvando localmente:", fsErr);
  }

  data.salt = newSalt;
  data.verification = newVerification;
  if (newEncryptedExtra) {
    data.extraPassword = newEncryptedExtra;
    data.extraPasswordUpdatedAt = now;
  }
  localStorage.setItem(`vault_data_${user.uid}`, JSON.stringify(data));

  // RE-ENCRIPTAR TODAS AS IMAGENS (LOCAL + SERVIDOR) PARA REFLETIR A NOVA CHAVE
  try {
    const serverRes = await fetch(`/api/storage/images?userId=${user.uid}`);
    let serverImages: any[] = [];
    if (serverRes.ok) {
      const respData = await serverRes.json();
      serverImages = respData.images || [];
    }

    const allCached = await getAllImagesFromCache();
    const allTrash = await getTrashItems();

    const processedIds = new Set<string>();

    const processMediaItem = async (item: any, isTrash: boolean) => {
      if (item.isChunked || item.ciphertext === "chunked_vault_data") return;

      let currentItem = { ...item };

      if (!currentItem.ciphertext || currentItem.ciphertext.length < 100) {
        const res = await fetch(`/api/storage/image/${currentItem.id}`);
        if (res.ok) {
          const respData = await res.json();
          if (respData.image) {
            currentItem = respData.image;
          } else return;
        } else return;
      }

      if (!currentItem.ciphertext) return;

      if (currentItem.fileKeyCiphertext && currentItem.fileKeyIv && currentItem.fileSalt) {
        // It uses a fileKey! We only need to decrypt the fileKey with old key and re-encrypt with new key!
        try {
          const fileKeyStr = await decryptFileKey(
            currentItem.fileKeyCiphertext,
            currentItem.fileKeyIv,
            currentDerivedKey
          );
          const newEncryptedFileKey = await encryptFileKey(fileKeyStr, newDerivedKey);
          currentItem.fileKeyCiphertext = newEncryptedFileKey.ciphertext;
          currentItem.fileKeyIv = newEncryptedFileKey.iv;
        } catch (e) {
          console.error("Failed to re-encrypt file key:", currentItem.id, e);
        }
      } else {
        // Old format (encrypted directly with master key). We must re-encrypt the whole file.
        const fullBase64 = await decryptData(currentItem.ciphertext, currentItem.iv, currentDerivedKey);
        const newFull = await encryptData(fullBase64, newDerivedKey);
        currentItem.ciphertext = newFull.ciphertext;
        currentItem.iv = newFull.iv;

        if (currentItem.thumbnailCiphertext && currentItem.thumbnailIv) {
          try {
            const thumbBase64 = await decryptData(
              currentItem.thumbnailCiphertext,
              currentItem.thumbnailIv,
              currentDerivedKey
            );
            const newThumb = await encryptData(thumbBase64, newDerivedKey);
            currentItem.thumbnailCiphertext = newThumb.ciphertext;
            currentItem.thumbnailIv = newThumb.iv;
          } catch (e) {
            console.warn("Falha ao re-criptografar thumbnail:", currentItem.id);
          }
        }
      }

      if (isTrash) {
        await saveToTrash(currentItem);
      } else {
        await saveImageToCache(currentItem);
      }

      await fetch("/api/storage/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...currentItem,
          userId: user.uid,
        }),
      });

      processedIds.add(currentItem.id);
    };

    const processBatch = async (items: any[], isTrash: boolean) => {
      const BATCH_SIZE = 5; // Lote menor pois as imagens podem ser grandes e consumir memória
      for (let i = 0; i < items.length; i += BATCH_SIZE) {
        const batch = items.slice(i, i + BATCH_SIZE);
        await Promise.all(
          batch.map(async (img) => {
            try {
              await processMediaItem(img, isTrash);
            } catch (err) {
              console.error(`Falha ao re-criptografar imagem ${isTrash ? "da lixeira" : ""}:`, img.id, err);
            }
          })
        );
      }
    };

    await processBatch(allCached, false);
    await processBatch(allTrash, true);

    const remainingServerImages = serverImages.filter((img: any) => !processedIds.has(img.id));
    await processBatch(remainingServerImages, false);
  } catch (e) {
    console.error("Erro massivo ao re-criptografar imagens:", e);
  }

  await saveKeyToLocal(user.uid, newDerivedKey);
  setCryptoKey(newDerivedKey);
}
