import { User } from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { dbPrimary } from "../../firebase";
import {
  deriveKey,
  generateSalt,
  encryptData,
  decryptData,
} from "../../utils/crypto";
import { saveKeyToLocal, removeKeyFromLocal } from "../../utils/db";
import { signVaultData, verifyVaultDataIntegrity, checkActiveIntrusion } from "../../utils/integrity";
import { UnlockResult } from "../AuthContextTypes";

export const getLockoutPenalty = (failedAttempts: number): number => {
  if (failedAttempts === 3) return 30 * 1000;
  if (failedAttempts === 4) return 60 * 1000;
  if (failedAttempts === 5) return 2 * 60 * 1000;
  if (failedAttempts === 6) return 5 * 60 * 1000;
  if (failedAttempts >= 7) return 24 * 60 * 60 * 1000;
  return 0;
};

export async function registerFailedAttemptLogic(
  user: User,
): Promise<{ lockedUntil: number | null; failedAttempts: number }> {
  let data;
  const cachedData = localStorage.getItem(`vault_data_${user.uid}`);
  if (cachedData) {
    data = JSON.parse(cachedData);
  } else {
    data = { failedAttempts: 0 };
  }

  // Valida integridade das tentativas locais salvas
  const isIntegrityValid = await verifyVaultDataIntegrity(
    user.uid,
    data.failedAttempts || 0,
    data.lockedUntil || null,
    data.integritySignature || null
  );

  let failedAttempts = (data.failedAttempts || 0) + 1;
  
  // Só pune com 24h se houver bypass ATIVO detectado em tempo de execução
  if (checkActiveIntrusion()) {
    console.warn("[INTEGRITY_SHIELD] Invasão ativa detectada! Bloqueio máximo preventivo.");
    failedAttempts = Math.max(7, failedAttempts);
  } else if (!isIntegrityValid && failedAttempts < 3) {
    // Se a integridade falhou mas são poucas tentativas, apenas resetamos o estado local
    // sem punir severamente, pois pode ser um erro de rotação de chave de sessão
    console.log("[INTEGRITY_SHIELD] Assinatura local inconsistente (Safe Sync).");
  } else if (!isIntegrityValid) {
    // Para casos suspeitos com muitas tentativas, forçamos o limite de segurança
    failedAttempts = Math.max(failedAttempts, 7);
  }

  const penalty = getLockoutPenalty(failedAttempts);
  const now = Date.now();
  const lockedUntil = penalty > 0 ? now + penalty : null;

  data.failedAttempts = failedAttempts;
  data.lockedUntil = lockedUntil;

  // Assina criptograficamente o novo estado de tentativas
  data.integritySignature = await signVaultData(user.uid, failedAttempts, lockedUntil);
  localStorage.setItem(`vault_data_${user.uid}`, JSON.stringify(data));

  try {
    await setDoc(
      doc(dbPrimary, "users", user.uid),
      {
        failedAttempts,
        lockedUntil,
      },
      { merge: true },
    );
  } catch (e) {
    console.warn("Error setting failed attempts remote:", e);
  }

  return { lockedUntil, failedAttempts };
}

export async function resetFailedAttemptsLogic(user: User): Promise<void> {
  let data;
  const cachedData = localStorage.getItem(`vault_data_${user.uid}`);
  if (cachedData) {
    data = JSON.parse(cachedData);
    if (data.failedAttempts > 0) {
      data.failedAttempts = 0;
      data.lockedUntil = null;
      
      // Assina criptograficamente o estado zerado
      data.integritySignature = await signVaultData(user.uid, 0, null);
      localStorage.setItem(`vault_data_${user.uid}`, JSON.stringify(data));

      try {
        await setDoc(
          doc(dbPrimary, "users", user.uid),
          {
            failedAttempts: 0,
            lockedUntil: null,
          },
          { merge: true },
        );
      } catch (e) {
        console.warn("Error resetting failed attempts remote:", e);
      }
    }
  }
}

export async function setupVaultLogic(
  pin: string,
  user: User,
  setCryptoKey: (key: CryptoKey | null) => void,
  setNeedsSetup: (needs: boolean) => void,
) {
  try {
    const salt = await generateSalt();
    const pinKey = await deriveKey(pin, salt, true);

    const verification = await encryptData("vault-check", pinKey);

    try {
      await setDoc(doc(dbPrimary, "users", user.uid), {
        email: user.email ? user.email.toLowerCase().trim() : "",
        salt,
        verification,
        createdAt: serverTimestamp(),
      });
    } catch (error: any) {
      console.warn("Async setDoc failed or offline", error);
    }

    const initialSignature = await signVaultData(user.uid, 0, null);
    localStorage.setItem(
      `vault_data_${user.uid}`,
      JSON.stringify({
        salt,
        verification,
        extraPassword: null,
        securityImageId: null,
        extraPasswordUpdatedAt: 0,
        securityImageIdUpdatedAt: 0,
        failedAttempts: 0,
        lockedUntil: null,
        integritySignature: initialSignature,
      }),
    );

    await saveKeyToLocal(user.uid, pinKey);
    setCryptoKey(pinKey);
    setNeedsSetup(false);
  } catch (error) {
    // Silent error on vault setup to prevent any logs containing password or stack trace leaks
    throw error;
  }
}

export async function unlockVaultLogic(
  pin: string,
  user: User,
  setCryptoKey: (key: CryptoKey | null) => void,
): Promise<UnlockResult> {
  try {
    let data;
    const cachedData = localStorage.getItem(`vault_data_${user.uid}`);

    if (cachedData) {
      data = JSON.parse(cachedData);
      // Valida integridade do localStorage offline
      const isIntegrityValid = await verifyVaultDataIntegrity(
        user.uid,
        data.failedAttempts || 0,
        data.lockedUntil || null,
        data.integritySignature || null
      );
      if (!isIntegrityValid) {
        // Em vez de punir imediatamente, verificamos se há intrusão ativa
        if (checkActiveIntrusion()) {
          console.warn("[INTEGRITY_SHIELD] Bypass detectado! Aplicando proteção máxima.");
          data.failedAttempts = 7;
          data.lockedUntil = Date.now() + getLockoutPenalty(7);
          data.integritySignature = await signVaultData(user.uid, data.failedAttempts, data.lockedUntil);
          localStorage.setItem(`vault_data_${user.uid}`, JSON.stringify(data));
        } else {
          // Se for apenas erro de assinatura (ex: reload), confiamos no cache mas avisamos o sistema
          console.log("[INTEGRITY_SHIELD] Sincronização de integridade necessária.");
          // O fluxo seguirá normalmente, validando o PIN contra o verification remoto/local
        }
      }
    } else {
      let userDocExists = false;
      let remoteData: any = null;

      try {
        const userDocPromise = getDoc(doc(dbPrimary, "users", user.uid));
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error("Timeout")), 4000),
        );
        const userDoc = (await Promise.race([
          userDocPromise,
          timeoutPromise,
        ])) as any;
        if (userDoc && userDoc.exists()) {
          userDocExists = true;
          remoteData = userDoc.data();
        }
      } catch (e) {
        console.warn("Could not retrieve remote vault config:", e);
      }

      if (!userDocExists || !remoteData) {
        return { success: false };
      }

      data = remoteData;
      const initialSig = await signVaultData(user.uid, data.failedAttempts || 0, data.lockedUntil || null);
      localStorage.setItem(
        `vault_data_${user.uid}`,
        JSON.stringify({
          salt: data.salt,
          verification: data.verification,
          extraPassword: data.extraPassword,
          securityImageId: data.securityImageId,
          extraPasswordUpdatedAt: data.extraPasswordUpdatedAt || 0,
          securityImageIdUpdatedAt: data.securityImageIdUpdatedAt || 0,
          failedAttempts: data.failedAttempts || 0,
          lockedUntil: data.lockedUntil || null,
          integritySignature: initialSig,
        }),
      );
    }

    const now = Date.now();
    if (data.lockedUntil && now < data.lockedUntil) {
      return {
        success: false,
        lockedUntil: data.lockedUntil,
        failedAttempts: data.failedAttempts,
      };
    }

    const salt = data.salt;
    const pinKey = await deriveKey(pin, salt, true);

    let isCorrect = false;
    if (data.verification) {
      try {
        const check = await decryptData(
          data.verification.ciphertext,
          data.verification.iv,
          pinKey,
        );
        if (check === "vault-check") {
          isCorrect = true;
        }
      } catch (e) {
        isCorrect = false;
      }
    }

    if (!isCorrect) {
      const { lockedUntil, failedAttempts } =
        await registerFailedAttemptLogic(user);
      return { success: false, lockedUntil, failedAttempts };
    }

    if (data.failedAttempts > 0) {
      await resetFailedAttemptsLogic(user);
    }

    await saveKeyToLocal(user.uid, pinKey);
    setCryptoKey(pinKey);
    return { success: true };
  } catch (error) {
    // Silent error on unlocking vault to avoid any sensitive trace logging
    return { success: false };
  }
}

export async function lockVaultLogic(
  user: User | null,
  setCryptoKey: (key: CryptoKey | null) => void,
) {
  if (user) {
    await removeKeyFromLocal(user.uid);
  }
  setCryptoKey(null);
}
