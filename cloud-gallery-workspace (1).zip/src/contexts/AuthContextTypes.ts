import { User } from "firebase/auth";

export interface UnlockResult {
  success: boolean;
  lockedUntil?: number | null;
  failedAttempts?: number;
}

export interface AuthContextType {
  user: User | null;
  cryptoKey: CryptoKey | null;
  isAuthReady: boolean;
  needsSetup: boolean;
  extraPassword: string | null;
  securityImageId: string | null;
  updateExtraPassword: (password: string) => Promise<void>;
  setSecurityImage: (imageId: string | null, customExtraPassword?: string) => Promise<void>;
  signIn: () => Promise<void>;
  signInEmail: (email: string, password: string) => Promise<void>;
  signUpEmail: (email: string, password: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logOut: () => Promise<void>;
  setupVault: (pin: string) => Promise<void>;
  unlockVault: (pin: string) => Promise<UnlockResult>;
  lockVault: () => Promise<void>;
  registerFailedAttempt: () => Promise<{ lockedUntil: number | null, failedAttempts: number }>;
  resetFailedAttempts: () => Promise<void>;
  changeVaultPin: (currentPin: string, newPin: string) => Promise<void>;
  showProtected: boolean;
  setShowProtected: (val: boolean) => void;
}

export const getPlainExtraPassword = (extraVal: any): string | null => {
  if (typeof extraVal === "string") return extraVal;
  return null;
};
