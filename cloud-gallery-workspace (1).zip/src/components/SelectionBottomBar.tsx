import React from 'react';
import { motion } from 'motion/react';
import { Wand2, Trash2 } from 'lucide-react';
import { DecryptedImage } from '../types';

interface SelectionBottomBarProps {
  selectedForDeletion: string[];
  setSelectedForDeletion: (val: string[]) => void;
  images: DecryptedImage[];
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  setDuplicatesToDelete: (val: string[]) => void;
  setIsCleaningDuplicates: (val: boolean) => void;
  setIsDeletingMultiple: (val: boolean) => void;
}

export default function SelectionBottomBar({
  selectedForDeletion,
  setSelectedForDeletion,
  images,
  showToast,
  setDuplicatesToDelete,
  setIsCleaningDuplicates,
  setIsDeletingMultiple
}: SelectionBottomBarProps) {
  const isAllSelected = selectedForDeletion.length === images.length;

  const handleSelectAllToggle = () => {
    if (isAllSelected) {
      setSelectedForDeletion([]);
    } else {
      setSelectedForDeletion(images.map(img => img.id));
    }
  };

  const handleCleanDuplicatesTrigger = () => {
    const urlMap = new Map<string, string[]>();
    images.forEach(img => {
      if (!img.failed && img.url) {
        const existing = urlMap.get(img.url) || [];
        urlMap.set(img.url, [...existing, img.id]);
      }
    });
    
    const idsToDelete: string[] = [];
    urlMap.forEach(ids => {
      if (ids.length > 1) {
        idsToDelete.push(...ids.slice(1));
      }
    });
    
    if (idsToDelete.length === 0) {
      showToast('Nenhuma imagem duplicada encontrada.', 'info');
    } else {
      setDuplicatesToDelete(idsToDelete);
      setIsCleaningDuplicates(true);
    }
  };

  return (
    <motion.div
      initial={{ y: 150, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 150, opacity: 0 }}
      transition={{ type: 'spring', damping: 25, stiffness: 220 }}
      className="fixed bottom-0 left-0 right-0 bg-[#0d0d10]/95 backdrop-blur-2xl border-t border-white/10 rounded-t-[28px] p-5 pb-safe z-40 shadow-[0_-15px_40px_-15px_rgba(0,0,0,0.8)]"
    >
      <div className="max-w-md mx-auto flex flex-col gap-4">
        {/* Info header row */}
        <div className="flex items-center justify-between px-1">
          <span className="text-white font-bold text-lg tracking-tight">
            {selectedForDeletion.length} selecionada{selectedForDeletion.length !== 1 ? 's' : ''}
          </span>
          <button
            onClick={handleSelectAllToggle}
            className="text-sm font-semibold text-zinc-400 hover:text-white active:scale-95 transition-all"
          >
            {isAllSelected ? 'Desmarcar tudo' : 'Selecionar tudo'}
          </button>
        </div>

        {/* Dynamic actions grid */}
        <div className="grid grid-cols-2 gap-3">
          <motion.button 
            whileTap={{ scale: 0.97 }}
            onClick={handleCleanDuplicatesTrigger}
            className="flex flex-col sm:flex-row items-center justify-center gap-2 py-3.5 px-4 bg-[#00df9a] hover:bg-[#00c588] text-zinc-950 rounded-2xl font-bold transition-all shadow-[0_4px_20px_rgba(0,223,154,0.2)] active:shadow-none"
          >
            <Wand2 size={18} className="shrink-0" strokeWidth={2.5} />
            <span className="text-sm tracking-tight text-center sm:text-left leading-tight">
              Limpar Duplicatas
            </span>
          </motion.button>

          <motion.button 
            whileTap={selectedForDeletion.length > 0 ? { scale: 0.97 } : {}}
            onClick={() => setIsDeletingMultiple(true)} 
            disabled={selectedForDeletion.length === 0}
            className={`flex flex-col sm:flex-row items-center justify-center gap-2 py-3.5 px-4 rounded-2xl font-bold transition-all border ${
              selectedForDeletion.length > 0
                ? 'bg-[#801b1b] hover:bg-[#942020] border-red-500/20 text-red-50 shadow-[0_4px_20px_rgba(128,27,27,0.2)]'
                : 'bg-zinc-900/40 border-zinc-800/50 text-zinc-600 cursor-not-allowed opacity-50'
            }`}
          >
            <Trash2 size={18} className="shrink-0" />
            <span className="text-sm tracking-tight text-center sm:text-left leading-tight">
              Excluir
            </span>
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}

