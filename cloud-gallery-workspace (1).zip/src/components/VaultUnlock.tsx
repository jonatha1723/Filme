import React, { useState, useEffect } from "react";
import { useAuth } from "../contexts/AuthContext";
import {
  Eye,
  EyeOff,
  Loader2,
  Timer,
  Shield,
} from "lucide-react";
import { motion } from "motion/react";
import { generateDeviceVerificationToken, verifyDeviceVerificationToken, checkActiveIntrusion } from "../utils/integrity";

export default function VaultUnlock() {
  const { unlockVault, logOut, user } = useAuth();
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [lockedUntil, setLockedUntil] = useState<number | null>(null);
  const [remainingTime, setRemainingTime] = useState<string>("");
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [deviceVerified, setDeviceVerified] = useState(false);
  const [deviceVerificationToken, setDeviceVerificationToken] = useState<string | null>(null);
  const [tamperAttemptDetected, setTamperAttemptDetected] = useState(false);

  useEffect(() => {
    // Monitor ativo de integridade local (Auto-Defesa)
    const intrusionInterval = setInterval(() => {
      if (checkActiveIntrusion()) {
        setTamperAttemptDetected(true);
      }
    }, 2500);

    return () => {
      clearInterval(intrusionInterval);
    };
  }, []);

  useEffect(() => {
    if (!user) return;
    const cachedData = localStorage.getItem(`vault_data_${user.uid}`);
    if (cachedData) {
      try {
        const data = JSON.parse(cachedData);
        if (data.failedAttempts) {
          setFailedAttempts(data.failedAttempts);
        }
        if (data.lockedUntil && data.lockedUntil > Date.now()) {
          setLockedUntil(data.lockedUntil);
        }
      } catch (e) {}
    }
  }, [user]);

  useEffect(() => {
    let interval: any;
    if (lockedUntil) {
      const updateTimer = () => {
        const now = Date.now();
        if (now >= lockedUntil) {
          setLockedUntil(null);
          setRemainingTime("");
        } else {
          const diff = lockedUntil - now;
          const seconds = Math.floor((diff / 1000) % 60);
          const minutes = Math.floor((diff / 1000 / 60) % 60);
          const hours = Math.floor((diff / 1000 / 60 / 60) % 24);
          const days = Math.floor(diff / 1000 / 60 / 60 / 24);

          if (days > 0) {
            setRemainingTime(`${days}d ${hours}h ${minutes}m`);
          } else if (hours > 0) {
            setRemainingTime(`${hours}h ${minutes}m ${seconds}s`);
          } else if (minutes > 0) {
            setRemainingTime(`${minutes}m ${seconds}s`);
          } else {
            setRemainingTime(`${seconds}s`);
          }
        }
      };

      updateTimer();
      interval = setInterval(updateTimer, 1000);
    }
    return () => clearInterval(interval);
  }, [lockedUntil]);

  const verifyDeviceAuth = async (): Promise<{ success: boolean; errorMsg?: string }> => {
    try {
      if (!window.PublicKeyCredential) {
        return { success: true };
      }

      const isAvailable = await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      if (!isAvailable) {
        return { success: true };
      }

      const challenge = new Uint8Array(32);
      window.crypto.getRandomValues(challenge);
      const userId = new Uint8Array(16);
      window.crypto.getRandomValues(userId);

      const options: CredentialCreationOptions = {
        publicKey: {
          challenge,
          rp: {
            name: "Santuário Cloud Gallery",
            id: window.location.hostname
          },
          user: {
            id: userId,
            name: user?.email || "usuario@cloudgallery",
            displayName: user?.email || "Usuário Cloud Gallery"
          },
          pubKeyCredParams: [
            { type: "public-key", alg: -7 },
            { type: "public-key", alg: -257 }
          ],
          timeout: 60000,
          authenticatorSelection: {
            authenticatorAttachment: "platform",
            userVerification: "required"
          }
        }
      };

      const credential = await navigator.credentials.create(options);
      return { success: !!credential };
    } catch (err: any) {
      console.warn("Device auth error:", err);
      const errMsg = err.message || "";
      if (
        err.name === "SecurityError" || 
        errMsg.includes("iframe") || 
        errMsg.includes("permission") || 
        errMsg.includes("feature is not enabled") || 
        errMsg.includes("Permissions Policy") ||
        errMsg.includes("publickey-credentials-create")
      ) {
        return {
          success: false,
          errorMsg: "Restrição de segurança (Iframe): Clique no botão 'Abrir em nova aba' (canto superior direito do visualizador) para validar com o PIN do seu PC ou celular com segurança."
        };
      }
      if (err.name === "NotAllowedError") {
        return {
          success: false,
          errorMsg: "Autenticação cancelada. Confirme o PIN ou biometria do seu aparelho para continuar."
        };
      }
      return {
        success: false,
        errorMsg: "Falha na validação de segurança. Confirme o PIN/Biometria do seu aparelho."
      };
    }
  };

  const handleDeviceVerify = async () => {
    if (checkActiveIntrusion()) {
      setError("Ambiente de execução comprometido. Reinicie a aplicação.");
      setTamperAttemptDetected(true);
      return;
    }

    setLoading(true);
    setError("Solicitando autenticação de segurança do dispositivo...");
    const authResult = await verifyDeviceAuth();
    setLoading(false);
    if (!authResult.success) {
      setError(authResult.errorMsg || "Autenticação do dispositivo necessária para continuar.");
    } else {
      if (user) {
        try {
          const token = await generateDeviceVerificationToken(user.uid);
          setDeviceVerificationToken(token);
          setDeviceVerified(true);
          setTamperAttemptDetected(false);
          setError("");
        } catch (e) {
          setError("Erro na assinatura de segurança. Tente novamente.");
        }
      }
    }
  };

  const handleSubmit = async (e?: React.FormEvent | React.KeyboardEvent) => {
    e?.preventDefault();
    if (lockedUntil) return;

    if (pin.length < 6 || pin.length > 30) {
      setError("A senha deve ter entre 6 e 30 caracteres");
      return;
    }

    if (failedAttempts >= 3) {
      // Validação criptográfica rigorosa do token de sessão
      const isTokenValid = await verifyDeviceVerificationToken(user?.uid || "", deviceVerificationToken);
      const isTampered = checkActiveIntrusion();

      // Só aplica o bloqueio de intrusão se houver evidência técnica clara de bypass
      // Se for apenas um token expirado/ausente, solicita nova verificação sem banir por 24h
      if (isTampered) {
        setTamperAttemptDetected(true);
        setError("Ambiente comprometido: Bloqueio de segurança ativo.");
        return;
      }

      if (!isTokenValid) {
        setDeviceVerified(false);
        setError("Validação do dispositivo necessária para continuar.");
        return;
      }
    }

    setLoading(true);
    setError("");

    // Simulate secure verification delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    try {
      const result = await unlockVault(pin);
      if (!result.success) {
        setLoading(false);
        setDeviceVerified(false); // Exige nova verificação do dispositivo para a próxima tentativa se errar
        setDeviceVerificationToken(null);
        if (result.failedAttempts) {
          setFailedAttempts(result.failedAttempts);
        } else {
          setFailedAttempts(prev => prev + 1);
        }

        if (result.lockedUntil && result.lockedUntil > Date.now()) {
          setLockedUntil(result.lockedUntil);
          setError(`Muitas tentativas falhas. Cofre bloqueado.`);
          setPin("");
        } else {
          setError("Falha ao desbloquear o cofre. Verifique sua senha.");
        }
      } else {
        setFailedAttempts(0);
        setDeviceVerified(false);
        setDeviceVerificationToken(null);
      }
    } catch (err) {
      setLoading(false);
      setDeviceVerified(false);
      // Silent error on unlocking to guarantee no logs on the site or console
      setError("Ocorreu um erro ao tentar desbloquear o cofre. Verifique se está offline ou tente de novo.");
    }
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4 sm:p-8 text-zinc-100">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm space-y-10"
      >
        <div className="text-center space-y-6">
          <div className="flex flex-col items-center gap-3">
            <h2 className="text-3xl sm:text-4xl font-light tracking-tight text-white drop-shadow-sm">
              Autenticação
            </h2>
            <p className="text-zinc-500 text-sm sm:text-[15px] px-2 sm:px-6 leading-relaxed max-w-[280px] sm:max-w-xs">
              Acesso seguro. Digite sua credencial para continuar.
            </p>
          </div>
        </div>

        {failedAttempts >= 3 && !deviceVerified && !lockedUntil && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-zinc-900/80 border border-zinc-800 text-zinc-300 text-xs rounded-xl p-4 text-center space-y-1.5 shadow-sm"
          >
            <div className="font-medium flex items-center justify-center gap-1.5 text-zinc-200">
              <Shield size={14} className="text-zinc-400" />
              Verificação de Segurança Exigida
            </div>
            <div className="text-zinc-500 leading-relaxed">
              Múltiplas tentativas incorretas detectadas. Clique no botão de verificação abaixo e confirme a autenticação do seu aparelho para continuar.
            </div>
          </motion.div>
        )}

        <div
          className="space-y-10"
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              if (failedAttempts >= 3 && !deviceVerified) {
                handleDeviceVerify();
              } else {
                handleSubmit();
              }
            }
          }}
        >
          <div className="space-y-4">
            <div className="relative group">
              <input
                type="text"
                name="secure-input-field"
                id="secure-input-field"
                style={{ WebkitTextSecurity: showPassword ? "none" : "disc" }}
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="none"
                spellCheck="false"
                data-lpignore="true"
                data-1p-ignore="true"
                data-form-type="other"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                disabled={loading || !!lockedUntil || (failedAttempts >= 3 && !deviceVerified)}
                className="w-full bg-zinc-900/50 border border-white/10 rounded-2xl py-4 text-center text-xl tracking-[0.2em] font-mono focus:outline-none focus:border-white/30 focus:bg-zinc-800/50 transition-all placeholder:text-zinc-700 placeholder:tracking-normal text-white disabled:opacity-40 disabled:cursor-not-allowed shadow-inner"
                placeholder={
                  lockedUntil 
                    ? "Conteúdo Bloqueado" 
                    : (failedAttempts >= 3 && !deviceVerified) 
                    ? "Confirme o Aparelho" 
                    : "Digite aqui"
                }
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300 p-3 transition-colors"
                disabled={lockedUntil || (failedAttempts >= 3 && !deviceVerified)}
              >
                {showPassword ? <EyeOff size={22} /> : <Eye size={22} />}
              </button>
            </div>

            {error && (
              <motion.p
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-red-400 text-xs text-center font-medium bg-red-400/10 py-2 rounded-lg px-3"
              >
                {error}
              </motion.p>
            )}
          </div>

          <div className="space-y-4">
            {lockedUntil ? (
              <button
                type="button"
                disabled={true}
                className="w-full bg-zinc-800 text-zinc-500 font-semibold py-4 rounded-2xl transition-all flex items-center justify-center gap-2 text-base cursor-not-allowed"
              >
                <Timer size={20} />
                Aguarde {remainingTime}
              </button>
            ) : failedAttempts >= 3 && !deviceVerified ? (
              <button
                type="button"
                onClick={handleDeviceVerify}
                disabled={loading}
                className="w-full bg-zinc-800 hover:bg-zinc-700 text-white border border-zinc-700/50 font-medium py-4 rounded-2xl transition-all flex items-center justify-center gap-2 active:scale-[0.98] text-base disabled:bg-zinc-900 disabled:text-zinc-600 disabled:cursor-not-allowed shadow-sm"
              >
                {loading ? (
                  <Loader2 className="animate-spin" size={20} />
                ) : (
                  <>
                    <Shield size={20} />
                    Verificar Dispositivo (PIN)
                  </>
                )}
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleSubmit()}
                disabled={loading}
                className="w-full bg-white text-black font-semibold py-4 rounded-2xl transition-all flex items-center justify-center gap-2 active:scale-[0.98] text-base disabled:bg-zinc-800 disabled:text-zinc-500 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <div className="relative">
                    <motion.div
                      animate={{ opacity: [0.3, 0.6, 0.3] }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut",
                      }}
                      className="absolute inset-0 blur-md bg-black/20 rounded-full"
                    />
                    <Loader2 className="animate-spin relative z-10" size={20} />
                  </div>
                ) : (
                  "Desbloquear"
                )}
              </button>
            )}

            <button
              type="button"
              onClick={logOut}
              className="w-full text-zinc-400 hover:text-white text-sm font-semibold transition-colors py-3 rounded-2xl hover:bg-zinc-900/50"
            >
              Sair da conta
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
