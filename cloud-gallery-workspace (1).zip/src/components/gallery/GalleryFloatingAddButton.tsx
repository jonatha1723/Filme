import React from "react";
import { Plus } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface GalleryFloatingAddButtonProps {
  isSelectionMode: boolean;
  activeTab: string;
  setIsUploaderOpen: (open: boolean) => void;
}

export default function GalleryFloatingAddButton({
  isSelectionMode,
  activeTab,
  setIsUploaderOpen,
}: GalleryFloatingAddButtonProps) {
  return (
    <AnimatePresence>
      {!isSelectionMode && activeTab === "gallery" && (
        <motion.button
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsUploaderOpen(true)}
          className="fixed bottom-24 lg:bottom-8 right-6 lg:right-8 h-14 sm:h-16 px-4 sm:px-6 bg-white text-black rounded-full shadow-xl flex items-center justify-center z-40 gap-2 sm:gap-3 font-medium transition-all border border-white/20"
        >
          <Plus size={24} className="sm:w-6 sm:h-6" strokeWidth={2.5} />
          <span className="hidden sm:block text-base font-bold tracking-tight pr-2">
            Adicionar Fotos
          </span>
        </motion.button>
      )}
    </AnimatePresence>
  );
}
