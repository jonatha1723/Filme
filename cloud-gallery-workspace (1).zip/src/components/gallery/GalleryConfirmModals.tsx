import React from "react";
import ConfirmModal from "../ConfirmModal";

interface GalleryConfirmModalsProps {
  imageToDelete: string | null;
  setImageToDelete: (id: string | null) => void;
  handleDelete: () => Promise<void>;
  isDeletingMultiple: boolean;
  setIsDeletingMultiple: (val: boolean) => void;
  handleDeleteMultiple: () => Promise<void>;
  selectedForDeletion: string[];
  isCleaningDuplicates: boolean;
  setIsCleaningDuplicates: (val: boolean) => void;
  handleCleanDuplicates: () => Promise<void>;
  duplicatesToDelete: string[];
}

export default function GalleryConfirmModals({
  imageToDelete,
  setImageToDelete,
  handleDelete,
  isDeletingMultiple,
  setIsDeletingMultiple,
  handleDeleteMultiple,
  selectedForDeletion,
  isCleaningDuplicates,
  setIsCleaningDuplicates,
  handleCleanDuplicates,
  duplicatesToDelete,
}: GalleryConfirmModalsProps) {
  return (
    <>
      <ConfirmModal
        isOpen={!!imageToDelete}
        onClose={() => setImageToDelete(null)}
        onConfirm={handleDelete}
        title="Excluir Imagem"
        message="Tem certeza que deseja excluir esta imagem permanentemente?"
        confirmText="Excluir"
        cancelText="Cancelar"
      />
      <ConfirmModal
        isOpen={isDeletingMultiple}
        onClose={() => setIsDeletingMultiple(false)}
        onConfirm={handleDeleteMultiple}
        title="Excluir Imagens"
        message={`Tem certeza que deseja excluir ${selectedForDeletion.length} imagens permanentemente?`}
        confirmText="Excluir"
        cancelText="Cancelar"
      />
      <ConfirmModal
        isOpen={isCleaningDuplicates}
        onClose={() => setIsCleaningDuplicates(false)}
        onConfirm={handleCleanDuplicates}
        title="Limpar Duplicatas"
        message={`Encontramos ${duplicatesToDelete.length} imagens duplicadas. Deseja excluí-las permanentemente para liberar espaço?`}
        confirmText="Limpar"
        cancelText="Cancelar"
      />
    </>
  );
}
