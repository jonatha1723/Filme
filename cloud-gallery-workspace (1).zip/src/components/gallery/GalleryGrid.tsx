import React from "react";
import GalleryEmptyState from "../GalleryEmptyState";
import GalleryItem from "../GalleryItem";
import { DecryptedImage } from "../../types";

interface GalleryGridProps {
  loading: boolean;
  images: DecryptedImage[];
  isSelectionMode: boolean;
  selectedForDeletion: string[];
  securityImageId: string | null;
  isExtraUnlocked: boolean;
  extraPassword: string | null;
  handleImageClick: (img: DecryptedImage, index: number, e: React.MouseEvent) => void;
  setImageToDelete: (id: string | null) => void;
  setImageToProtect: (id: string | null) => void;
  setIsUploaderOpen: (open: boolean) => void;
}

export default function GalleryGrid({
  loading,
  images,
  isSelectionMode,
  selectedForDeletion,
  securityImageId,
  isExtraUnlocked,
  extraPassword,
  handleImageClick,
  setImageToDelete,
  setImageToProtect,
  setIsUploaderOpen,
}: GalleryGridProps) {
  if (loading && images.length === 0) {
    return (
      <main className="max-w-7xl mx-auto p-1.5 sm:p-4 pb-24 sm:pb-32 w-full">
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-1.5 sm:gap-4">
          {[...Array(18)].map((_, i) => (
            <div
              key={i}
              className="aspect-square bg-white/5 rounded-xl sm:rounded-2xl animate-pulse border border-white/5"
            />
          ))}
        </div>
      </main>
    );
  }

  if (images.length === 0) {
    return (
      <main className="max-w-7xl mx-auto p-1.5 sm:p-4 pb-24 sm:pb-32 w-full">
        <GalleryEmptyState setIsUploaderOpen={setIsUploaderOpen} />
      </main>
    );
  }

  return (
    <main className="max-w-7xl mx-auto p-1.5 sm:p-4 pb-24 sm:pb-32 w-full">
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-1.5 sm:gap-4">
        {images.map((img, index) => (
          <GalleryItem
            key={img.id}
            img={img}
            index={index}
            isSelectionMode={isSelectionMode}
            selectedForDeletion={selectedForDeletion}
            securityImageId={securityImageId}
            isExtraUnlocked={isExtraUnlocked}
            extraPassword={extraPassword}
            handleImageClick={handleImageClick}
            setImageToDelete={setImageToDelete}
            setImageToProtect={setImageToProtect}
          />
        ))}
      </div>
    </main>
  );
}
