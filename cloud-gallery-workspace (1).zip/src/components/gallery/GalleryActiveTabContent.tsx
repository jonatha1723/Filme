import React from "react";
import ProtectedGallery from "../ProtectedGallery";
import TrashModal from "../TrashModal";
import SettingsModal from "../SettingsModal";
import GalleryGrid from "./GalleryGrid";
import { DecryptedImage } from "../../types";

interface GalleryActiveTabContentProps {
  activeTab: string;
  setActiveTab: (tab: 'gallery' | 'protected' | 'trash' | 'settings') => void;
  isSelectionMode: boolean;
  setIsSelectionMode: (mode: boolean) => void;
  selectedForDeletion: string[];
  setSelectedForDeletion: (ids: string[]) => void;
  setIsProtectedLightboxOpen: (open: boolean) => void;
  images: DecryptedImage[];
  loading: boolean;
  securityImageId: string | null;
  isExtraUnlocked: boolean;
  extraPassword: string | null;
  handleImageClick: (img: DecryptedImage, index: number, e: React.MouseEvent) => void;
  setImageToDelete: (id: string | null) => void;
  setImageToProtect: (id: string | null) => void;
  setIsUploaderOpen: (open: boolean) => void;
}

export default function GalleryActiveTabContent({
  activeTab,
  setActiveTab,
  isSelectionMode,
  setIsSelectionMode,
  selectedForDeletion,
  setSelectedForDeletion,
  setIsProtectedLightboxOpen,
  images,
  loading,
  securityImageId,
  isExtraUnlocked,
  extraPassword,
  handleImageClick,
  setImageToDelete,
  setImageToProtect,
  setIsUploaderOpen,
}: GalleryActiveTabContentProps) {
  if (activeTab === "protected") {
    return (
      <ProtectedGallery
        onBack={() => {
          setActiveTab("gallery");
          setIsSelectionMode(false);
          setSelectedForDeletion([]);
        }}
        onLightboxToggle={setIsProtectedLightboxOpen}
      />
    );
  }

  if (activeTab === "trash") {
    return (
      <TrashModal
        isOpen={true}
        onClose={() => setActiveTab("gallery")}
        isInline={true}
        onLightboxToggle={setIsProtectedLightboxOpen}
      />
    );
  }

  if (activeTab === "settings") {
    return (
      <SettingsModal
        isOpen={true}
        onClose={() => setActiveTab("gallery")}
        images={images}
        onOpenTrash={() => setActiveTab("trash")}
        isInline={true}
      />
    );
  }

  return (
    <GalleryGrid
      loading={loading}
      images={images}
      isSelectionMode={isSelectionMode}
      selectedForDeletion={selectedForDeletion}
      securityImageId={securityImageId}
      isExtraUnlocked={isExtraUnlocked}
      extraPassword={extraPassword}
      handleImageClick={handleImageClick}
      setImageToDelete={setImageToDelete}
      setImageToProtect={setImageToProtect}
      setIsUploaderOpen={setIsUploaderOpen}
    />
  );
}
