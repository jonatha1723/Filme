import React from "react";
import { X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import ImageUploader from "../ImageUploader";

interface GalleryUploaderModalProps {
  isUploaderOpen: boolean;
  setIsUploaderOpen: (open: boolean) => void;
  isUploading: boolean;
  setDroppedFiles: (files: File[]) => void;
  droppedFiles: File[];
  setIsUploading: (uploading: boolean) => void;
  loadImages: () => void;
}

export default function GalleryUploaderModal({
  isUploaderOpen,
  setIsUploaderOpen,
  isUploading,
  setDroppedFiles,
  droppedFiles,
  setIsUploading,
  loadImages,
}: GalleryUploaderModalProps) {
  return (
    <>
      <AnimatePresence>
        {isUploaderOpen && (
          <motion.div
            key="uploader-modal"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end md:items-center justify-center p-0 md:p-6"
          >
            <div
              onClick={() => !isUploading && setIsUploaderOpen(false)}
              className="absolute inset-0 bg-black/80"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{
                type: "spring",
                damping: 30,
                stiffness: 300,
                mass: 0.8,
              }}
              style={{ willChange: "transform" }}
              className="relative w-full max-w-lg bg-[#0a0a0a] rounded-t-[2.5rem] md:rounded-[2.5rem] shadow-2xl overflow-hidden border-t md:border border-white/10 flex flex-col h-[85dvh] md:h-auto md:max-h-[90vh] ring-1 ring-white/5"
            >
              <div className="p-4 sm:p-6 border-b border-white/10 flex items-center justify-between shrink-0">
                <h2 className="text-lg font-semibold text-white">
                  Adicionar Fotos
                </h2>
                <button
                  onClick={() => setIsUploaderOpen(false)}
                  className="p-2 rounded-full transition-colors hover:bg-white/5 text-zinc-400"
                >
                  <X size={20} />
                </button>
              </div>
              <div className="p-4 sm:p-6 overflow-y-auto flex-1 flex flex-col">
                <ImageUploader
                  onFilesSelected={(files) => {
                    setIsUploaderOpen(false);
                    setDroppedFiles(files);
                  }}
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="hidden" aria-hidden="true" style={{ display: "none" }}>
        <ImageUploader
          onComplete={() => {
            setDroppedFiles([]);
            loadImages();
          }}
          onUploadingStateChange={setIsUploading}
          initialFiles={droppedFiles}
        />
      </div>
    </>
  );
}
