import React from "react";
import { FolderDown, Loader2 } from "lucide-react";
import { motion } from "motion/react";

export default function DownloadSourceButton() {
  const [isDownloading, setIsDownloading] = React.useState(false);

  // O botão deve ser visível apenas dentro do ambiente de preview do Google AI Studio
  const isAIStudioPreview = () => {
    if (typeof window === "undefined") return false;
    const hostname = window.location.hostname;
    return (
      hostname.includes("ais-dev-") ||
      hostname.includes("ais-pre-") ||
      hostname.includes("aistudio")
    );
  };

  if (!isAIStudioPreview()) {
    return null;
  }

  const handleDownload = async () => {
    if (isDownloading) return;
    setIsDownloading(true);

    try {
      // Direct file download using native window location or anchor element
      const response = await fetch("/api/download-source");
      if (!response.ok) {
        throw new Error("Falha ao preparar os arquivos do site");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "cloud-gallery-workspace.zip";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Erro ao baixar os arquivos:", error);
      alert("Houve um erro ao gerar o pacote de arquivos do site. Tente novamente.");
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <motion.button
      id="btn-download-source-floating"
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={handleDownload}
      disabled={isDownloading}
      className="fixed bottom-24 lg:bottom-8 left-6 lg:left-8 h-14 sm:h-16 px-4 sm:px-6 bg-black/80 text-white rounded-full shadow-2xl flex items-center justify-center z-[50] gap-2 sm:gap-3 font-medium transition-all border border-white/10 backdrop-blur-md cursor-pointer hover:bg-zinc-900/90 hover:border-white/20 active:bg-zinc-800"
      title="Baixar todos os arquivos do site (.zip)"
    >
      {isDownloading ? (
        <Loader2 size={20} className="animate-spin text-zinc-400" />
      ) : (
        <FolderDown size={20} className="text-emerald-400 sm:w-5 sm:h-5" />
      )}
      <span className="text-sm font-semibold tracking-tight text-zinc-100">
        {isDownloading ? "Gerando ZIP..." : "Baixar Código do Site"}
      </span>
    </motion.button>
  );
}
