import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, X } from 'lucide-react';

interface ConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  isDestructive?: boolean;
}

export default function ConfirmModal({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = 'Confirmar',
  cancelText = 'Cancelar',
  isDestructive = true
}: ConfirmModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          key="confirm-modal"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
        >
          <div
            onClick={onClose}
            className="absolute inset-0 bg-black/80"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 40 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 40 }}
            className="relative w-full max-w-[290px] bg-black border border-white/10 rounded-[2rem] p-6 shadow-2xl"
          >
            <div className="flex flex-col items-center text-center space-y-4">
              <motion.div 
                initial={{ rotate: -10, scale: 0.8 }}
                animate={{ rotate: 0, scale: 1 }}
                className={`w-12 h-12 rounded-[1.25rem] flex items-center justify-center ${
                  isDestructive ? 'bg-red-500/10 text-red-500 border border-red-500/20' : 'bg-white/10 text-white border border-white/5'
                } shadow-lg`}
              >
                <AlertTriangle size={24} strokeWidth={1.5} />
              </motion.div>
              
              <div className="space-y-1">
                <h3 className="text-xl font-bold text-white tracking-tight">{title}</h3>
                <p className="text-zinc-400 text-xs leading-relaxed px-1">
                  {message}
                </p>
              </div>

              <div className="flex flex-col w-full gap-2 pt-2">
                <button
                  id="confirm-modal-btn-confirm"
                  type="button"
                  onClick={() => {
                    onConfirm();
                    onClose();
                  }}
                  className={`w-full py-3 rounded-[1rem] font-bold transition-all active:scale-[0.96] text-sm ${
                    isDestructive 
                      ? 'bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/20' 
                      : 'bg-white text-black hover:bg-zinc-200'
                  }`}
                >
                  {confirmText}
                </button>
                <button
                  id="confirm-modal-btn-cancel"
                  type="button"
                  onClick={onClose}
                  className="w-full py-3 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-bold rounded-[1rem] transition-all active:scale-[0.96] text-sm border border-white/5"
                >
                  {cancelText}
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
