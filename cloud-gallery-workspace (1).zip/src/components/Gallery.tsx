import React from "react";
import ShareModal from "./ShareModal";
import Toast from "./Toast";
import GallerySidebar from "./GallerySidebar";
import Lightbox from "./Lightbox";
import ExtraPasswordPrompt from "./ExtraPasswordPrompt";
import GalleryHeader from "./GalleryHeader";
import SelectionBottomBar from "./SelectionBottomBar";
import { AnimatePresence } from "motion/react";
import { useGalleryLogic } from "../hooks/useGalleryLogic";
import DragOverlay from "./DragOverlay";
import MobileBottomNav from "./MobileBottomNav";
import ProtectImageModal from "./ProtectImageModal";
import GalleryUploaderModal from "./gallery/GalleryUploaderModal";
import GalleryActiveTabContent from "./gallery/GalleryActiveTabContent";
import GalleryConfirmModals from "./gallery/GalleryConfirmModals";
import GalleryFloatingAddButton from "./gallery/GalleryFloatingAddButton";
import DownloadSourceButton from "./gallery/DownloadSourceButton";

export default function Gallery() {
  const g = useGalleryLogic();
  const [isProtectedLightboxOpen, setIsProtectedLightboxOpen] = React.useState(false);

  return (
    <div className="min-h-screen bg-[#050505] text-zinc-100 selection:bg-white/20 flex animate-fadeIn">
      <DragOverlay isDraggingGlobal={g.isDraggingGlobal} />

      <GallerySidebar
        onViewGallery={() => { g.setActiveTab('gallery'); g.setIsSelectionMode(false); g.setSelectedForDeletion([]); }}
        onViewProtected={() => { g.setActiveTab('protected'); g.setIsSelectionMode(false); g.setSelectedForDeletion([]); }}
        onOpenTrash={() => { g.setActiveTab('trash'); g.setIsSelectionMode(false); }}
        onOpenSettings={() => { g.setActiveTab('settings'); g.setIsSelectionMode(false); }}
        onLockVault={g.lockVault}
        onLogOut={g.logOut}
        currentView={g.activeTab}
      />

      <div className="flex-1 flex flex-col min-w-0 relative">
        <GalleryConfirmModals
          imageToDelete={g.imageToDelete}
          setImageToDelete={g.setImageToDelete}
          handleDelete={g.handleDelete}
          isDeletingMultiple={g.isDeletingMultiple}
          setIsDeletingMultiple={g.setIsDeletingMultiple}
          handleDeleteMultiple={g.handleDeleteMultiple}
          selectedForDeletion={g.selectedForDeletion}
          isCleaningDuplicates={g.isCleaningDuplicates}
          setIsCleaningDuplicates={g.setIsCleaningDuplicates}
          handleCleanDuplicates={g.handleCleanDuplicates}
          duplicatesToDelete={g.duplicatesToDelete}
        />

        {g.activeTab === 'gallery' && (
          <GalleryHeader
            imagesCount={g.images.length}
            isSelectionMode={g.isSelectionMode}
            setIsSelectionMode={g.setIsSelectionMode}
            setSelectedForDeletion={g.setSelectedForDeletion}
            isInstallable={g.isInstallable}
            promptToInstall={g.promptToInstall}
            isInIframe={g.isInIframe}
            showToast={g.showToast}
            lockVault={g.lockVault}
            logOut={g.logOut}
            setIsSettingsOpen={(open) => open ? g.setActiveTab('settings') : g.setActiveTab('gallery')}
            backgroundSyncing={g.backgroundSyncing}
            backgroundSyncProgress={g.backgroundSyncProgress}
          />
        )}

        <GalleryActiveTabContent
          activeTab={g.activeTab}
          setActiveTab={g.setActiveTab}
          isSelectionMode={g.isSelectionMode}
          setIsSelectionMode={g.setIsSelectionMode}
          selectedForDeletion={g.selectedForDeletion}
          setSelectedForDeletion={g.setSelectedForDeletion}
          setIsProtectedLightboxOpen={setIsProtectedLightboxOpen}
          images={g.images}
          loading={g.loading}
          securityImageId={g.securityImageId}
          isExtraUnlocked={g.isExtraUnlocked}
          extraPassword={g.extraPassword}
          handleImageClick={g.handleImageClick}
          setImageToDelete={g.setImageToDelete}
          setImageToProtect={g.setImageToProtect}
          setIsUploaderOpen={g.setIsUploaderOpen}
        />
      </div>

      <GalleryFloatingAddButton
        isSelectionMode={g.isSelectionMode}
        activeTab={g.activeTab}
        setIsUploaderOpen={g.setIsUploaderOpen}
      />

      <AnimatePresence>
        {g.isSelectionMode && (
          <SelectionBottomBar
            selectedForDeletion={g.selectedForDeletion}
            setSelectedForDeletion={g.setSelectedForDeletion}
            images={g.images}
            showToast={g.showToast}
            setDuplicatesToDelete={g.setDuplicatesToDelete}
            setIsCleaningDuplicates={g.setIsCleaningDuplicates}
            setIsDeletingMultiple={g.setIsDeletingMultiple}
          />
        )}
      </AnimatePresence>

      <ExtraPasswordPrompt
        isOpen={!!g.isPromptingExtra}
        extraPasswordInput={g.extraPasswordInput}
        setExtraPasswordInput={g.setExtraPasswordInput}
        onClose={() => {
          g.setIsPromptingExtra(null);
          g.setExtraPasswordInput("");
        }}
        onSubmit={() => g.handleExtraPasswordSubmit()}
      />

      <GalleryUploaderModal
        isUploaderOpen={g.isUploaderOpen}
        setIsUploaderOpen={g.setIsUploaderOpen}
        isUploading={g.isUploading}
        setDroppedFiles={g.setDroppedFiles}
        droppedFiles={g.droppedFiles}
        setIsUploading={g.setIsUploading}
        loadImages={g.loadImages}
      />

      <AnimatePresence>
        {g.selectedImage && g.selectedImageId && (
          <Lightbox
            selectedImage={g.selectedImage}
            selectedImageId={g.selectedImageId}
            selectedImageIsVideo={g.selectedImageIsVideo}
            downloadingFull={g.downloadingFull}
            fullDownloadProgress={g.fullDownloadProgress}
            imageFit={g.imageFit}
            showControls={g.showControls}
            isZoomed={g.isZoomed}
            isFullscreen={g.isFullscreen}
            setIsZoomed={g.setIsZoomed}
            setImageFit={g.setImageFit}
            setIsShareOpen={g.setIsShareOpen}
            setShowControls={g.setShowControls}
            onClose={g.closeLightbox}
            onNext={g.handleNextImage}
            onPrev={g.handlePrevImage}
            onToggleFullscreen={g.toggleFullscreen}
          />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {g.toast && (
          <Toast
            key="toast-message"
            message={g.toast.message}
            type={g.toast.type}
            onClose={() => g.setToast(null)}
          />
        )}
      </AnimatePresence>

      <ProtectImageModal
        imageToProtect={g.imageToProtect}
        setImageToProtect={g.setImageToProtect}
      />

      <MobileBottomNav
        activeTab={g.activeTab}
        setActiveTab={g.setActiveTab}
        isSelectionMode={g.isSelectionMode}
        selectedImageId={g.selectedImageId}
        isProtectedLightboxOpen={isProtectedLightboxOpen}
        setIsSelectionMode={g.setIsSelectionMode}
        setSelectedForDeletion={g.setSelectedForDeletion}
      />

      {g.isShareOpen && g.selectedImageId && g.selectedImage && (
        <ShareModal
          isOpen={g.isShareOpen}
          onClose={() => g.setIsShareOpen(false)}
          imageId={g.selectedImageId}
          decryptedImageUrl={g.selectedImage}
        />
      )}

      <DownloadSourceButton />
    </div>
  );
}
