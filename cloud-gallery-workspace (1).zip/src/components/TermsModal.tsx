import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShieldCheck } from 'lucide-react';

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function TermsModal({ isOpen, onClose }: TermsModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: "10%" }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: "10%" }}
          transition={{ duration: 0.3, ease: [0.32, 0.72, 0, 1] }}
          className="fixed inset-0 z-[100] bg-black flex flex-col overflow-hidden"
        >
          <div className="flex flex-col h-full bg-zinc-950">
            {/* Header */}
            <div className="flex items-center justify-between p-5 sm:px-8 border-b border-white/5 bg-zinc-900/30 sticky top-0 z-10 w-full backdrop-blur-md">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center flex-shrink-0">
                  <ShieldCheck size={20} className="text-white" />
                </div>
                <h2 className="text-lg font-semibold text-white">Termos e Privacidade</h2>
              </div>
              <button
                onClick={onClose}
                className="w-10 h-10 flex items-center justify-center text-zinc-400 hover:text-white bg-zinc-800 hover:bg-zinc-700 rounded-full transition-colors"
                title="Fechar"
              >
                <X size={20} />
              </button>
            </div>
            
            {/* Content Scrollable Area */}
            <div className="flex-1 overflow-y-auto">
              <div className="p-6 sm:p-10 md:py-12 md:px-16 max-w-4xl mx-auto w-full space-y-10 text-sm sm:text-base text-zinc-300 leading-relaxed">
                <section className="space-y-4">
                  <h3 className="text-white font-semibold text-lg flex items-center gap-2">
                    <span className="w-6 h-6 rounded-md bg-white/10 flex items-center justify-center text-xs font-bold text-white">1</span>
                    Aceitação dos Termos
                  </h3>
                  <p className="pl-8 text-zinc-400">
                    Ao criar uma conta ou utilizar os serviços do Cloud Gallery ("nós", "nosso" ou "o Aplicativo"), 
                    você concorda em estar vinculado a estes Termos de Uso e à nossa Política de Privacidade. 
                    Se você não concorda com qualquer parte destes termos, você não deve usar ou acessar nossos serviços.
                  </p>
                </section>

                <section className="space-y-4">
                  <h3 className="text-white font-semibold text-lg flex items-center gap-2">
                    <span className="w-6 h-6 rounded-md bg-white/10 flex items-center justify-center text-xs font-bold text-white">2</span>
                    Descrição do Serviço
                  </h3>
                  <p className="pl-8 text-zinc-400">
                    O Cloud Gallery fornece um serviço de armazenamento em nuvem para imagens e arquivos pessoais, 
                    com foco na segurança e criptografia avançada. O serviço é destinado ao uso estritamente pessoal. 
                    Não nos responsabilizamos pela natureza do conteúdo enviado pelo usuário.
                  </p>
                </section>

                <section className="space-y-4">
                  <h3 className="text-white font-semibold text-lg flex items-center gap-2">
                    <span className="w-6 h-6 rounded-md bg-white/10 flex items-center justify-center text-xs font-bold text-white">3</span>
                    Contas e Segurança
                  </h3>
                  <ul className="list-none pl-8 space-y-4 text-zinc-400">
                    <li className="relative before:content-[''] before:absolute before:left-[-12px] before:top-[10px] before:w-1.5 before:h-1.5 before:bg-white/30 before:rounded-full">
                      Você deve fornecer informações precisas e completas ao criar uma conta.
                    </li>
                    <li className="relative before:content-[''] before:absolute before:left-[-12px] before:top-[10px] before:w-1.5 before:h-1.5 before:bg-white/30 before:rounded-full">
                      Você é inteiramente responsável por manter a confidencialidade de sua senha, chave de criptografia ou sequência gráfica (Padrão de Segurança).
                    </li>
                    <li className="relative before:content-[''] before:absolute before:left-[-12px] before:top-[10px] before:w-1.5 before:h-1.5 before:bg-white/30 before:rounded-full">
                      <strong className="text-zinc-200">Aviso Crítico:</strong> O Cloud Gallery utiliza criptografia de ponta a ponta (E2EE) para proteger seus arquivos. 
                      Nós não possuímos acesso às suas chaves privadas. Se você perder sua chave de criptografia, seus arquivos armazenados no "Cofre" 
                      ou em álbuns criptografados serão irrecuperáveis permanentemente.
                    </li>
                  </ul>
                </section>

                <section className="space-y-4">
                  <h3 className="text-white font-semibold text-lg flex items-center gap-2">
                    <span className="w-6 h-6 rounded-md bg-white/10 flex items-center justify-center text-xs font-bold text-white">4</span>
                    Privacidade e Coleta de Dados
                  </h3>
                  <p className="pl-8 text-zinc-400">
                    Nós respeitamos profundamente a sua privacidade. A coleta de dados é reduzida ao mínimo funcional:
                  </p>
                  <ul className="list-none pl-8 space-y-4 text-zinc-400">
                    <li className="relative before:content-[''] before:absolute before:left-[-12px] before:top-[10px] before:w-1.5 before:h-1.5 before:bg-white/30 before:rounded-full">
                      <strong className="text-zinc-200">Informações Coletadas:</strong> Apenas o seu endereço de e-mail e dados técnicos básicos para funcionamento (ex: tokens de login do Firebase).
                    </li>
                    <li className="relative before:content-[''] before:absolute before:left-[-12px] before:top-[10px] before:w-1.5 before:h-1.5 before:bg-white/30 before:rounded-full">
                      <strong className="text-zinc-200">Proteção dos Arquivos:</strong> Suas imagens e arquivos subidos em áreas criptografadas não podem ser vistos ou acessados pelos mantenedores do Cloud Gallery. Os dados repousam criptografados (AES-GCM) nos nossos servidores em nuvem.
                    </li>
                    <li className="relative before:content-[''] before:absolute before:left-[-12px] before:top-[10px] before:w-1.5 before:h-1.5 before:bg-white/30 before:rounded-full">
                      <strong className="text-zinc-200">Compartilhamento e Terceiros:</strong> Nós não vendemos, não sublicenciamos e não comercializamos informações pessoais ou dados de usuários a nenhuma empresa terceira.
                    </li>
                  </ul>
                </section>

                <section className="space-y-4">
                  <h3 className="text-white font-semibold text-lg flex items-center gap-2">
                    <span className="w-6 h-6 rounded-md bg-white/10 flex items-center justify-center text-xs font-bold text-white">5</span>
                    Conteúdo e Conduta
                  </h3>
                  <p className="pl-8 text-zinc-400">
                    Você mantém integralmente todos os direitos sobre o conteúdo que você fornece. É estritamente proibido o uso da plataforma para fins ilegais, difamação, 
                    violação de propriedade intelectual de terceiros, ou o armazenamento de material de distribuição ilícita conforme as leis vigentes. 
                    Reservamo-nos o direito absoluto de suspender ou remover contas identificadas em violação legal (sob ordem judicial) sem aviso prévio.
                  </p>
                </section>

                <section className="space-y-4">
                  <h3 className="text-white font-semibold text-lg flex items-center gap-2">
                    <span className="w-6 h-6 rounded-md bg-white/10 flex items-center justify-center text-xs font-bold text-white">6</span>
                    Modificações no Serviço
                  </h3>
                  <p className="pl-8 text-zinc-400">
                    Reservamo-nos o direito de atualizar, modificar ou descontinuar, temporária ou permanentemente, 
                    o serviço ou qualquer parte dele com ou sem aviso prévio. Os Termos de Uso e Política de Privacidade também podem ser atualizados periodicamente. 
                    Seu uso contínuo após as notificações de alterações no aplicativo constitui sua aceitação tácita dos novos termos.
                  </p>
                </section>
                
                {/* Footer of modal */}
                <div className="pb-8 border-t border-white/5 pt-10 mt-12 flex flex-col sm:flex-row justify-between items-center gap-6">
                  <p className="text-xs text-zinc-500 font-medium">
                    Última atualização: {new Date().toLocaleDateString('pt-BR')}
                  </p>
                  <button
                    onClick={onClose}
                    className="w-full sm:w-auto bg-white text-black font-semibold py-3.5 px-10 rounded-xl hover:bg-zinc-200 transition-colors active:scale-95 flex items-center justify-center"
                  >
                    Entendido, Voltar
                  </button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
