import React from 'react';
import { motion } from 'motion/react';
import { Minimize2, Maximize2, Maximize, Minimize, Share2, Download, Trash2, X } from 'lucide-react';

interface LightboxControlsProps {
  selectedImage: string;
  imageFit: 'contain' | 'cover';
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  setImageFit: (fit: 'contain' | 'cover') => void;
  setIsShareOpen: (open: boolean) => void;
  onClose: () => void;
  onDelete?: () => void;
}

export default function LightboxControls({
  selectedImage,
  imageFit,
  isFullscreen,
  onToggleFullscreen,
  setImageFit,
  setIsShareOpen,
  onClose,
  onDelete,
}: LightboxControlsProps) {
  return (
    <motion.div 
      id="lightbox-header-controls"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="absolute top-4 right-4 sm:top-6 sm:right-6 flex items-center gap-2 sm:gap-4 z-10"
    >
      <button
        id="lightbox-btn-fullscreen"
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onToggleFullscreen();
        }}
        className="text-white/70 hover:text-white transition-colors p-2 sm:p-3 bg-black/40 backdrop-blur-md rounded-full hover:bg-black/60 active:scale-90"
        title={isFullscreen ? "Sair da Tela Cheia" : "Tela Cheia"}
      >
        {isFullscreen ? <Minimize2 size={20} className="sm:w-6 sm:h-6" /> : <Maximize2 size={20} className="sm:w-6 sm:h-6" />}
      </button>

      <button
        id="lightbox-btn-fit"
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setImageFit(imageFit === 'contain' ? 'cover' : 'contain');
        }}
        className="text-white/70 hover:text-white transition-colors p-2 sm:p-3 bg-black/40 backdrop-blur-md rounded-full hover:bg-black/60 active:scale-90"
        title={imageFit === 'contain' ? "Preencher Tela" : "Ajustar à Tela"}
      >
        {imageFit === 'contain' ? <Maximize size={20} className="sm:w-6 sm:h-6" /> : <Minimize size={20} className="sm:w-6 sm:h-6" />}
      </button>

      <button
        id="lightbox-btn-share"
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setIsShareOpen(true);
        }}
        className="text-white/70 hover:text-white transition-colors p-2 sm:p-3 bg-black/40 backdrop-blur-md rounded-full hover:bg-black/60 active:scale-90"
        title="Compartilhar Imagem"
      >
        <Share2 size={20} className="sm:w-6 sm:h-6" />
      </button>

      <a 
        id="lightbox-btn-download"
        href={selectedImage} 
        download={`secure-image-${Date.now()}.png`}
        className="text-white/70 hover:text-white transition-colors p-2 sm:p-3 bg-black/40 backdrop-blur-md rounded-full hover:bg-black/60 active:scale-90"
        onClick={(e) => e.stopPropagation()}
        title="Baixar Imagem"
      >
        <Download size={20} className="sm:w-6 sm:h-6" />
      </a>

      {onDelete && (
        <button
          id="lightbox-btn-delete"
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onDelete();
          }}
          className="text-white/70 hover:text-red-400 hover:bg-red-500/10 transition-colors p-2 sm:p-3 bg-black/40 backdrop-blur-md rounded-full hover:bg-black/60 active:scale-90"
          title="Excluir Imagem"
        >
          <Trash2 size={20} className="sm:w-6 sm:h-6" />
        </button>
      )}

      <button 
        id="lightbox-btn-close"
        type="button"
        className="text-white/70 hover:text-white transition-colors p-2 sm:p-3 bg-black/40 backdrop-blur-md rounded-full hover:bg-black/60 active:scale-90"
        onClick={(e) => {
          e.stopPropagation();
          onClose();
        }}
      >
        <X size={20} className="sm:w-6 sm:h-6" />
      </button>
    </motion.div>
  );
}
