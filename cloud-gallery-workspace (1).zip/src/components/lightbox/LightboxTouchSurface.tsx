import React, { useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { TransformWrapper, TransformComponent } from 'react-zoom-pan-pinch';

interface LightboxTouchSurfaceProps {
  selectedImage: string;
  selectedImageId: string;
  selectedImageIsVideo: boolean;
  downloadingFull: boolean;
  fullDownloadProgress: string;
  imageFit: 'contain' | 'cover';
  showControls: boolean;
  isZoomed: boolean;
  setIsZoomed: (zoomed: boolean) => void;
  setShowControls: (show: boolean | ((prev: boolean) => boolean)) => void;
  onClose: () => void;
  onNext: () => void;
  onPrev: () => void;
}

export default function LightboxTouchSurface({
  selectedImage,
  selectedImageId,
  selectedImageIsVideo,
  downloadingFull,
  fullDownloadProgress,
  imageFit,
  showControls,
  isZoomed,
  setIsZoomed,
  setShowControls,
  onClose,
  onNext,
  onPrev,
}: LightboxTouchSurfaceProps) {
  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);

  const handleControlsClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowControls(prev => !prev);
  };

  return (
    <div 
      id="lightbox-touch-surface"
      className="w-full h-full flex items-center justify-center relative touch-none"
      onClick={handleControlsClick}
      onTouchStart={(e) => {
        if (isZoomed || e.touches.length > 1) {
          touchStartX.current = null;
          touchStartY.current = null;
          return;
        }
        touchStartX.current = e.touches[0].clientX;
        touchStartY.current = e.touches[0].clientY;
      }}
      onTouchEnd={(e) => {
        if (!touchStartX.current || !touchStartY.current || isZoomed || e.touches.length > 0) {
          touchStartX.current = null;
          touchStartY.current = null;
          return;
        }
        const touchEndX = e.changedTouches[0].clientX;
        const touchEndY = e.changedTouches[0].clientY;
        const distanceX = touchStartX.current - touchEndX;
        const distanceY = touchStartY.current - touchEndY;
        
        if (Math.abs(distanceX) > Math.abs(distanceY)) {
          if (distanceX > 120) {
            onNext();
          } else if (distanceX < -120) {
            onPrev();
          }
        } else {
          if (distanceY < -150 || distanceY > 150) {
            onClose();
          }
        }
        touchStartX.current = null;
        touchStartY.current = null;
      }}
    >
      {selectedImageIsVideo ? (
        <div className="w-full h-full flex items-center justify-center relative bg-black">
          {downloadingFull ? (
            <div className="flex flex-col items-center justify-center text-center space-y-4">
              <Loader2 className="w-12 h-12 text-white animate-spin" />
              <p className="text-zinc-200 text-sm font-semibold">{fullDownloadProgress}</p>
            </div>
          ) : (
            <video
              id="lightbox-video"
              src={selectedImage || undefined}
              controls
              autoPlay
              playsInline
              className="w-full h-full max-h-full max-w-full object-contain bg-zinc-950"
              onClick={(e) => e.stopPropagation()}
              onContextMenu={(e) => e.preventDefault()}
            />
          )}
        </div>
      ) : downloadingFull ? (
        <div className="w-full h-full flex flex-col items-center justify-center text-center space-y-4">
          <Loader2 className="w-12 h-12 text-white animate-spin" />
          <p className="text-zinc-200 text-sm font-semibold">{fullDownloadProgress}</p>
        </div>
      ) : (
        <TransformWrapper
          key={selectedImageId}
          initialScale={1}
          minScale={1}
          maxScale={6}
          centerOnInit
          wheel={{ step: 0.05, smoothStep: 0.005 }}
          doubleClick={{ disabled: false, step: 2, mode: 'toggle' }}
          panning={{ disabled: false, velocityDisabled: false }}
          pinch={{ step: 5 }}
          limitToBounds={true}
          onTransformed={(ref) => {
            const zoomed = ref.state.scale > 1.01;
            if (zoomed !== isZoomed) {
              setIsZoomed(zoomed);
            }
          }}
        >
          <TransformComponent 
            wrapperClass="!w-full !h-full" 
            contentClass="!w-full !h-full flex items-center justify-center"
            wrapperStyle={{ width: "100%", height: "100%" }}
            contentStyle={{ width: "100%", height: "100%" }}
          >
            <motion.img
              id="lightbox-main-img"
              key={selectedImageId}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              src={selectedImage || undefined}
              alt="Full screen"
              className={`w-full h-full select-none cursor-grab active:cursor-grabbing ${imageFit === 'cover' ? 'object-cover' : 'object-contain'}`}
              onContextMenu={(e) => e.preventDefault()}
              onClick={(e) => e.stopPropagation()}
              draggable={false}
            />
          </TransformComponent>
        </TransformWrapper>
      )}
      
      <AnimatePresence>
        {showControls && (
          <>
            <motion.button
              id="lightbox-nav-prev"
              type="button"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onClick={(e) => {
                e.stopPropagation();
                onPrev();
              }}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-white/70 hover:text-white transition-colors p-3 bg-black/40 backdrop-blur-md rounded-full hover:bg-black/60 active:scale-90 hidden sm:block"
            >
              <ChevronLeft size={32} />
            </motion.button>
            <motion.button
              id="lightbox-nav-next"
              type="button"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              onClick={(e) => {
                e.stopPropagation();
                onNext();
              }}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-white/70 hover:text-white transition-colors p-3 bg-black/40 backdrop-blur-md rounded-full hover:bg-black/60 active:scale-90 hidden sm:block"
            >
              <ChevronRight size={32} />
            </motion.button>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
