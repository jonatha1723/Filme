import React from "react";
import { motion } from "motion/react";
import {
  Lock,
  Film,
  Image as ImageIcon,
  Play,
  Check,
  Trash2,
  Shield,
} from "lucide-react";
import { DecryptedImage } from "../types";

interface GalleryItemProps {
  key?: string;
  img: DecryptedImage;
  index: number;
  isSelectionMode: boolean;
  selectedForDeletion: string[];
  securityImageId: string | null;
  isExtraUnlocked: boolean;
  extraPassword: string | null;
  hideProtectButton?: boolean;
  handleImageClick: (
    img: DecryptedImage,
    index: number,
    e: React.MouseEvent,
  ) => Promise<void> | void;
  setImageToDelete: (id: string | null) => void;
  setImageToProtect?: (id: string | null) => void;
}

export default function GalleryItem({
  img,
  index,
  isSelectionMode,
  selectedForDeletion,
  securityImageId,
  isExtraUnlocked,
  extraPassword,
  hideProtectButton,
  handleImageClick,
  setImageToDelete,
  setImageToProtect,
}: GalleryItemProps) {
  const isSelected = selectedForDeletion.includes(img.id);
  const [showMobileOverlay, setShowMobileOverlay] = React.useState(false);
  const timerRef = React.useRef<NodeJS.Timeout | null>(null);
  const isLongPressRef = React.useRef(false);

  const handleTouchStart = () => {
    isLongPressRef.current = false;
    timerRef.current = setTimeout(() => {
      isLongPressRef.current = true;
      setShowMobileOverlay((prev) => !prev);
      if (navigator.vibrate) {
        try {
          navigator.vibrate(50);
        } catch (_) {}
      }
    }, 600); // 600ms long press threshold
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    if (isLongPressRef.current) {
      e.preventDefault();
      e.stopPropagation();
    }
  };

  const handleTouchMove = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
  };

  const onImageClick = (e: React.MouseEvent) => {
    if (showMobileOverlay) {
      e.stopPropagation();
      setShowMobileOverlay(false);
      return;
    }
    handleImageClick(img, index, e);
  };

  React.useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={`aspect-square bg-zinc-900 cursor-pointer group relative overflow-hidden rounded-xl sm:rounded-2xl shadow-lg ring-1 transition-all ${
        isSelectionMode && isSelected
          ? "ring-white ring-2 scale-[0.98]"
          : "ring-white/10 hover:ring-white/30"
      }`}
      onClick={onImageClick}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onTouchMove={handleTouchMove}
      onContextMenu={(e) => e.preventDefault()}
    >
      {img.failed ? (
        <div className="w-full h-full flex flex-col items-center justify-center text-zinc-700 p-2 text-center">
          <Lock size={24} className="mb-1 opacity-20" />
          <span className="text-[10px] font-bold uppercase tracking-tighter">
            Erro
          </span>
        </div>
      ) : img.id === securityImageId && !isExtraUnlocked && extraPassword ? (
        <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-900 text-zinc-500 group-hover:text-white transition-colors">
          <div className="relative">
            <Lock size={32} className="relative z-10" strokeWidth={1.5} />
          </div>
          <span className="mt-3 text-[10px] font-bold uppercase tracking-widest opacity-50">
            Protegida
          </span>
        </div>
      ) : (
        <div className="relative w-full h-full flex items-center justify-center bg-zinc-900/40 border border-white/5">
          {img.noThumbnail ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-zinc-400 group-hover:text-white transition-colors">
              {img.isVideo ? (
                <Film size={32} className="opacity-40 mb-1" strokeWidth={1.5} />
              ) : (
                <ImageIcon
                  size={32}
                  className="opacity-40 mb-1"
                  strokeWidth={1.5}
                />
              )}
              <span className="text-[9px] font-mono tracking-wider opacity-65 uppercase">
                {img.isVideo ? "Vídeo" : "Imagem"}
              </span>
            </div>
          ) : (
            <img
              src={img.url}
              alt=""
              className="w-full h-full object-cover transition-all duration-500 group-hover:brightness-90 select-none animate-fade-in"
              referrerPolicy="no-referrer"
              onContextMenu={(e) => e.preventDefault()}
              draggable={false}
            />
          )}
          {img.isVideo && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/10">
              <div className="p-2.5 bg-black/60 backdrop-blur-md text-white rounded-full border border-white/10 group-hover:bg-white group-hover:text-black transition-all group-hover:scale-110 shadow-lg">
                <Play size={16} fill="currentColor" className="w-4 h-4" />
              </div>
              {!img.noThumbnail && (
                <span className="absolute bottom-2 left-2 px-1.5 py-0.5 bg-black/70 backdrop-blur-md font-mono text-[9px] uppercase tracking-wider text-white font-semibold rounded border border-white/5 flex items-center gap-1">
                  <Film size={10} />
                  VÍDEO
                </span>
              )}
            </div>
          )}
        </div>
      )}

      {isSelectionMode && (
        <div className="absolute inset-0 bg-black/10 z-10 flex items-start justify-start p-2 sm:p-3 transition-colors">
          <div
            className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${isSelected ? "bg-white border-white" : "border-white/70 bg-black/40"}`}
          >
            {isSelected && <Check size={14} className="text-black" />}
          </div>
        </div>
      )}

      {!isSelectionMode && (
        <div className={`absolute top-2 right-2 transition-opacity z-20 flex gap-1 ${
          showMobileOverlay 
            ? "opacity-100 pointer-events-auto" 
            : "opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto"
        }`}>
          {extraPassword && !hideProtectButton && (
            <button
              onClick={async (e) => {
                e.stopPropagation();
                if (setImageToProtect) {
                  setImageToProtect(img.id);
                }
              }}
              className="p-2 sm:p-2.5 bg-black/40 hover:bg-emerald-500/90 text-white rounded-xl backdrop-blur-md transition-all active:scale-90 border border-white/10 hover:border-emerald-500"
              title="Proteger com Chave Auxiliar"
            >
              <Shield size={16} className="sm:w-4 sm:h-4" />
            </button>
          )}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setImageToDelete(img.id);
            }}
            className="p-2 sm:p-2.5 bg-black/40 hover:bg-red-500/90 text-white rounded-xl backdrop-blur-md transition-all active:scale-90 border border-white/10 hover:border-red-500"
            title="Excluir"
          >
            <Trash2 size={16} className="sm:w-4 sm:h-4" />
          </button>
        </div>
      )}
    </motion.div>
  );
}
