import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Shield, HardDrive, User, Trash2, Lock, Sparkles, Wrench } from 'lucide-react';
import Toast from './Toast';

import SecurityTab from './settings/SecurityTab';
import FakeVaultTab from './settings/FakeVaultTab';
import StorageTab from './settings/StorageTab';
import NewsTab from './settings/NewsTab';
import RepairTab from './settings/RepairTab';
import AccountTab from './settings/AccountTab';
import AboutTab from './settings/AboutTab';
import { useSettingsLogic } from '../hooks/useSettingsLogic';

interface DecryptedImage {
  id: string;
  url: string;
  failed?: boolean;
  createdAt: number;
}

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  images?: DecryptedImage[];
  onOpenTrash?: () => void;
  isInline?: boolean;
}

// Icon map for tab items
const ICON_MAP = {
  Shield,
  Lock,
  HardDrive,
  Trash2,
  Sparkles,
  Wrench,
  User,
};

export default function SettingsModal({ isOpen, onClose, images = [], onOpenTrash, isInline }: SettingsModalProps) {
  const s = useSettingsLogic(isOpen, images, onClose, onOpenTrash);

  React.useEffect(() => {
    if (isOpen) {
      document.body.classList.add('modal-open');
    } else {
      document.body.classList.remove('modal-open');
    }
    return () => document.body.classList.remove('modal-open');
  }, [isOpen]);

  const content = (
    <div className={`flex flex-col bg-zinc-950 ${isInline ? 'h-full w-full' : 'relative w-full max-w-2xl md:rounded-3xl shadow-2xl overflow-hidden border-0 md:border border-white/10 h-[100dvh] md:h-[600px] md:max-h-[85vh]'}`}>
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#050505]/90 backdrop-blur-2xl border-b border-white/5 px-3 sm:px-6 h-14 sm:h-20 flex items-center justify-between safe-top shrink-0 select-none">
        <div className="flex items-center gap-4">
          {s.activeTab !== 'menu' && (
            <button 
              onClick={() => s.setActiveTab('menu')}
              className="p-2 -ml-2 hover:bg-white/5 rounded-full transition-colors text-white"
            >
              <motion.div
                initial={{ x: 5, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m15 18-6-6 6-6"/>
                </svg>
              </motion.div>
            </button>
          )}
          <div>
            <h2 className="text-lg sm:text-2xl font-bold tracking-tight text-white leading-tight">
              {s.activeTab === 'menu' ? 'Configurações' : s.tabs.find(t => t.id === s.activeTab)?.label}
            </h2>
            <p className="text-xs sm:text-sm text-zinc-500 font-medium line-clamp-1">
              {s.activeTab === 'menu' ? 'Gerencie as preferências de segurança, armazenamento e conta' : s.tabs.find(t => t.id === s.activeTab)?.description}
            </p>
          </div>
        </div>
      </header>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto relative bg-[#050505]">
        <AnimatePresence mode="wait">
          {s.activeTab === 'menu' ? (
            <motion.div
              key="menu"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
              className="p-4 pb-48 md:pb-20 space-y-2 max-w-2xl mx-auto w-full"
            >
              {s.tabs.map((tab, i) => {
                const Icon = ICON_MAP[tab.icon as keyof typeof ICON_MAP] || Sparkles;
                return (
                  <motion.button
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05, duration: 0.3, ease: 'easeOut' }}
                    key={tab.id}
                    onClick={() => {
                      if ((tab.id as string) === 'trash') {
                        onOpenTrash?.();
                        if (!isInline) s.handleClose();
                      } else {
                        s.setActiveTab(tab.id);
                      }
                    }}
                    className="w-full flex items-center gap-4 p-4 rounded-2xl transition-all hover:bg-white/5 active:bg-white/10 text-left group"
                  >
                    <div className="p-3 bg-zinc-900/50 rounded-2xl border border-white/5 text-zinc-400 group-hover:text-white group-hover:border-white/10 transition-colors">
                      <Icon size={24} strokeWidth={1.5} />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-white font-medium text-base">{tab.label}</h3>
                      <p className="text-sm text-zinc-500 line-clamp-1">{tab.description}</p>
                    </div>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-zinc-700 group-hover:text-zinc-400 transition-colors">
                      <path d="m9 18 6-6-6-6"/>
                    </svg>
                  </motion.button>
                );
              })}
            </motion.div>
          ) : (
            <motion.div
              key={s.activeTab}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
              className="p-6 pb-48 md:pb-24 min-h-full"
            >
              <div className="max-w-md mx-auto">
                {s.activeTab === 'security' && (
                  <SecurityTab
                    privacyMode={s.privacyMode}
                    handleTogglePrivacy={s.handleTogglePrivacy}
                    autoLockTimer={s.autoLockTimer}
                    handleSaveTimer={s.handleSaveTimer}
                  />
                )}

                {s.activeTab === 'fakeVault' && (
                  <FakeVaultTab
                    extraPassword={s.extraPassword}
                    isSettingsUnlocked={s.isSettingsUnlocked}
                    setIsSettingsUnlocked={s.setIsSettingsUnlocked}
                    unlockPasswordInput={s.unlockPasswordInput}
                    setUnlockPasswordInput={s.setUnlockPasswordInput}
                    newExtraPassword={s.newExtraPassword}
                    setNewExtraPassword={s.setNewExtraPassword}
                    handleUpdateExtraPassword={s.handleUpdateExtraPassword}
                    isUpdatingPassword={s.isUpdatingPassword}
                    securityImageId={s.securityImageId}
                    setSecurityImage={s.setSecurityImage}
                    images={images}
                    showToast={s.showToast}
                  />
                )}

                {s.activeTab === 'storage' && (
                  <StorageTab
                    cloudStorageUsed={s.cloudStorageUsed}
                    storageUsage={s.storageUsage}
                    downloading={s.downloading}
                    clearing={s.clearing}
                    handleBackupToDrive={s.handleBackupToDrive}
                    handleRemoveFailedImages={s.handleRemoveFailedImages}
                    handleDownloadAll={s.handleDownloadAll}
                    handleClearCache={s.handleClearCache}
                    images={images}
                    formatBytes={s.formatBytes}
                  />
                )}

                {s.activeTab === 'news' && (
                  <NewsTab showToast={s.showToast} />
                )}

                {s.activeTab === 'repair' && (
                  <RepairTab
                    clearing={s.clearing}
                    setClearing={s.setClearing}
                    showToast={s.showToast}
                  />
                )}

                {s.activeTab === 'account' && (
                  <AccountTab
                    user={s.user}
                    isInstallable={s.isInstallable}
                    promptToInstall={s.promptToInstall}
                    isInIframe={s.isInIframe}
                    showToast={s.showToast}
                    logOut={s.logOut}
                    onClose={onClose}
                  />
                )}

                {s.activeTab === 'about' && (
                  <AboutTab showToast={s.showToast} />
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );

  if (isInline) return (
    <motion.div
      initial={{ opacity: 0, y: 15, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 15, scale: 0.98 }}
      transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
      className="h-full w-full"
    >
      {content}
      {s.toast && (
        <Toast
          key="settings-toast"
          message={s.toast.message}
          type={s.toast.type}
          onClose={() => s.setToast(null)}
        />
      )}
    </motion.div>
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          key="settings-modal"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-0 md:p-6"
        >
          <div
            onClick={s.handleClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          <motion.div
            initial={{ scale: 0.96, opacity: 0, y: 30 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.96, opacity: 0, y: 20 }}
            transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
            className="flex flex-col h-full w-full max-w-2xl relative z-10"
          >
            {content}
          </motion.div>
        </motion.div>
      )}
      {s.toast && (
        <Toast
          key="settings-toast"
          message={s.toast.message}
          type={s.toast.type}
          onClose={() => s.setToast(null)}
        />
      )}
    </AnimatePresence>
  );
}
