import React from 'react';
import { Loader2, ShieldAlert, RefreshCw } from 'lucide-react';
import PublicPasswordPrompt from './PublicPasswordPrompt';
import PublicMediaFrame from './PublicMediaFrame';
import { usePublicShareLogic } from '../hooks/usePublicShareLogic';

export default function PublicShareView() {
  const s = usePublicShareLogic();

  if (s.loading) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center text-zinc-400 gap-4">
        <Loader2 className="w-10 h-10 text-white animate-spin" strokeWidth={1.5} />
      </div>
    );
  }

  if (s.error && !s.decryptedUrl) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 text-center animate-fadeIn">
        <div className="w-16 h-16 rounded-full bg-red-950/30 border border-red-900 flex items-center justify-center text-red-500 mb-4 animate-pulse">
          <ShieldAlert size={32} />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">Acesso Restrito / Expirado</h2>
        <p className="text-sm text-zinc-400 max-w-md mb-6">{s.error}</p>
        <button
          onClick={() => window.location.reload()}
          className="px-5 py-2.5 bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-white rounded-xl text-xs font-semibold transition-all inline-flex items-center gap-1.5 active:scale-95 animate-pulse"
        >
          <RefreshCw size={14} /> Recarregar Página
        </button>
      </div>
    );
  }

  // If requires password and not decrypted yet
  if (s.shareData?.options?.requirePassword && !s.decryptedUrl) {
    return (
      <PublicPasswordPrompt
        password={s.password}
        setPassword={s.setPassword}
        decrypting={s.decrypting}
        error={s.error}
        onSubmit={s.handlePasswordSubmit}
      />
    );
  }

  const oneTimeView = s.shareData?.options?.oneTimeView;
  const allowDownload = s.shareData?.options?.allowDownload && !oneTimeView;
  const isVideo = s.shareData?.contentType?.startsWith('video/');

  return (
    <PublicMediaFrame
      decryptedUrl={s.decryptedUrl}
      allowDownload={allowDownload}
      isVideo={isVideo || false}
      isDownloadingChunks={s.isDownloadingChunks}
      downloadProgress={s.downloadProgress}
    />
  );
}
