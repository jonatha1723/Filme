import React from 'react';
import { motion } from 'motion/react';
import { Shield } from 'lucide-react';

interface GalleryEmptyStateProps {
  setIsUploaderOpen: (val: boolean) => void;
}

export default function GalleryEmptyState({ setIsUploaderOpen }: GalleryEmptyStateProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="text-center py-32 sm:py-48 text-zinc-500 space-y-6 px-4 flex flex-col items-center"
    >
      <div className="relative">
        <div className="relative w-24 h-24 bg-gradient-to-b from-white/10 to-white/5 rounded-[2rem] flex items-center justify-center border border-white/10 shadow-2xl">
          <Shield size={40} className="text-white/50" strokeWidth={1.5} />
        </div>
      </div>
      <div className="space-y-2">
        <h3 className="text-xl font-medium text-zinc-200 tracking-tight">Cofre Vazio</h3>
        <p className="text-sm text-zinc-500 max-w-xs mx-auto leading-relaxed">
          Suas fotos criptografadas aparecerão aqui. Ninguém mais tem acesso a elas.
        </p>
        <button 
          onClick={() => setIsUploaderOpen(true)}
          className="mt-4 px-6 py-3 bg-white text-black font-bold rounded-full hover:bg-zinc-200 transition-colors"
        >
          Adicionar Primeira Foto
        </button>
      </div>
    </motion.div>
  );
}
