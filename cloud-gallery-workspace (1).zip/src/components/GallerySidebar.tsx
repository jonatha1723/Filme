import React from 'react';
import { Shield, Image as ImageIcon, Trash2, Settings, Lock, LogOut } from 'lucide-react';

interface GallerySidebarProps {
  /**
   * Clears selection mode and selections when main gallery is viewed
   */
  onViewGallery: () => void;
  /**
   * Opens the trash modal
   */
  onOpenTrash: () => void;
  /**
   * Opens the settings modal
   */
  onOpenSettings: () => void;
  /**
   * Handler to lock the vault immediately
   */
  onLockVault: () => void;
  /**
   * Handler to log out of the firebase session
   */
  onLogOut: () => void;
  onViewProtected: () => void;
  /**
   * Current active navigation view indicator
   */
  currentView?: 'gallery' | 'trash' | 'settings' | 'protected';
}

/**
 * GallerySidebar component provides responsive sidebar navigation on desktop viewports.
 * Features:
 * - Brand heading with high-contrast badge
 * - Mode and sub-system transitions (Gallery, Lixeira, Configurações)
 * - Safe termination controls (Lock, Logout)
 */
export default function GallerySidebar({
  onViewGallery,
  onOpenTrash,
  onOpenSettings,
  onViewProtected,
  onLockVault,
  onLogOut,
  currentView = 'gallery'
}: GallerySidebarProps) {
  return (
    <aside 
      id="gallery-desktop-sidebar" 
      className="hidden lg:flex w-72 flex-col sticky top-0 h-screen border-r border-white/5 bg-[#050505] p-6 shrink-0 z-40 justify-between select-none"
    >
      <div className="flex flex-col flex-1">
        {/* Brand Identity / Header Logo */}
        <div className="flex items-center gap-3 mb-10 px-2" id="brand-header">
          <div className="w-10 h-10 bg-white text-black rounded-xl flex items-center justify-center shadow-lg shadow-white/5 transition-transform hover:scale-105 duration-300">
            <Shield size={22} strokeWidth={2.5} />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white leading-tight">Cloud Gallery</h1>
            <span className="text-[10px] font-semibold text-zinc-500 tracking-wider uppercase">Cofre de Mídia</span>
          </div>
        </div>

        {/* Main Navigation Links */}
        <nav className="space-y-1.5" id="main-navigation">
          <button 
            id="nav-btn-gallery"
            type="button"
            onClick={onViewGallery}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-medium transition-all duration-200 hover:scale-[1.01] active:scale-[0.99] ${
              currentView === 'gallery'
                ? 'bg-white/10 text-white border border-white/10 shadow-lg shadow-black/20'
                : 'text-zinc-400 hover:bg-white/5 hover:text-white border border-transparent'
            }`}
          >
            <ImageIcon size={18} className="shrink-0" />
            <span className="text-sm">Sua Galeria</span>
          </button>
          
          <button 
            id="nav-btn-protected"
            type="button"
            onClick={onViewProtected}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-medium transition-all duration-200 hover:scale-[1.01] active:scale-[0.99] ${
              currentView === 'protected'
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-lg shadow-emerald-950/20'
                : 'text-zinc-400 hover:bg-white/5 hover:text-white border border-transparent'
            }`}
          >
            <Shield size={18} className="shrink-0" />
            <span className="text-sm">Protegidas</span>
          </button>
          
          <button 
            id="nav-btn-trash"
            type="button"
            onClick={onOpenTrash}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-medium transition-all duration-200 hover:scale-[1.01] active:scale-[0.99] ${
              currentView === 'trash'
                ? 'bg-white/10 text-white border border-white/10 shadow-lg shadow-black/20'
                : 'text-zinc-400 hover:bg-white/5 hover:text-white border border-transparent'
            }`}
          >
            <Trash2 size={18} className="shrink-0" />
            <span className="text-sm">Lixeira</span>
          </button>
          
          <button 
            id="nav-btn-settings"
            type="button"
            onClick={onOpenSettings}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-medium transition-all duration-200 hover:scale-[1.01] active:scale-[0.99] ${
              currentView === 'settings'
                ? 'bg-white/10 text-white border border-white/10 shadow-lg shadow-black/20'
                : 'text-zinc-400 hover:bg-white/5 hover:text-white border border-transparent'
            }`}
          >
            <Settings size={18} className="shrink-0" />
            <span className="text-sm">Configurações</span>
          </button>
        </nav>
      </div>

      {/* Account Info and System Utilities */}
      <div className="mt-auto space-y-4 pt-6 border-t border-white/5" id="bottom-navigation">
        <div className="space-y-1">
          <button 
            id="btn-lock-vault"
            type="button"
            onClick={onLockVault}
            className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-zinc-400 text-xs font-medium transition-all hover:bg-white/5 hover:text-white"
          >
            <Lock size={16} />
            Bloquear Cofre
          </button>
          <button 
            id="btn-log-out"
            type="button"
            onClick={onLogOut}
            className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-zinc-400 text-xs font-medium transition-all hover:bg-red-500/10 hover:text-red-400"
          >
            <LogOut size={16} />
            Sair da Conta
          </button>
        </div>
      </div>
    </aside>
  );
}
