import React from "react";
import { Lock } from "lucide-react";
import { motion } from "framer-motion";
import { ChangeSecurityPasswordForm } from "./ChangeSecurityPasswordForm";

interface SecurityPasswordFormSectionProps {
  isChangingExtraPassword: boolean;
  setIsChangingExtraPassword: (val: boolean) => void;
  extraPassword: string | null;
  securityProps: any;
}

export function SecurityPasswordFormSection({
  isChangingExtraPassword,
  setIsChangingExtraPassword,
  extraPassword,
  securityProps,
}: SecurityPasswordFormSectionProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: 0.2 }}
      className="bg-zinc-800/50 rounded-2xl overflow-hidden border border-white/5 mb-3"
    >
      {!isChangingExtraPassword ? (
        <button
          onClick={() => setIsChangingExtraPassword(true)}
          className="w-full py-3 px-4 hover:bg-white/5 text-white font-medium transition-all flex items-center justify-center gap-2"
        >
          <Lock size={18} />
          {extraPassword ? "Alterar Senha de Segurança" : "Definir Senha de Segurança"}
        </button>
      ) : (
        <ChangeSecurityPasswordForm
          {...securityProps}
          extraPassword={extraPassword}
          onCancel={() => {
            setIsChangingExtraPassword(false);
            securityProps.setCurrentExtraPassword("");
            securityProps.setNewExtraPasswordState("");
            securityProps.setConfirmNewExtraPassword("");
          }}
        />
      )}
    </motion.div>
  );
}
