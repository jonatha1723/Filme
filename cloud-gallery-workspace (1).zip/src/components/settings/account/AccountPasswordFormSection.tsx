import React from "react";
import { KeyRound } from "lucide-react";
import { motion } from "framer-motion";
import { ChangeAccountPasswordForm } from "./ChangeAccountPasswordForm";

interface AccountPasswordFormSectionProps {
  isChangingPassword: boolean;
  setIsChangingPassword: (val: boolean) => void;
  passwordProps: any;
}

export function AccountPasswordFormSection({
  isChangingPassword,
  setIsChangingPassword,
  passwordProps,
}: AccountPasswordFormSectionProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: 0.1 }}
      className="bg-zinc-800/50 rounded-2xl overflow-hidden border border-white/5 mb-3"
    >
      {!isChangingPassword ? (
        <button
          onClick={() => setIsChangingPassword(true)}
          className="w-full py-3 px-4 hover:bg-white/5 text-white font-medium transition-all flex items-center justify-center gap-2"
        >
          <KeyRound size={18} />
          Alterar Senha da Conta
        </button>
      ) : (
        <ChangeAccountPasswordForm
          {...passwordProps}
          onCancel={() => {
            setIsChangingPassword(false);
            passwordProps.setCurrentPassword("");
            passwordProps.setNewPassword("");
            passwordProps.setConfirmPassword("");
          }}
        />
      )}
    </motion.div>
  );
}
