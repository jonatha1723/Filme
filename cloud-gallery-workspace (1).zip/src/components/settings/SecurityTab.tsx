import React from 'react';
import { EyeOff, Clock, Check } from 'lucide-react';
import { motion } from 'framer-motion';

interface SecurityTabProps {
  privacyMode: boolean;
  handleTogglePrivacy: () => void;
  autoLockTimer: string;
  handleSaveTimer: (val: string) => void;
}

export default function SecurityTab({
  privacyMode,
  handleTogglePrivacy,
  autoLockTimer,
  handleSaveTimer
}: SecurityTabProps) {
  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <h3 className="text-lg font-semibold text-white mb-2">Proteção de Tela</h3>
        <p className="text-sm text-zinc-400 mb-6">
          Oculta o conteúdo do cofre quando você muda de aba ou minimiza o aplicativo.
        </p>
        
        <label className="flex items-center justify-between p-4 rounded-2xl border cursor-pointer transition-all border-white/10 hover:border-white/20 bg-zinc-900/30 mb-8">
          <div className="flex items-center gap-3">
            <EyeOff size={18} className={privacyMode ? 'text-white' : 'text-zinc-500'} />
            <span className={privacyMode ? 'text-white font-medium' : 'text-zinc-400'}>
              Modo Privacidade
            </span>
          </div>
          <div className={`w-10 h-6 rounded-full transition-colors relative ${privacyMode ? 'bg-white' : 'bg-zinc-800'}`}>
            <div className={`absolute top-1 left-1 bg-black w-4 h-4 rounded-full transition-transform ${privacyMode ? 'translate-x-4' : 'translate-x-0'}`} />
          </div>
          <input 
            type="checkbox" 
            checked={privacyMode}
            onChange={handleTogglePrivacy}
            className="hidden"
          />
        </label>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 }}
      >
        <h3 className="text-lg font-semibold text-white mb-2">Bloqueio Automático</h3>
        <p className="text-sm text-zinc-400 mb-6">
          Tempo de inatividade antes de exigir a senha novamente.
        </p>
        
        <div className="space-y-3">
          {[
            { value: '5', label: '5 minutos' },
            { value: '15', label: '15 minutos' },
            { value: '30', label: '30 minutos' },
            { value: '60', label: '1 hora' },
            { value: 'never', label: 'Nunca (Não recomendado)' }
          ].map((option) => (
            <label 
              key={option.value}
              className={`flex items-center justify-between p-4 rounded-2xl border cursor-pointer transition-all ${
                autoLockTimer === option.value 
                  ? 'border-white bg-white/5' 
                  : 'border-white/10 hover:border-white/20 bg-zinc-900/30'
              }`}
            >
              <div className="flex items-center gap-3">
                <Clock size={18} className={autoLockTimer === option.value ? 'text-white' : 'text-zinc-500'} />
                <span className={autoLockTimer === option.value ? 'text-white font-medium' : 'text-zinc-400'}>
                  {option.label}
                </span>
              </div>
              <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                autoLockTimer === option.value ? 'border-white bg-white' : 'border-zinc-700'
              }`}>
                {autoLockTimer === option.value && <Check size={12} className="text-black" />}
              </div>
              <input 
                type="radio" 
                name="autolock" 
                value={option.value}
                checked={autoLockTimer === option.value}
                onChange={(e) => handleSaveTimer(e.target.value)}
                className="hidden"
              />
            </label>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
