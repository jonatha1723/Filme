import React from 'react';
import { Sparkles, Shield, RefreshCw } from 'lucide-react';
import { APP_VERSION } from '../../constants';

interface AboutTabProps {
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export default function AboutTab({ showToast }: AboutTabProps) {
  const handleCheckUpdates = () => {
    showToast('Buscando atualizações...');
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.getRegistrations().then((registrations) => {
        if (registrations.length === 0) {
          showToast('Você já está na versão mais recente!', 'info');
        } else {
          for (const registration of registrations) {
            registration.update();
          }
          showToast('Verificação concluída. Se houver novidades, o app atualizará em breve.', 'info');
        }
      });
    } else {
      window.location.reload();
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-white/10 rounded-xl text-white">
            <Sparkles size={20} />
          </div>
          <h3 className="text-lg font-semibold text-white">Sobre o App</h3>
        </div>

        <div className="p-6 bg-zinc-900/50 border border-white/10 rounded-3xl space-y-6 text-center">
          <div className="flex justify-center">
            <div className="w-20 h-20 bg-white text-black rounded-[2rem] flex items-center justify-center shadow-2xl">
              <Shield size={40} strokeWidth={2.5} />
            </div>
          </div>
          <div>
            <h4 className="text-xl font-bold text-white">Cloud Gallery</h4>
            <p className="text-sm text-zinc-500 mt-1">Versão {APP_VERSION}</p>
          </div>

          <div className="pt-4 space-y-3">
            <button
              onClick={handleCheckUpdates}
              className="w-full py-4 bg-white text-black font-bold rounded-2xl hover:bg-zinc-200 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <RefreshCw size={20} />
              Verificar Atualizações
            </button>
            
            <p className="text-[10px] text-zinc-600 uppercase tracking-widest font-bold">
              Criptografia de Ponta a Ponta Ativa
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
