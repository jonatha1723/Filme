import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trash2, RefreshCw, X, Loader2, Film, Image as ImageIcon, Lock } from 'lucide-react';
import ConfirmModal from './ConfirmModal';
import Toast from './Toast';
import ExtraPasswordPrompt from './ExtraPasswordPrompt';
import { useTrashLogic } from '../hooks/useTrashLogic';

interface TrashModalProps {
  isOpen: boolean;
  onClose: () => void;
  isInline?: boolean;
  onLightboxToggle?: (isOpen: boolean) => void;
}

export default function TrashModal({ isOpen, onClose, isInline, onLightboxToggle }: TrashModalProps) {
  const t = useTrashLogic(isOpen);

  React.useEffect(() => {
    onLightboxToggle?.(t.selectedImage !== null);
  }, [t.selectedImage, onLightboxToggle]);

  const content = (
    <div className={`flex flex-col bg-[#050505] ${isInline ? 'h-full w-full' : 'fixed inset-0 z-[70]'}`}>
      {t.toast && (
        <Toast 
          message={t.toast.message} 
          type={t.toast.type} 
          onClose={() => t.setToast(null)} 
        />
      )}

      <ConfirmModal
        isOpen={t.isConfirmEmptyOpen}
        onClose={() => t.setIsConfirmEmptyOpen(false)}
        onConfirm={t.handleEmptyTrash}
        title="Esvaziar Lixeira"
        message="Tem certeza que deseja excluir permanentemente TODAS as imagens da lixeira? Esta ação não pode ser desfeita."
        confirmText="Esvaziar Lixeira"
        cancelText="Cancelar"
      />

      <ConfirmModal
        isOpen={t.isConfirmDeleteOpen}
        onClose={() => t.setIsConfirmDeleteOpen(false)}
        onConfirm={() => t.selectedImage && t.handleDeletePermanently(t.selectedImage)}
        title="Excluir Permanentemente"
        message="Tem certeza que deseja excluir esta imagem permanentemente? Esta ação não pode ser desfeita."
        confirmText="Excluir"
        cancelText="Cancelar"
      />

      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#050505]/90 backdrop-blur-2xl border-b border-white/5 px-3 sm:px-6 h-14 sm:h-20 flex items-center justify-between safe-top">
        <div>
          <h2 className="text-lg sm:text-2xl font-bold tracking-tight text-white">
            {t.selectedIds.length > 0 ? `${t.selectedIds.length} selecionados` : 'Lixeira Local'}
          </h2>
          <p className="text-xs sm:text-sm text-zinc-500 font-medium">
            {t.selectedIds.length > 0 ? 'Opções de exclusão ou restauração em lote' : `${t.images.length} itens removidos`}
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          {t.selectedIds.length > 0 ? (
            <button
              onClick={() => t.setSelectedIds([])}
              className="text-zinc-400 hover:text-white text-sm font-medium px-4 py-2 rounded-xl hover:bg-white/5 transition-colors border border-transparent hover:border-white/5"
            >
              Cancelar
            </button>
          ) : t.images.length > 0 && (
            <button
              onClick={t.triggerEmptyTrash}
              className="text-red-400 hover:text-red-300 text-sm font-medium px-4 py-2 rounded-xl hover:bg-red-500/10 transition-colors border border-transparent hover:border-red-500/10"
            >
              Esvaziar
            </button>
          )}
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 pb-40">
        {t.loading ? (
          <div className="flex items-center justify-center h-64">
            <Loader2 className="w-8 h-8 text-zinc-500 animate-spin" />
          </div>
        ) : t.images.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-zinc-500 space-y-4 py-20">
            <div className="w-16 h-16 bg-zinc-900 rounded-full flex items-center justify-center border border-white/5">
              <Trash2 size={28} className="text-zinc-600" />
            </div>
            <p className="text-base font-semibold text-white">A lixeira está vazia</p>
            <p className="text-sm text-center max-w-xs text-zinc-500">
              Imagens excluídas da Cloud Gallery aparecerão aqui e poderão ser restauradas.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-1.5 sm:gap-4">
            {t.images.map((img) => {
              const isSelected = t.selectedIds.includes(img.id);
              return (
                <motion.div
                  key={img.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className={`aspect-[4/5] sm:aspect-square bg-zinc-900 cursor-pointer group relative overflow-hidden rounded-2xl shadow-lg ring-1 transition-all ${
                    isSelected ? 'ring-emerald-400 ring-2' : 'ring-white/10 hover:ring-white/30'
                  }`}
                  onClick={() => t.handleSelectImage(img)}
                >
                  {/* Selection Overlay */}
                  <div className={`absolute top-2 right-2 z-10 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                    isSelected ? 'bg-emerald-400 border-emerald-400' : 'bg-black/20 border-white/40'
                  }`}>
                    {isSelected && <div className="w-2.5 h-2.5 bg-zinc-950 rounded-full" />}
                  </div>

                  {img.id === t.securityImageId && !t.isExtraUnlocked && t.extraPassword ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-zinc-500 bg-zinc-950 p-4 text-center select-none">
                      <Lock size={28} className="text-zinc-600 mb-2 animate-pulse" strokeWidth={1.5} />
                      <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-wider">
                        Protegido
                      </span>
                    </div>
                  ) : img.noThumbnail ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-zinc-400 group-hover:brightness-50 transition-all bg-zinc-950">
                      {img.isVideo ? (
                        <Film size={32} className="opacity-40 mb-1" strokeWidth={1.5} />
                      ) : (
                        <ImageIcon size={32} className="opacity-40 mb-1" strokeWidth={1.5} />
                      )}
                      <span className="text-[9px] font-mono tracking-wider opacity-65 uppercase">
                        {img.isVideo ? 'Vídeo' : 'Imagem'}
                      </span>
                    </div>
                  ) : (
                    <img 
                      src={img.url} 
                      alt="" 
                      className={`w-full h-full object-cover transition-all duration-500 select-none ${isSelected ? 'brightness-75 scale-95' : 'group-hover:brightness-50'}`}
                      draggable={false}
                    />
                  )}
                  
                  {/* Hover Overlay */}
                  {t.selectedIds.length === 0 && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                      <span className="text-white text-xs font-medium bg-black/60 px-2 py-1 rounded-md backdrop-blur-md">
                        Ver Opções
                      </span>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        )}
      </main>

      {/* Multiple Selection Bar */}
      <AnimatePresence>
        {t.selectedIds.length > 0 && (
          <motion.div
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            exit={{ y: 100 }}
            className={`fixed bottom-0 left-0 right-0 bg-[#0a0a0a]/90 backdrop-blur-xl border-t border-white/10 p-4 sm:p-6 flex items-center justify-between z-[90] gap-4 ${isInline ? 'lg:left-64' : ''}`}
          >
            <div className="flex flex-col">
              <span className="text-white font-bold text-lg">{t.selectedIds.length} selecionados</span>
              <button 
                onClick={() => t.setSelectedIds(t.images.map(i => i.id))}
                className="text-xs text-zinc-500 hover:text-white transition-colors text-left"
              >
                Selecionar tudo
              </button>
            </div>
            <div className="flex gap-2">
              <button
                onClick={t.handleRestoreMultiple}
                disabled={t.isRestoring || t.isDeleting}
                className="px-4 py-2.5 bg-white text-black font-bold rounded-xl flex items-center gap-2 hover:bg-zinc-200 transition-colors disabled:opacity-50 text-sm"
              >
                {t.isRestoring ? <Loader2 className="animate-spin" size={18} /> : <RefreshCw size={18} />}
                Restaurar
              </button>
              <button
                onClick={() => t.setIsConfirmDeleteMultipleOpen(true)}
                disabled={t.isRestoring || t.isDeleting}
                className="px-4 py-2.5 bg-red-500/10 text-red-500 font-bold rounded-xl flex items-center gap-2 hover:bg-red-500/20 transition-colors border border-red-500/20 disabled:opacity-50 text-sm"
              >
                <Trash2 size={18} />
                Excluir
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <ConfirmModal
        isOpen={t.isConfirmDeleteMultipleOpen}
        onClose={() => t.setIsConfirmDeleteMultipleOpen(false)}
        onConfirm={t.handleDeleteMultiple}
        title="Excluir Permanentemente"
        message={`Tem certeza que deseja excluir ${t.selectedIds.length} itens permanentemente? Esta ação não pode ser desfeita.`}
        confirmText="Excluir"
        cancelText="Cancelar"
      />

      {/* Image Action Modal */}
      <AnimatePresence>
        {t.selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
            onClick={() => t.setSelectedImage(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-zinc-900 border border-white/10 rounded-3xl p-6 w-full max-w-sm flex flex-col items-center gap-6"
              onClick={e => e.stopPropagation()}
            >
              <div className="w-full aspect-square rounded-2xl overflow-hidden bg-black border border-white/5">
                <img src={t.selectedImage.url} className="w-full h-full object-contain" alt="Selected" />
              </div>
              
              <div className="w-full space-y-3">
                <button
                  onClick={() => t.handleRestore(t.selectedImage!)}
                  disabled={t.isRestoring || t.isDeleting}
                  className="w-full py-3.5 sm:py-4 bg-white text-black font-bold rounded-xl sm:rounded-2xl flex items-center justify-center gap-2 hover:bg-zinc-200 transition-colors disabled:opacity-50 text-sm sm:text-base"
                >
                  {t.isRestoring ? <Loader2 className="animate-spin" size={20} /> : <RefreshCw size={20} />}
                  Restaurar Imagem
                </button>
                
                <button
                  onClick={() => t.setIsConfirmDeleteOpen(true)}
                  disabled={t.isRestoring || t.isDeleting}
                  className="w-full py-3.5 sm:py-4 bg-red-500/10 text-red-500 font-bold rounded-xl sm:rounded-2xl flex items-center justify-center gap-2 hover:bg-red-500/20 transition-colors border border-red-500/20 disabled:opacity-50 text-sm sm:text-base"
                >
                  <Trash2 size={20} />
                  Excluir Permanentemente
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <ExtraPasswordPrompt
        isOpen={t.isPromptingExtra !== null}
        extraPasswordInput={t.extraPasswordInput}
        setExtraPasswordInput={t.setExtraPasswordInput}
        onClose={() => t.setIsPromptingExtra(null)}
        onSubmit={t.handleExtraPasswordSubmit}
      />
    </div>
  );

  if (isInline) return content;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[70] flex flex-col bg-[#050505]"
        >
          {content}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
