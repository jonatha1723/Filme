import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import LightboxControls from './lightbox/LightboxControls';
import LightboxTouchSurface from './lightbox/LightboxTouchSurface';

interface LightboxProps {
  selectedImage: string;
  selectedImageId: string;
  selectedImageIsVideo: boolean;
  downloadingFull: boolean;
  fullDownloadProgress: string;
  imageFit: 'contain' | 'cover';
  showControls: boolean;
  isZoomed: boolean;
  isFullscreen: boolean;
  setIsZoomed: (zoomed: boolean) => void;
  setImageFit: (fit: 'contain' | 'cover') => void;
  setIsShareOpen: (open: boolean) => void;
  setShowControls: (show: boolean | ((prev: boolean) => boolean)) => void;
  onClose: () => void;
  onNext: () => void;
  onPrev: () => void;
  onToggleFullscreen: () => void;
  onDelete?: () => void;
}

export default function Lightbox({
  selectedImage,
  selectedImageId,
  selectedImageIsVideo,
  downloadingFull,
  fullDownloadProgress,
  imageFit,
  showControls,
  isZoomed,
  isFullscreen,
  setIsZoomed,
  setImageFit,
  setIsShareOpen,
  setShowControls,
  onClose,
  onNext,
  onPrev,
  onToggleFullscreen,
  onDelete,
}: LightboxProps) {
  const handleContainerClick = () => {
    onClose();
  };

  return (
    <motion.div
      id="lightbox-backdrop"
      key="fullscreen-image"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black flex items-center justify-center p-0"
      onClick={handleContainerClick}
    >
      <AnimatePresence>
        {showControls && (
          <LightboxControls
            selectedImage={selectedImage}
            imageFit={imageFit}
            isFullscreen={isFullscreen}
            onToggleFullscreen={onToggleFullscreen}
            setImageFit={setImageFit}
            setIsShareOpen={setIsShareOpen}
            onClose={onClose}
            onDelete={onDelete}
          />
        )}
      </AnimatePresence>

      <LightboxTouchSurface
        selectedImage={selectedImage}
        selectedImageId={selectedImageId}
        selectedImageIsVideo={selectedImageIsVideo}
        downloadingFull={downloadingFull}
        fullDownloadProgress={fullDownloadProgress}
        imageFit={imageFit}
        showControls={showControls}
        isZoomed={isZoomed}
        setIsZoomed={setIsZoomed}
        setShowControls={setShowControls}
        onClose={onClose}
        onNext={onNext}
        onPrev={onPrev}
      />
    </motion.div>
  );
}
export type { DecryptedImage } from '../types';
