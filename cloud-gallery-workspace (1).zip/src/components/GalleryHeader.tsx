import React from 'react';
import { motion } from 'motion/react';
import { CheckSquare, DownloadCloud, Lock, LogOut } from 'lucide-react';

interface GalleryHeaderProps {
  imagesCount: number;
  isSelectionMode: boolean;
  setIsSelectionMode: (val: boolean) => void;
  setSelectedForDeletion: (val: string[]) => void;
  isInstallable: boolean;
  promptToInstall: () => void;
  isInIframe: boolean;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  lockVault: () => void;
  logOut: () => void;
  setIsSettingsOpen: (val: boolean) => void;
  backgroundSyncing?: boolean;
  backgroundSyncProgress?: number;
}

export default function GalleryHeader({
  imagesCount,
  isSelectionMode,
  setIsSelectionMode,
  setSelectedForDeletion,
  isInstallable,
  promptToInstall,
  isInIframe,
  showToast,
  lockVault,
  logOut,
  setIsSettingsOpen,
  backgroundSyncing,
  backgroundSyncProgress
}: GalleryHeaderProps) {
  return (
    <header className="sticky top-0 z-40 bg-[#050505]/90 backdrop-blur-2xl border-b border-white/5 px-3 sm:px-6 h-14 sm:h-20 flex items-center justify-between safe-top">
      <div className="flex items-center gap-1 sm:gap-2">
        <div>
          <h2 className="text-lg sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            Sua Galeria
            {backgroundSyncing && (
               <motion.div
                 animate={{ rotate: 360 }}
                 transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
               >
                 <DownloadCloud size={16} className="text-zinc-500" />
               </motion.div>
            )}
          </h2>
          <p className="text-xs sm:text-sm text-zinc-500 font-medium">
            {imagesCount} fotos protegidas
            {backgroundSyncing && ` • Sincronizando cofre (${backgroundSyncProgress}%)`}
          </p>
        </div>
      </div>
      
      <div className="flex items-center gap-1 sm:gap-2">
        <button
          onClick={() => {
            setIsSelectionMode(!isSelectionMode);
            setSelectedForDeletion([]);
          }}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-full transition-colors text-sm font-medium mr-1 sm:mr-2 ${isSelectionMode ? 'bg-white text-black' : 'bg-white/10 text-white hover:bg-white/20'}`}
          title={isSelectionMode ? 'Concluir seleção' : 'Selecionar múltiplas fotos'}
        >
          <CheckSquare size={16} />
          <span className="hidden sm:inline">{isSelectionMode ? 'Concluir' : 'Selecionar'}</span>
        </button>
        <button
          onClick={lockVault}
          className="p-1.5 sm:p-3 text-zinc-400 hover:bg-white/10 hover:text-white rounded-full transition-all active:scale-90"
          title="Bloquear Cofre"
        >
          <Lock size={18} className="sm:w-[22px] sm:h-[22px]" />
        </button>
        <button
          onClick={logOut}
          className="p-1.5 sm:p-3 text-zinc-400 hover:bg-white/10 hover:text-red-400 rounded-full transition-all active:scale-90"
          title="Sair da Conta"
        >
          <LogOut size={18} className="sm:w-[22px] sm:h-[22px]" />
        </button>
      </div>
    </header>
  );
}
