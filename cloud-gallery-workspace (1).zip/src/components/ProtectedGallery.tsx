import React from "react";
import { useAuth } from "../contexts/AuthContext";
import { useProtectedGallery } from "../hooks/protected/useProtectedGallery";
import ProtectedSetupScreen from "./protected/ProtectedSetupScreen";
import ProtectedUnlockScreen from "./protected/ProtectedUnlockScreen";
import GalleryItem from "./GalleryItem";
import Lightbox from "./Lightbox";
import ConfirmModal from "./ConfirmModal";
import Toast from "./Toast";
import { AnimatePresence } from "motion/react";
import { Loader2 } from "lucide-react";

interface ProtectedGalleryProps {
  onBack?: () => void;
  onLightboxToggle?: (isOpen: boolean) => void;
}

export default function ProtectedGallery({ onLightboxToggle }: ProtectedGalleryProps) {
  const { extraPassword } = useAuth();
  const pg = useProtectedGallery(onLightboxToggle);

  if (!extraPassword) {
    return <ProtectedSetupScreen />;
  }

  const showUnlockOverlay = !pg.isUnlocked;

  return (
    <>
      {showUnlockOverlay && (
        <div className="absolute inset-0 z-30 bg-[#050505] flex flex-col">
          <ProtectedUnlockScreen
            passwordInput={pg.passwordInput}
            setPasswordInput={pg.setPasswordInput}
            passwordError={pg.passwordError}
            setPasswordError={pg.setPasswordError}
            onUnlockSubmit={pg.handleUnlockSubmit}
            isLoading={pg.isLoading}
          />
        </div>
      )}

      {/* Header Unificado para PC / Mobile */}
      <header className="sticky top-0 z-40 bg-[#050505]/90 backdrop-blur-2xl border-b border-white/5 px-3 sm:px-6 h-14 sm:h-20 flex items-center justify-between safe-top shrink-0">
        <div>
          <h2 className="text-lg sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            Fotos Protegidas
            <span className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] rounded-full font-semibold uppercase tracking-wider">Cofre Ativo</span>
          </h2>
          <p className="text-xs sm:text-sm text-zinc-500 font-medium">
            {pg.images.length} mídias criptografadas
          </p>
        </div>
      </header>

      {/* Grid de Imagens com Layout Idêntico à Galeria Principal */}
      <main className="max-w-7xl mx-auto p-1.5 sm:p-4 pb-24 sm:pb-32 w-full flex-1 overflow-y-auto">
        {pg.loading && pg.images.length === 0 ? (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-1.5 sm:gap-4">
            {[...Array(18)].map((_, i) => (
              <div
                key={i}
                className="aspect-square bg-white/5 rounded-xl sm:rounded-2xl animate-pulse border border-white/5"
              />
            ))}
          </div>
        ) : pg.error ? (
          <div className="text-red-400 p-4 bg-red-500/10 border border-red-500/15 rounded-2xl text-sm font-medium">
            {pg.error}
          </div>
        ) : pg.images.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-zinc-500 space-y-4">
            <div className="w-16 h-16 bg-zinc-900 rounded-full flex items-center justify-center border border-white/5 text-zinc-400">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
              </svg>
            </div>
            <p className="text-base font-semibold text-white">Cofre Auxiliar Vazio</p>
            <p className="text-sm text-center max-w-xs text-zinc-500">
              Mídias que você proteger com sua chave auxiliar aparecerão neste espaço ultra seguro.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-1.5 sm:gap-4">
            {pg.images.map((img, index) => (
              <GalleryItem
                key={img.id}
                img={img}
                index={index}
                isSelectionMode={false}
                selectedForDeletion={[]}
                securityImageId={null}
                isExtraUnlocked={true}
                extraPassword={extraPassword}
                hideProtectButton={true}
                handleImageClick={pg.handleImageClick}
                setImageToDelete={pg.setImageToDelete}
              />
            ))}
          </div>
        )}

        <ConfirmModal
          isOpen={!!pg.imageToDelete}
          onClose={() => pg.setImageToDelete(null)}
          onConfirm={pg.handleDelete}
          title="Excluir Imagem Protegida"
          message="Tem certeza que deseja mover esta imagem protegida para a lixeira?"
          confirmText="Excluir"
          cancelText="Cancelar"
        />

        <AnimatePresence>
          {pg.toast && (
            <Toast
              key="toast-message"
              message={pg.toast.message}
              type={pg.toast.type}
              onClose={() => pg.setToast(null)}
            />
          )}
        </AnimatePresence>

        <AnimatePresence>
          {pg.selectedIndex !== null && pg.images[pg.selectedIndex] && (
            <Lightbox
              selectedImage={pg.images[pg.selectedIndex].originalUrl || pg.images[pg.selectedIndex].url}
              selectedImageId={pg.images[pg.selectedIndex].id}
              selectedImageIsVideo={pg.images[pg.selectedIndex].isVideo}
              downloadingFull={pg.downloadingFull}
              fullDownloadProgress={pg.fullDownloadProgress}
              imageFit={pg.imageFit}
              showControls={pg.showControls}
              isZoomed={pg.isZoomed}
              isFullscreen={pg.isFullscreen}
              setIsZoomed={pg.setIsZoomed}
              setImageFit={pg.setImageFit}
              setIsShareOpen={pg.setIsShareOpen}
              setShowControls={pg.setShowControls}
              onClose={() => {
                pg.setSelectedIndex(null);
                pg.setIsZoomed(false);
              }}
              onNext={pg.handleNext}
              onPrev={pg.handlePrev}
              onToggleFullscreen={pg.toggleFullscreen}
              onDelete={() => pg.setImageToDelete(pg.images[pg.selectedIndex!].id)}
            />
          )}
        </AnimatePresence>
      </main>
    </>
  );
}
