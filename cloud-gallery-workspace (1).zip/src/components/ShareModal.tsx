import React from 'react';
import { X, Share2, Copy, Trash2, Check, Loader2, AlertTriangle } from 'lucide-react';
import { useShareLogic } from '../hooks/useShareLogic';
import ShareConfigForm from './ShareConfigForm';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageId: string;
  decryptedImageUrl: string;
}

export default function ShareModal({ isOpen, onClose, imageId, decryptedImageUrl }: ShareModalProps) {
  const s = useShareLogic(isOpen, imageId, decryptedImageUrl, onClose);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl relative" onClick={e => e.stopPropagation()}>
        <div className="p-5 border-b border-zinc-800 flex justify-between items-center bg-zinc-900/50">
          <div className="flex items-center gap-2 text-white">
            <Share2 className="text-zinc-400" size={20} />
            <h3 className="font-semibold text-lg">Compartilhar Imagem</h3>
          </div>
          <button 
            onClick={onClose}
            className="text-zinc-400 hover:text-white p-1 rounded-full hover:bg-zinc-800 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {s.checking ? (
          <div className="p-10 flex flex-col items-center justify-center gap-3">
            <Loader2 className="w-8 h-8 text-white animate-spin" strokeWidth={1.5} />
            <p className="text-sm text-zinc-400">Verificando links...</p>
          </div>
        ) : (
          <div className="p-5 flex flex-col gap-5">
            {s.error && (
              <div className="p-3 bg-red-950/40 border border-red-800 rounded-lg flex gap-2 items-start text-red-400 text-xs text-left">
                <AlertTriangle size={14} className="shrink-0 mt-0.5" />
                <span>{s.error}</span>
              </div>
            )}

            {s.existingShare ? (
              <div className="flex flex-col gap-4">
                <div className="p-4 bg-zinc-900 border border-zinc-850 rounded-xl flex flex-col gap-2">
                  <div className="text-xs text-zinc-400 font-medium text-left">Link ativo para esta imagem:</div>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      readOnly 
                      value={s.generatedLink}
                      className="bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-xs text-zinc-300 w-full select-all font-mono"
                    />
                    <button
                      onClick={s.handleCopy}
                      className="p-2 rounded-lg bg-zinc-800 text-zinc-300 hover:bg-zinc-700 hover:text-white transition-all shrink-0 active:scale-95"
                      title="Copiar Link"
                    >
                      {s.copied ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
                    </button>
                  </div>
                  
                  {s.existingShare.options.oneTimeView && (
                    <div className="text-xs text-amber-500 bg-amber-500/10 p-2 rounded border border-amber-950 text-left mt-1">
                      ⚠️ Este é um link de <strong>visualização única</strong>. Uma vez aberto por 1 minuto, ele se inutilizará automaticamente e bloqueará outros acessos.
                    </div>
                  )}

                  <div className="text-[11px] text-zinc-500 text-left mt-1">
                    Configurado como:{' '}
                    {s.existingShare.options.requirePassword ? 'Com Senha' : 'Sem Senha'} •{' '}
                    {s.existingShare.options.allowDownload ? 'Download permitido' : 'Download proibido'} •{' '}
                    {s.existingShare.options.oneTimeView ? 'Visualização Única' : 'Visualização comum'}
                  </div>
                </div>

                <div className="flex gap-3 mt-2">
                  <button
                    onClick={s.handleDeleteShare}
                    disabled={s.loading}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-red-950/50 hover:bg-red-900/50 text-red-400 border border-red-900 rounded-xl text-sm font-medium transition-all active:scale-95 disabled:opacity-50"
                  >
                    {s.loading ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />}
                    Excluir Link Existente
                  </button>
                  <button
                    onClick={onClose}
                    className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-sm font-medium transition-all"
                  >
                    Fechar
                  </button>
                </div>
              </div>
            ) : (
              <ShareConfigForm
                linkDuration={s.linkDuration}
                setLinkDuration={s.setLinkDuration}
                requirePassword={s.requirePassword}
                setRequirePassword={s.setRequirePassword}
                password={s.password}
                setPassword={s.setPassword}
                allowDownload={s.allowDownload}
                setAllowDownload={s.setAllowDownload}
                oneTimeView={s.oneTimeView}
                setOneTimeView={s.setOneTimeView}
                loading={s.loading}
                onClose={onClose}
                onGenerate={s.handleGenerateShare}
              />
            )}
          </div>
        )}
      </div>
    </div>
  );
}
