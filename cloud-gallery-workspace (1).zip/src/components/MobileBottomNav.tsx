import React from "react";
import { Shield, Image as ImageIcon, Trash2, Settings } from "lucide-react";
import { motion } from "motion/react";

interface MobileBottomNavProps {
  activeTab: string;
  setActiveTab: (tab: any) => void;
  isSelectionMode: boolean;
  selectedImageId: string | null;
  isProtectedLightboxOpen: boolean;
  setIsSelectionMode: (val: boolean) => void;
  setSelectedForDeletion: (val: any[]) => void;
}

export default function MobileBottomNav({
  activeTab,
  setActiveTab,
  isSelectionMode,
  selectedImageId,
  isProtectedLightboxOpen,
  setIsSelectionMode,
  setSelectedForDeletion,
}: MobileBottomNavProps) {
  if (isSelectionMode || selectedImageId || isProtectedLightboxOpen) {
    return null;
  }

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-[100] bg-black/90 backdrop-blur-lg border-t border-white/5 py-2 px-4 flex items-center justify-around pb-safe shadow-2xl">
      <motion.button
        whileTap={{ scale: 0.85, opacity: 0.7 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        onClick={() => {
          setActiveTab('gallery');
          setIsSelectionMode(false);
          setSelectedForDeletion([]);
        }}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
          activeTab === 'gallery'
            ? 'text-white font-semibold'
            : 'text-zinc-500 hover:text-zinc-300'
        }`}
      >
        <ImageIcon size={20} />
        <span className="text-[10px] font-medium">Galeria</span>
      </motion.button>

      <motion.button
        whileTap={{ scale: 0.85, opacity: 0.7 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        onClick={() => {
          setActiveTab('protected');
          setIsSelectionMode(false);
          setSelectedForDeletion([]);
        }}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
          activeTab === 'protected'
            ? 'text-emerald-400 font-semibold'
            : 'text-zinc-500 hover:text-zinc-300'
        }`}
      >
        <Shield size={20} />
        <span className="text-[10px] font-medium">Protegidas</span>
      </motion.button>

      <motion.button
        whileTap={{ scale: 0.85, opacity: 0.7 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        onClick={() => {
          setActiveTab('trash');
          setIsSelectionMode(false);
        }}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
          activeTab === 'trash'
            ? 'text-white font-semibold'
            : 'text-zinc-500 hover:text-zinc-300'
        }`}
      >
        <Trash2 size={20} />
        <span className="text-[10px] font-medium">Lixeira</span>
      </motion.button>

      <motion.button
        whileTap={{ scale: 0.85, opacity: 0.7 }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        onClick={() => {
          setActiveTab('settings');
          setIsSelectionMode(false);
        }}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl transition-all ${
          activeTab === 'settings'
            ? 'text-white font-semibold'
            : 'text-zinc-500 hover:text-zinc-300'
        }`}
      >
        <Settings size={20} />
        <span className="text-[10px] font-medium">Config</span>
      </motion.button>
    </div>
  );
}
